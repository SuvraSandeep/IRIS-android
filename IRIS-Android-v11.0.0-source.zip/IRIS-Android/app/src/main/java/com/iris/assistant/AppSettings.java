package com.iris.assistant;

import android.content.Context;
import android.content.SharedPreferences;

public final class AppSettings {
    public static final String MODE_WAKE = "wake";
    public static final String MODE_TAP = "tap";
    public static final String MODE_CONTINUOUS = "continuous";
    public static final String LOG_COMMANDS = "commands";
    public static final String LOG_FULL = "full";
    public static final String LOG_OFF = "off";

    private static final String PREFS = "iris_settings_v2";
    private final SharedPreferences prefs;
    private final Context context;

    public AppSettings(Context context) {
        this.context=context.getApplicationContext();
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String listeningMode() { return MODE_TAP.equals(prefs.getString("listening_mode",MODE_WAKE))?MODE_TAP:MODE_WAKE; }
    public void setListeningMode(String value) { prefs.edit().putString("listening_mode", value).apply(); }
    public String logMode() { return prefs.getString("log_mode", LOG_COMMANDS); }
    public void setLogMode(String value) { prefs.edit().putString("log_mode", value).apply(); }
    public int retentionDays() { return prefs.getInt("retention_days", 7); }
    public void setRetentionDays(int value) { prefs.edit().putInt("retention_days", value).apply(); }
    public String personality() { return prefs.getString("personality", "Sarcastic"); }
    public void setPersonality(String value) { prefs.edit().putString("personality", value).apply(); }
    public boolean requireUnlock() { return prefs.getBoolean("require_unlock", true); }
    public void setRequireUnlock(boolean value) { prefs.edit().putBoolean("require_unlock", value).apply(); }
    public boolean haptics() { return prefs.getBoolean("haptics", true); }
    public void setHaptics(boolean value) { prefs.edit().putBoolean("haptics", value).apply(); }
    public boolean voiceReplies() { return prefs.getBoolean("voice_replies", true); }
    public void setVoiceReplies(boolean value) { prefs.edit().putBoolean("voice_replies", value).apply(); }
    /** Exact TTS voice name the user picked (empty = auto-select a female en-IN voice). */
    public String ttsVoiceName() { return prefs.getString("tts_voice_name", ""); }
    public void setTtsVoiceName(String v) { prefs.edit().putString("tts_voice_name", v == null ? "" : v).apply(); }
    public boolean preferOnDevice() { return prefs.getBoolean("prefer_on_device", false); }
    public void setPreferOnDevice(boolean value) { prefs.edit().putBoolean("prefer_on_device", value).apply(); }
    public String preferredMicrophone() { return prefs.getString("preferred_microphone", "Automatic"); }
    public void setPreferredMicrophone(String value) { prefs.edit().putString("preferred_microphone", value).apply(); }
    public String languageTag() { return prefs.getString("language_tag", "en-IN"); }
    public void setLanguageTag(String value) { prefs.edit().putString("language_tag", value).apply(); }
    public String resolvedLanguageTag() {
        String value = languageTag();
        if ("hinglish".equals(value)) return "en-IN";
        return "system".equals(value) ? java.util.Locale.getDefault().toLanguageTag() : value;
    }
    public float textScale() { return prefs.getFloat("text_scale", 1.0f); }
    public void setTextScale(float value) { prefs.edit().putFloat("text_scale", value).apply(); }
    /** Use the large, high-accuracy Vosk en-IN model (~1GB, downloaded on first use).
     *  Off by default; falls back to the small model automatically if it can't load. */
    public boolean highAccuracyVoice() { return false; } // Retired large decoder: bounded command-model memory.
    public void setHighAccuracyVoice(boolean value) { prefs.edit().putBoolean("high_accuracy_voice", value).apply(); }
    /** Server mode: use a private online server for smarter NLP/STT; auto-falls back offline. */
    public boolean serverModeEnabled() { return prefs.getBoolean("server_mode", false); }
    public void setServerModeEnabled(boolean v) { prefs.edit().putBoolean("server_mode", v).apply(); }
    public String serverUrl() { return prefs.getString("server_url", ""); }
    public void setServerUrl(String v) { prefs.edit().putString("server_url", v == null ? "" : v.trim()).apply(); }
    public String serverToken() { return prefs.getString("server_token", ""); }
    public void setServerToken(String v) { prefs.edit().putString("server_token", v == null ? "" : v.trim()).apply(); }
    /** Send audio to the server's Whisper endpoint for transcription (best accent accuracy). */
    public boolean serverStt() { return false; }
    public void setServerStt(boolean v) { prefs.edit().putBoolean("server_stt", v).apply(); }
    /** Speak replies with the server's Piper voice (falls back to Android TTS if unavailable). */
    public boolean serverTts() { return prefs.getBoolean("server_tts", false); }
    public void setServerTts(boolean v) { prefs.edit().putBoolean("server_tts", v).apply(); }
    public boolean autoOfflineWhenSlow() { return prefs.getBoolean("server_auto_offline_slow", true); }
    public void setAutoOfflineWhenSlow(boolean v) { prefs.edit().putBoolean("server_auto_offline_slow", v).apply(); }
    public int serverSlowMs() { return prefs.getInt("server_slow_ms", 30000); }
    public void setServerSlowMs(int v) { prefs.edit().putInt("server_slow_ms", v).apply(); }
    /** Let IRIS act on commands while the phone is locked (UI actions prompt a quick unlock). */
    public boolean lockScreenControl() { return prefs.getBoolean("lock_screen_control", false); }
    public void setLockScreenControl(boolean value) { prefs.edit().putBoolean("lock_screen_control", value).apply(); }
    /** Voice-verification strictness 0=lenient .. 1=strict (default balanced; missing verification always rejects). */
    // A saved profile is authoritative so applying or undoing a policy cannot leave the
    // control displaying a different threshold from the one used by live verification.
    public float ownerStrictness() {
        double policy=new ProfileStore(context).ownerPolicy();
        float value=!Double.isFinite(policy)?prefs.getFloat("owner_strictness_v3",1f-voiceSensitivity()):(float)((policy-.65)/.20);
        return Float.isFinite(value)?Math.max(0,Math.min(1,value)):.5f;
    }
    public double ownerThreshold() { double policy=new ProfileStore(context).ownerPolicy(); return Double.isFinite(policy)?policy:.65+.20*ownerStrictness(); }
    public boolean setOwnerStrictness(float value) { WakeChangeApproval.require(); if(!Float.isFinite(value))return false; return prefs.edit().putFloat("owner_strictness_v3",Math.max(0,Math.min(1,value))).commit(); }
    public float voiceSensitivity() { return Math.max(0f, Math.min(1f, prefs.getFloat("owner_voice_sensitivity_v2", 0.75f))); }
    public void setVoiceSensitivity(float value) { WakeChangeApproval.require(); prefs.edit().putFloat("owner_voice_sensitivity_v2", Math.max(0f, Math.min(1f, value))).apply(); }
    /** Use Google Speech Recognition for commands (best accuracy; falls back to Vosk offline). */
    public boolean googleSttForCommands() { return prefs.getBoolean("google_stt_commands",false); }
    public void setGoogleSttForCommands(boolean v) { prefs.edit().putBoolean("google_stt_commands", v).apply(); }
    /** Speak a cue when a wake voice isn't recognized as the owner. */
    public boolean voiceCueEnabled() { return prefs.getBoolean("voice_cue_enabled", true); }
    public void setVoiceCueEnabled(boolean value) { prefs.edit().putBoolean("voice_cue_enabled", value).apply(); }

    // ---------------- Appearance / customization ----------------
    public static final String THEME_DARK = "dark";
    public static final String THEME_AMOLED = "amoled";
    public static final String DENSITY_COMFORTABLE = "comfortable";
    public static final String DENSITY_COMPACT = "compact";
    public static final String DEFAULT_ACCENT = "#22D3EE";

    public String accentColor() { return prefs.getString("accent_color", DEFAULT_ACCENT); }
    public void setAccentColor(String hex) { prefs.edit().putString("accent_color", hex).apply(); }
    public String theme() { return prefs.getString("ui_theme", THEME_DARK); }
    public void setTheme(String value) { prefs.edit().putString("ui_theme", value).apply(); }
    public boolean reduceMotion() { return prefs.getBoolean("reduce_motion", false); }
    public void setReduceMotion(boolean value) { prefs.edit().putBoolean("reduce_motion", value).apply(); }
    public String density() { return prefs.getString("ui_density", DENSITY_COMFORTABLE); }
    public void setDensity(String value) { prefs.edit().putString("ui_density", value).apply(); }
    /** CSV of quick-action chip ids shown on the home screen. */
    public String homeChips() { return prefs.getString("home_chips", "call,text,alarm,weather,torch,time"); }
    public void setHomeChips(String csv) { prefs.edit().putString("home_chips", csv).apply(); }
    // Off by default (7.37.0): wake on the phrase alone unless the user opts into stricter,
    // voice-matched wake. Previously hardcoded to true, which silently rejected every wake
    // attempt for anyone who hadn't completed voice enrollment (no voiceprint → owner() always
    // false), even though the phrase was heard correctly. That regression is fixed here.
    public boolean speakerVerification() { return true; }
    public void setSpeakerVerification(boolean value) { WakeChangeApproval.require(); prefs.edit().putBoolean("speaker_verification", value).apply(); }
    public boolean shakeToWake() { return prefs.getBoolean("shake_to_wake", false); }
    public void setShakeToWake(boolean v) { prefs.edit().putBoolean("shake_to_wake", v).apply(); }
    public boolean headsetTrigger() { return prefs.getBoolean("headset_trigger", false); }
    public void setHeadsetTrigger(boolean v) { prefs.edit().putBoolean("headset_trigger", v).apply(); }
    /** Which media button wakes IRIS: "play_pause" (default, matches the old hardcoded
     *  behaviour), "next", or "previous". Volume up/down are deliberately not offered —
     *  Bluetooth earphone volume presses go through AVRCP as system broadcasts, not
     *  KEYCODE_MEDIA_* events, and cannot be intercepted by any regular app. */
    public String triggerButton() { return prefs.getString("trigger_button", "play_pause"); }
    public void setTriggerButton(String v) { prefs.edit().putString("trigger_button", v == null ? "play_pause" : v).apply(); }
    /** How many presses of the chosen button, within the double-press window, wake IRIS. */
    public int triggerPressCount() { return prefs.getInt("trigger_press_count", 2); }
    public void setTriggerPressCount(int v) { prefs.edit().putInt("trigger_press_count", Math.max(1, Math.min(3, v))).apply(); }
    public boolean mirrorReplies() { return prefs.getBoolean("mirror_replies", true); }

    // ─────────────── Command Deck (fully customisable) ───────────────
    /** Show the SYSTEM TELEMETRY section at all. */
    public boolean deckTelemetry() { return prefs.getBoolean("deck_telemetry", true); }
    public void setDeckTelemetry(boolean v) { prefs.edit().putBoolean("deck_telemetry", v).apply(); }
    /** Off by default: opening the Command Deck reads one snapshot and stops, instead of
     *  ticking every 1-4s. Turning this on resumes the live-updating dashboard until it's
     *  switched off again or the deck is left. Saves RAM/CPU for the common case of a quick
     *  glance rather than a continuous readout. */
    public boolean deckContinuousRead() { return prefs.getBoolean("deck_continuous_read", false); }
    public void setDeckContinuousRead(boolean v) { prefs.edit().putBoolean("deck_continuous_read", v).apply(); }
    /** Show the activity stream console. */
    public boolean deckActivityStream() { return prefs.getBoolean("deck_activity", true); }
    public void setDeckActivityStream(boolean v) { prefs.edit().putBoolean("deck_activity", v).apply(); }
    /** Show the four summary tiles under the orb. */
    public boolean deckTiles() { return prefs.getBoolean("deck_tiles", true); }
    public void setDeckTiles(boolean v) { prefs.edit().putBoolean("deck_tiles", v).apply(); }
    /** Orb diameter in dp (spec suggests 190–210 on a normal phone). */
    public int deckOrbSize() { return prefs.getInt("deck_orb_size", 200); }
    public void setDeckOrbSize(int dp) { prefs.edit().putInt("deck_orb_size", Math.max(120, Math.min(260, dp))).apply(); }
    /** Battery-saving visual mode: no continuous animation, static rings. */
    public boolean deckBatterySaver() { return prefs.getBoolean("deck_battery_saver", false); }
    public void setDeckBatterySaver(boolean v) { prefs.edit().putBoolean("deck_battery_saver", v).apply(); }
    /** IRIS's own resource-saving mode: distinct from deckBatterySaver, which only freezes
     *  Command Deck visuals. This actually reduces what IRIS does: the AI brain is disabled,
     *  the small (not high-accuracy) Vosk model is forced, the orb goes static, and telemetry
     *  ticking is skipped in favour of read-once — real CPU/RAM/battery savings, not cosmetic. */
    public boolean irisPowerSaver() { return prefs.getBoolean("iris_power_saver", false); }
    public void setIrisPowerSaver(boolean v) { prefs.edit().putBoolean("iris_power_saver", v).apply(); }
    /** Faint background scanline (optional per spec). */
    public boolean deckScanline() { return prefs.getBoolean("deck_scanline", true); }
    public void setDeckScanline(boolean v) { prefs.edit().putBoolean("deck_scanline", v).apply(); }
    /** Public IP lookup — OFF by default, needs an outside service. */
    public boolean telemetryPublicIp() { return prefs.getBoolean("telemetry_public_ip", false); }
    public void setTelemetryPublicIp(boolean v) { prefs.edit().putBoolean("telemetry_public_ip", v).apply(); }
    /** Which telemetry tab opens first: overview/network/devices/sensors/resources. */
    public String deckDefaultTab() { return prefs.getString("deck_tab", "overview"); }
    public void setDeckDefaultTab(String tab) { prefs.edit().putString("deck_tab", tab == null ? "overview" : tab).apply(); }
    public void setMirrorReplies(boolean v) { prefs.edit().putBoolean("mirror_replies", v).apply(); }
    public boolean mirrorMajorOnly() { return prefs.getBoolean("mirror_major_only", true); }
    public void setMirrorMajorOnly(boolean v) { prefs.edit().putBoolean("mirror_major_only", v).apply(); }
    /** Mirror replies even while the screen is on (not just when it's off). */
    public boolean mirrorAlways() { return prefs.getBoolean("mirror_always", true); }
    public void setMirrorAlways(boolean v) { prefs.edit().putBoolean("mirror_always", v).apply(); }
}
