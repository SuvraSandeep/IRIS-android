package com.iris.assistant;

import android.Manifest;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IrisListeningService extends Service implements RecognitionListener {
    public static final String ACTION_START = "com.iris.assistant.START";
    public static final String ACTION_STOP = "com.iris.assistant.STOP";
    public static final String ACTION_CONFIRM_CALL = "com.iris.assistant.CONFIRM_CALL";
    public static final String ACTION_CANCEL_CALL = "com.iris.assistant.CANCEL_CALL";
    public static final String ACTION_CHOOSE_CONTACT = "com.iris.assistant.CHOOSE_CONTACT";
    public static final String ACTION_PROCESS_TEXT = "com.iris.assistant.PROCESS_TEXT";
    public static final String ACTION_STOP_RECORDING = "com.iris.assistant.STOP_RECORDING";
    public static final String ACTION_TALK = "com.iris.assistant.TALK";
    public static final String ACTION_CAPTURE_DONE = "com.iris.assistant.CAPTURE_DONE";
    public static final String ACTION_CAPTURE_STARTED = "com.iris.assistant.CAPTURE_STARTED";
    private Runnable cameraLaunchTimeout;
    private PendingIntent cameraLaunchIntent;
    private static final int CAMERA_LAUNCH_NOTIFICATION = 0xC0DE;
    public static final String ACTION_STOP_SPEAKING = "com.iris.assistant.STOP_SPEAKING";
    public static final String ACTION_STOP_VIDEO = "com.iris.assistant.STOP_VIDEO";
    public static final String EVENT_STATE = "com.iris.assistant.EVENT_STATE";
    public static final String EVENT_TRANSCRIPT = "com.iris.assistant.EVENT_TRANSCRIPT";
    public static final String EVENT_CALL_PROMPT = "com.iris.assistant.EVENT_CALL_PROMPT";
    public static final String EVENT_DISAMBIGUATE = "com.iris.assistant.EVENT_DISAMBIGUATE";
    public static final String EVENT_TEACH = "com.iris.assistant.EVENT_TEACH";
    public static final String EVENT_LEVEL = "com.iris.assistant.EVENT_LEVEL";
    public static final String EVENT_MESSAGE = "com.iris.assistant.EVENT_MESSAGE";
    public static final String EXTRA_ACTIVE = "active";
    public static final String EXTRA_PHASE = "phase";
    public static final String EXTRA_TEXT = "text";
    public static final String EXTRA_NAME = "name";
    public static final String EXTRA_NUMBER = "number";
    public static final String EXTRA_NAMES = "names";
    public static final String EXTRA_NUMBERS = "numbers";
    public static final String EXTRA_MIC = "mic";
    public static final String EXTRA_RECOGNITION = "recognition";
    public static final String EXTRA_AUTH_REQUIRED = "auth_required";
    public static final String EXTRA_TEACH = "teach";
    public static final String EXTRA_LEVEL = "level";

    private static final String LISTENING_CHANNEL = "iris_listening_v2";
    private static final String CALL_CHANNEL = "iris_call_confirmation_v2";
    private static final int LISTENING_NOTIFICATION = 4201;
    private static final int CALL_NOTIFICATION = 4202;
    private static final int TEACH_NOTIFICATION = 4203;
    private static final Pattern CALL_PATTERN = Pattern.compile(
            "^(?:(?:please|can you|could you|just)\\s+)?"
            + "(?:call|dial|phone|ring|ring up|phone up|buzz|hit up"
            + "|get\\s+.+?\\s+on\\s+the\\s+(?:line|phone)"
            + "|talk\\s+to|speak\\s+to|connect\\s+(?:me\\s+)?to|reach)"
            + "\\s+(.+?)(?:\\s+(?:please|for me))?$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern HINDI_CALL_PATTERN = Pattern.compile(
            "^(.+?)\\s+(?:ko\\s+(?:call|phone|ring)\\s+karo|se\\s+baat\\s+karo|ko\\s+phone\\s+karo)$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern REDIAL_PATTERN = Pattern.compile(
            "^(?:redial|call\\s+(?:again|back|the\\s+last\\s+(?:person|one|contact))|ring\\s+(?:again|back))$",
            Pattern.CASE_INSENSITIVE);
    // "spell the name", "call by spelling" — enter letter-by-letter contact spelling
    private static final Pattern SPELL_CALL_PATTERN = Pattern.compile(
            "^(?:call\\s+by\\s+spelling|spell(?:ing)?(?:\\s+(?:the\\s+)?(?:name|contact))?"
            + "|spell\\s+(?:the\\s+)?(?:name|contact)|let\\s+me\\s+spell)$",
            Pattern.CASE_INSENSITIVE);
    // "what version are you", "app version" / "what's new in this version"
    private static final Pattern VERSION_PATTERN = Pattern.compile(
            "^(?:(?:what|which)(?:'?s| is)?\\s+(?:your\\s+|the\\s+|iris\\s+|app\\s+)?version(?:\\s+number)?"
            + "|what\\s+version\\s+are\\s+you|your\\s+version|app\\s+version|version\\s+number|version)$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern WHATSNEW_PATTERN = Pattern.compile(
            "^(?:what'?s\\s+new(?:\\s+in\\s+(?:this|the\\s+latest)?\\s*(?:version|update|build)?)?"
            + "|what\\s+is\\s+new|what(?:'?s| did\\s+you)\\s+(?:changed?|add(?:ed)?)"
            + "|release\\s+notes|change\\s?log|what'?s\\s+in\\s+this\\s+(?:version|update|build))$",
            Pattern.CASE_INSENSITIVE);
    // What's-new summary — UPDATE this each release (per PROJECT-RULES).
    private static final String VERSION_NOTES =
            "Indian English speech defaults, a matching offline model, clearer retry prompts, and safer "
            + "natural command parsing. Names and message text are no longer rewritten by command training. "
            + "Use Indian English accuracy setup in Settings if your old preferences are still active.";
    private static final Pattern QUICK_ACTION_PATTERN = Pattern.compile(
            "^(?:what(?:\\s+is)?\\s+the\\s+time|time\\s*(?:please)?|what\\s+time\\s+is\\s+it"
            + "|battery|battery\\s+level|how\\s+much\\s+battery"
            + "|stop|shut\\s+up|quiet|silence|go\\s+to\\s+sleep"
            + "|help|what\\s+can\\s+you\\s+do)$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern RELATIONSHIP_CALL_PATTERN = Pattern.compile(
            "^(?:(?:please|can you)\\s+)?(?:call|dial|phone|ring|talk\\s+to|reach)\\s+(?:my\\s+)?(.+?)(?:\\s+(?:please|for me))?$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern HISTORY_PATTERN = Pattern.compile(
            "^(?:who\\s+did\\s+i\\s+call\\s*(?:last|today|yesterday)?"
            + "|how\\s+many\\s+times\\s+did\\s+i\\s+call\\s+(.+)"
            + "|when\\s+did\\s+i\\s+(?:last\\s+)?call\\s+(.+)"
            + "|call\\s+history|my\\s+calls)$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern MEMORY_PATTERN = Pattern.compile(
            "^(?:remember|note|save|store)\\s+(?:that\\s+)?(.+)$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern OPEN_APP_PATTERN = Pattern.compile(
            "^(?:please\\s+)?(?:open|launch|start|run)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern WEATHER_PATTERN = Pattern.compile(
            ".*\\b(?:weather|forecast|temperature|how\\s+(?:hot|cold|warm)|going\\s+to\\s+rain"
            + "|will\\s+it\\s+rain|is\\s+it\\s+(?:raining|sunny|hot|cold))\\b.*",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern LOCATION_PATTERN = Pattern.compile(
            ".*\\b(?:where\\s+am\\s+i|where\\s+are\\s+we|where\\s+is\\s+this"
            + "|my\\s+(?:current\\s+)?location|current\\s+location"
            + "|what(?:'?s|\\s+is)\\s+my\\s+location"
            + "|which\\s+(?:city|place|area|town)\\s+am\\s+i(?:\\s+in)?)\\b.*",
            Pattern.CASE_INSENSITIVE);
    // "text Rahul saying I'll be late" / "send a message to mom that I'm coming"
    private static final Pattern SMS_PATTERN = Pattern.compile(
            "^(?:send\\s+(?:a\\s+)?(?:text|message|sms)\\s+to|text|message|sms)\\s+(.+?)\\s+(?:saying|that|:)\\s+(.+)$",
            Pattern.CASE_INSENSITIVE);
    // "text my office email to mom" / "send my number to dad" — share a value/text TO a contact
    private static final Pattern SHARE_PATTERN = Pattern.compile(
            "^(?:send|text|share|message|forward)\\s+(.+?)\\s+to\\s+(.+)$",
            Pattern.CASE_INSENSITIVE);
    // Loose, natural texting with NO "saying": "text mom i'll be late", "tell dad i'm coming",
    // "let mom know i'm safe". Recipient is inferred; only fires if it resolves to a real contact.
    private static final Pattern SMS_LOOSE_PATTERN = Pattern.compile(
            "^(?:text|txt|message|msg|sms|tell|let)\\s+(.+)$",
            Pattern.CASE_INSENSITIVE);
    // "send an sms", "send a text to mom", "compose a message" — start the guided compose flow
    // (IRIS will ask for whoever/whatever is missing).
    private static final Pattern SMS_START_PATTERN = Pattern.compile(
            "^(?:send|write|compose|start|create)\\s+(?:a|an)?\\s*(?:sms|text\\s*message|text|message|txt)"
            + "(?:\\s+to\\s+(.+))?$",
            Pattern.CASE_INSENSITIVE);
    // "whatsapp Rahul saying hi" / "send a whatsapp to mom that ..."
    private static final Pattern WHATSAPP_PATTERN = Pattern.compile(
            "^(?:send\\s+(?:a\\s+)?whatsapp(?:\\s+message)?\\s+to|whatsapp(?:\\s+message)?(?:\\s+to)?)\\s+(.+?)\\s+(?:saying|that|:)\\s+(.+)$",
            Pattern.CASE_INSENSITIVE);
    // "set an alarm for 7:30 am" / "wake me up at 6 am"
    private static final Pattern ALARM_PATTERN = Pattern.compile(
            "^(?:set\\s+(?:an?\\s+)?alarm(?:\\s+(?:for|at))?|wake\\s+me(?:\\s+up)?(?:\\s+(?:at|for))?)\\s+(.+)$",
            Pattern.CASE_INSENSITIVE);
    // "set a timer for 5 minutes"
    private static final Pattern TIMER_PATTERN = Pattern.compile(
            "^(?:set\\s+(?:a\\s+)?timer(?:\\s+for)?|timer(?:\\s+for)?)\\s+(.+)$",
            Pattern.CASE_INSENSITIVE);
    // "remind me to call mom in 10 minutes" / "remind me to take medicine at 9 pm"
    private static final Pattern REMINDER_PATTERN = Pattern.compile(
            "^(?:remind\\s+me\\s+to|set\\s+a\\s+reminder\\s+to|reminder\\s+to)\\s+(.+?)\\s+(in|at)\\s+(.+)$",
            Pattern.CASE_INSENSITIVE);
    // "turn on the flashlight" / "torch off"
    private static final Pattern TORCH_PATTERN = Pattern.compile(
            "^(?:turn\\s+(on|off)\\s+(?:the\\s+)?(?:flash\\s*light|torch|flash)"
            + "|(?:flash\\s*light|torch|flash)\\s+(on|off))$",
            Pattern.CASE_INSENSITIVE);
    // "volume up/down/mute/max" / "turn up the volume" / "mute"
    private static final Pattern VOLUME_PATTERN = Pattern.compile(
            "^(?:volume\\s+(up|down|max|maximum|mute|unmute)"
            + "|turn\\s+(up|down)\\s+(?:the\\s+)?volume"
            + "|(mute|unmute)(?:\\s+(?:the\\s+)?(?:volume|sound|phone))?"
            + "|(max|maximum)\\s+volume)$",
            Pattern.CASE_INSENSITIVE);
    // "set volume to 50", "volume 50 percent", "set the volume at 30%"
    private static final Pattern VOLUME_SET_PATTERN = Pattern.compile(
            "^(?:set\\s+)?(?:the\\s+)?volume\\s+(?:to\\s+|at\\s+)?(.+?)\\s*(?:percent|%)?$",
            Pattern.CASE_INSENSITIVE);
    // Ringer: silent / vibrate / normal
    private static final Pattern SILENT_PATTERN = Pattern.compile(
            "^(?:(?:go\\s+|turn\\s+on\\s+)?silent(?:\\s+mode)?|silence\\s+(?:my\\s+)?phone"
            + "|make\\s+(?:my\\s+)?phone\\s+silent|mute\\s+(?:my\\s+)?phone)$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern VIBRATE_PATTERN = Pattern.compile(
            "^(?:vibrate(?:\\s+mode|\\s+only)?|(?:go\\s+|turn\\s+on\\s+)?vibrate)$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern NORMAL_RINGER_PATTERN = Pattern.compile(
            "^(?:normal\\s+mode|ring(?:er)?\\s+mode|sound\\s+on|turn\\s+on\\s+(?:the\\s+)?(?:sound|ringer)"
            + "|unmute\\s+(?:my\\s+)?phone|general\\s+mode)$",
            Pattern.CASE_INSENSITIVE);
    // Do Not Disturb on/off
    private static final Pattern DND_PATTERN = Pattern.compile(
            "^(?:turn\\s+on\\s+|enable\\s+|start\\s+)?(?:do\\s+not\\s+disturb|dnd)(?:\\s+on)?$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern DND_OFF_PATTERN = Pattern.compile(
            "^(?:(?:turn\\s+off|disable|stop|end)\\s+(?:do\\s+not\\s+disturb|dnd)"
            + "|(?:do\\s+not\\s+disturb|dnd)\\s+off)$",
            Pattern.CASE_INSENSITIVE);
    // Unified mode control (silent/vibrate/normal/dnd/airplane) — on/off/status, state-aware.
    private static final String MODE_WORDS =
            "(silent|vibrate|ringer|ring|normal|do\\s+not\\s+disturb|dnd|aeroplane|aero\\s*plane|airplane|air\\s*plane|flight)";
    private static final Pattern MODE_QUERY_PATTERN = Pattern.compile(
            "^(?:is|are)\\s+(?:the\\s+|my\\s+)?" + MODE_WORDS
            + "\\s*(?:mode)?\\s*(?:on|off|active|enabled|turned\\s+on|turned\\s+off)?\\s*\\??$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern MODE_SET_PATTERN = Pattern.compile(
            "^(?:(turn\\s+on|turn\\s+off|switch\\s+on|switch\\s+off|enable|disable|start|stop|end|go)\\s+)?"
            + "(?:the\\s+)?" + MODE_WORDS + "\\s*(?:mode)?\\s*(on|off)?$",
            Pattern.CASE_INSENSITIVE);
    // Self-awareness: recall / repeat the last action.
    private static final Pattern LAST_ACTION_PATTERN = Pattern.compile(
            "^(?:what\\s+did\\s+you\\s+(?:just\\s+)?do|what\\s+was\\s+(?:your\\s+|the\\s+)?last\\s+action"
            + "|what\\s+did\\s+you\\s+last\\s+do|your\\s+last\\s+action|what\\s+was\\s+that)\\??$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern REPEAT_ACTION_PATTERN = Pattern.compile(
            "^(?:do\\s+(?:that|it)\\s+again|repeat\\s+(?:that|it|the\\s+last\\s+(?:action|command))"
            + "|again|same\\s+again|one\\s+more\\s+time)$",
            Pattern.CASE_INSENSITIVE);
    // Phase 1: let the user tell IRIS it got it wrong, so it can be measured and learned.
    private static final Pattern WRONG_ACTION_PATTERN = Pattern.compile(
            "^(?:that(?:'s| is| was)?\\s+(?:wrong|not right|incorrect|not what i (?:said|meant))"
            + "|wrong|not what i (?:said|meant)|you (?:got it wrong|misheard me)"
            + "|i didn'?t say that)\\.?$",
            Pattern.CASE_INSENSITIVE);
    // Phase 3 — action-ledger queries: where things went, sharing the last one, undo.
    private static final Pattern WHERE_SAVED_PATTERN = Pattern.compile(
            "^(?:where\\s+(?:did\\s+you\\s+|is\\s+|was\\s+)?(?:it|that|the\\s+(?:file|photo|video|screenshot|recording|memo))?"
            + "\\s*(?:saved?|stored?|kept?|go|gone)?"
            + "|where'?s\\s+(?:it|that|the\\s+\\w+))\\s*\\??$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern SEND_LAST_PATTERN = Pattern.compile(
            "^(?:send|share)\\s+(?:me\\s+)?(?:the\\s+)?(?:last|latest|recent|most\\s+recent)\\s+"
            + "(screenshot|screen\\s?shot|photo|picture|image|video|clip|recording|voice|memo|audio|one|file)"
            + "(?:\\s+.*)?$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern UNDO_PATTERN = Pattern.compile(
            "^(?:undo(?:\\s+(?:that|it|the\\s+last\\s+(?:one|action|reminder)))?"
            + "|cancel\\s+(?:that|the\\s+last\\s+)?reminder"
            + "|forget\\s+(?:that|the\\s+last\\s+one))\\.?$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern TIMELINE_PATTERN = Pattern.compile(
            "^(?:what\\s+have\\s+you\\s+done|(?:show|read)\\s+(?:me\\s+)?(?:your\\s+)?"
            + "(?:activity|history|timeline|recent\\s+actions))\\s*\\??$",
            Pattern.CASE_INSENSITIVE);
    // "what's connected to bluetooth" / "what device is connected"
    private static final Pattern BT_DEVICE_PATTERN = Pattern.compile(
            "^(?:what(?:'s| is)\\s+connected(?:\\s+(?:to|via|over)\\s+bluetooth)?"
            + "|what\\s+(?:bluetooth\\s+)?device\\s+is\\s+connected"
            + "|(?:is\\s+)?(?:my\\s+)?bluetooth\\s+connected)\\s*\\??$",
            Pattern.CASE_INSENSITIVE);
    // "phone status" / "how's my phone" — full rundown of ringer, DND, airplane, net, bt, battery.
    private static final Pattern STATUS_PATTERN = Pattern.compile(
            "^(?:(?:what(?:'s| is)\\s+(?:my\\s+)?)?(?:phone|mobile|device|system)\\s+status"
            + "|(?:phone|mobile|device|system)\\s+report"
            + "|status(?:\\s+report)?"
            + "|how(?:'s| is)\\s+(?:my\\s+)?(?:phone|mobile|device))\\s*\\??$",
            Pattern.CASE_INSENSITIVE);
    // Timed voice memo: "record voice 20", "voice memo 30", "record audio for 1 minute", with
    // an optional mic phrase before or after the number ("...using earphone", "with bluetooth").
    private static final String MIC_WORDS =
            "(phone|built-?in|internal|earphones?|earbuds?|headset|headphones?|wired|usb|bluetooth|bt)";
    private static final Pattern VOICE_RECORD_PATTERN = Pattern.compile(
            "^(?:record|start|take|capture)?\\s*(?:a\\s+)?(?:voice|audio)(?:\\s+memo)?(?:\\s+recording)?\\b.*$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern STOP_RECORD_PATTERN = Pattern.compile(
            "^(?:stop|end|finish|cancel)\\s+(?:the\\s+)?(?:voice\\s+)?(?:recording|record|memo|audio)$",
            Pattern.CASE_INSENSITIVE);
    // Video: "record video 30", "record front camera video 20", "record video with back cam".
    // "take a photo/picture/selfie" — a still photo, NOT video (checked before VIDEO/screenshot).
    private static final Pattern PHOTO_PATTERN = Pattern.compile(
            "^(?:take|click|capture|snap)\\s+(?:a\\s+|my\\s+|the\\s+)?"
            + "(?:(front|selfie|back|rear)\\s+)?(?:camera\\s+)?(?:photo|picture|pic|selfie)\\b.*$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern VIDEO_RECORD_PATTERN = Pattern.compile(
            "^(?:record|start|take|capture)\\s+(?:a\\s+)?(?:(?:front|selfie|back|rear)\\s+)?(?:camera\\s+)?video\\b.*$",
            Pattern.CASE_INSENSITIVE);
    // Your phrasing: "start recording 30" → video on the back camera.
    private static final Pattern START_RECORDING_PATTERN = Pattern.compile(
            "^start\\s+recording\\b.*$", Pattern.CASE_INSENSITIVE);
    // Bare "record" / "begin recording" / "record now" with no keyword — default to back-camera
    // video, matching the existing "start recording" behaviour, so a plain "record" isn't ignored.
    private static final Pattern GENERIC_RECORD_PATTERN = Pattern.compile(
            "^(?:record|begin\\s+recording|record\\s+now)\\b.*$", Pattern.CASE_INSENSITIVE);
    // Screenshot: "screenshot", "take a screenshot", "capture the screen" (NOT recording).
    private static final Pattern SCREENSHOT_PATTERN = Pattern.compile(
            "^(?:(?:take|grab|capture|get)\\s+(?:a\\s+|the\\s+|my\\s+)?screen(?:\\s?shot)?"
            + "|(?:a\\s+)?screen\\s?shot|screen\\s+capture)\\b.*$",
            Pattern.CASE_INSENSITIVE);
    // Screen recording: must involve the word record/recording. "record the screen 30", "screen record".
    private static final Pattern SCREEN_REC_PATTERN = Pattern.compile(
            "^(?:(?:record|start)\\s+(?:the\\s+|my\\s+)?screen(?:\\s+recording)?|screen\\s+record(?:ing)?)\\b.*$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern SCREEN_REC_STOP_PATTERN = Pattern.compile(
            "^(?:stop|end|finish)\\s+(?:the\\s+)?screen\\s+record(?:ing)?$",
            Pattern.CASE_INSENSITIVE);
    // Control whatever is playing: pause/resume/next/previous.
    // Note: this must catch "play the next song" BEFORE PLAY_SONG_PATTERN, otherwise "next song"
    // gets treated as a song title and searched for in a music/video app.
    private static final Pattern MEDIA_CONTROL_PATTERN = Pattern.compile(
            "^(?:pause(?:\\s+(?:the\\s+)?(?:music|song|media|audio|playback))?"
            + "|stop\\s+(?:the\\s+)?(?:music|song|media|audio|playback)"
            + "|resume(?:\\s+(?:the\\s+)?(?:music|song|playback))?"
            + "|continue(?:\\s+playing)?"
            + "|play\\s+(?:the\\s+)?(?:music|song|playback)"
            + "|(?:play\\s+)?(?:the\\s+)?next(?:\\s+(?:song|track|music|one|this))?"
            + "|(?:play\\s+)?(?:the\\s+)?(?:previous|prev|last)(?:\\s+(?:song|track|music|one))?"
            + "|skip(?:\\s+(?:this|the)\\s*)?(?:\\s*(?:song|track|music|one))?"
            + "|go\\s+(?:to\\s+the\\s+)?(?:next|back|previous)(?:\\s+(?:song|track|music))?"
            + "|forward\\s+(?:the\\s+)?(?:song|track|music))$",
            Pattern.CASE_INSENSITIVE);
    // "play <song/artist>" — hands off to a music app to find & play a local track
    private static final Pattern PLAY_SONG_PATTERN = Pattern.compile(
            "^(?:play|put\\s+on)\\s+(.+)$",
            Pattern.CASE_INSENSITIVE);
    // "turn on wifi" / "disable bluetooth" / "wifi settings"
    private static final Pattern CONNECTIVITY_PATTERN = Pattern.compile(
            "^(?:turn\\s+(on|off)\\s+|enable\\s+|disable\\s+)?(wi-?fi|bluetooth)(?:\\s+settings?)?$",
            Pattern.CASE_INSENSITIVE);
    // "search for X" / "google X" / "look up X"
    private static final Pattern WEBSEARCH_PATTERN = Pattern.compile(
            "^(?:search\\s+(?:the\\s+web\\s+)?for|search|google|look\\s+up|web\\s+search\\s+for)\\s+(.+)$",
            Pattern.CASE_INSENSITIVE);
    // "navigate to X" / "directions to X" / "take me to X"
    private static final Pattern NAV_PATTERN = Pattern.compile(
            "^(?:navigate\\s+to|directions\\s+to|take\\s+me\\s+to|route\\s+to|how\\s+do\\s+i\\s+get\\s+to|navigate)\\s+(.+)$",
            Pattern.CASE_INSENSITIVE);
    // "email mom about dinner" / "send an email to john@x.com saying hi"
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^(?:send\\s+(?:an?\\s+)?email\\s+to|email)\\s+(.+?)(?:\\s+(?:about|saying|regarding|that|re)\\s+(.+))?$",
            Pattern.CASE_INSENSITIVE);
    // "add a meeting X at 3 pm" / "schedule an event Y" / "create an appointment Z on monday"
    private static final Pattern CALENDAR_PATTERN = Pattern.compile(
            "^(?:add|create|schedule|set\\s+up)\\s+(?:an?\\s+)?(?:event|meeting|appointment)\\s+(.+?)(?:\\s+(?:at|on)\\s+(.+))?$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern NOTIFICATION_PATTERN = Pattern.compile(
            ".*\\bnotifications?\\b.*"
            + "|.*\\bwho\\s+(?:texted|messaged|pinged)\\s+me\\b.*"
            + "|.*\\bwhat\\s+did\\s+i\\s+miss\\b.*"
            + "|.*\\b(?:how\\s+many|any|check|latest|last|read|unread|new)\\b.*\\b(?:message|messages|text|texts|whatsapp|sms)\\b.*"
            + "|.*\\b(?:message|messages|text|texts)\\s+from\\b.*",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern CLEAR_NOTIFICATION_PATTERN = Pattern.compile(
            "^(?:clear|dismiss|delete|remove|clean)\\s+(?:all\\s+|my\\s+|the\\s+)*notifications?.*$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern FORGET_PATTERN = Pattern.compile(
            "^(?:forget|delete|remove)\\s+(?:that|the\\s+last\\s+(?:memory|thing)|it)$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern RECALL_PATTERN = Pattern.compile(
            ".*\\b(?:what\\s+do\\s+you\\s+(?:know|remember)(?:\\s+about\\s+(.+))?"
            + "|know\\s+about\\s+me"
            + "|tell\\s+me\\s+about\\s+(?:me|myself)"
            + "|what.?s?\\s+in\\s+my\\s+memory"
            + "|my\\s+(?:memories|info|memory|details|profile))\\b.*",
            Pattern.CASE_INSENSITIVE);
    private static final String PHASE_WAKE = "wake";
    private static final String PHASE_COMMAND = "command";
    private static final String PHASE_CONFIRM = "confirm";

    public static volatile boolean isRunning;
    public static volatile String currentPhase = "off";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private Intent recognizerIntent;
    private WakeWordEngine wakeEngine;
    private AppSettings settings;
    private String phase = PHASE_WAKE;
    private String microphoneLabel = "Phone microphone";
    /** Last mic route IRIS configured — readable by the UI even between broadcasts. */
    public static volatile String currentMic = "";
    private String recognitionLabel = "System speech service";
    private String pendingName;
    private String pendingNumber;
    private java.util.List<ContactMatch> pendingCandidates;
    private int pendingCandidateIndex;
    private AudioManager audioManager;
    private int previousAudioMode = AudioManager.MODE_NORMAL;
    private AudioDeviceCallback audioDeviceCallback;
    private TextToSpeech textToSpeech;
    private boolean ttsReady;
    private android.media.MediaPlayer serverTtsPlayer;
    private int confirmationRetries;
    private String lastMemoryId;

    private VoskEngine voskEngine;
    private MediaMemoRecorder memoRecorder;
    private boolean voskReady;
    private volatile boolean androidWakeActive;
    private LlmAgent llmAgent;
    private final ConnectivityMonitor serverMonitor = new ConnectivityMonitor();
    private volatile boolean llmReady;
    private final ConversationManager conversation = new ConversationManager();
    private long lastLevelBroadcast;
    private Runnable commandTimeout;
    private Runnable confirmTimeout;
    private PowerManager.WakeLock wakeLock;
    private android.hardware.SensorManager sensorManager;
    private android.hardware.SensorEventListener shakeListener;
    private long lastShakeAt;
    private android.media.session.MediaSession mediaSession;
    private long lastHeadsetHookAt;

    @Override
    public void onCreate() {
        super.onCreate();
        settings = new AppSettings(this);
        try { PersonalProfile.seedInto(this); } catch (Throwable ignored) { }
        try { new ProfileStore(this).seedDefaultWakePhrase(); } catch (Throwable ignored) { }
        try { new ProfileStore(this).seedHardcodedVoiceprint(); } catch (Throwable ignored) { }
        createNotificationChannels();
        textToSpeech = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) {
                configureVoice();
                // Warm up TTS engine with silent utterance — some devices need this
                textToSpeech.speak(" ", TextToSpeech.QUEUE_FLUSH, null, "warmup");
                LogStore.append(IrisListeningService.this, "TTS", "Ready: " + textToSpeech.getDefaultEngine());
            } else {
                LogStore.append(IrisListeningService.this, "TTS", "FAILED (status " + status + ")");
            }
        });

        voskEngine = new VoskEngine();
        voskEngine.init(this, new VoskEngine.InitListener() {
            @Override public void onReady() {
                voskReady = true;
                LogStore.append(IrisListeningService.this, "VOSK", "Voice model ready");
                // Load the speaker model for voice verification (non-fatal).
                try { voskEngine.initSpeaker(IrisListeningService.this); } catch (Throwable ignored) { }
                // If we're currently beeping via the Android recognizer, switch to
                // silent, continuous Vosk wake immediately.
                if (isRunning && androidWakeActive && PHASE_WAKE.equals(phase)) {
                    handler.post(() -> {
                        LogStore.append(IrisListeningService.this, "WAKE", "Switching to silent Vosk wake");
                        startWakeDetection();
                    });
                }
            }
            @Override public void onError(String message) {
                voskReady = false;
                LogStore.append(IrisListeningService.this, "VOSK", "Model unavailable, using fallback: " + message);
            }
        });
        // Load the AI brain only if the user has opted in (off by default for
        // stability — some devices crash natively during on-device inference).
        llmAgent = new LlmAgent();
        serverMonitor.register(this);
        // Crash-guard: if the app was killed mid-inference last time (native LLM crash),
        // auto-disable the AI brain so we don't crash-loop. The rule-based engine still works.
        android.content.SharedPreferences llmGuard = getSharedPreferences("iris_llm_guard", MODE_PRIVATE);
        if (settings.aiEnabled() && llmGuard.getBoolean("inference_active", false)) {
            settings.setAiEnabled(false);
            llmGuard.edit().putBoolean("inference_active", false).apply();
            LogStore.append(this, "LLM", "AI brain crashed during last use — auto-disabled for stability");
        }
        if (settings.aiEnabled()) {
            new Thread(() -> {
                boolean ok = llmAgent.loadModel(this);
                llmReady = ok;
                LogStore.append(this, "LLM", ok ? "AI brain ready" : "No LLM model, using rule-based chat");
            }, "IRIS-LLM-Load").start();
        } else {
            llmReady = false;
            LogStore.append(this, "LLM", "AI brain disabled in Settings — using rule-based chat");
        }
        setupTriggers();
    }

    /** Register optional shake-to-wake and headset-button triggers (both off by default). */
    private void setupTriggers() {
        try {
            if (settings.shakeToWake()) {
                sensorManager = (android.hardware.SensorManager) getSystemService(SENSOR_SERVICE);
                android.hardware.Sensor accel = sensorManager == null ? null
                        : sensorManager.getDefaultSensor(android.hardware.Sensor.TYPE_ACCELEROMETER);
                if (accel != null) {
                    shakeListener = new android.hardware.SensorEventListener() {
                        @Override public void onSensorChanged(android.hardware.SensorEvent e) {
                            float x = e.values[0] / 9.81f, y = e.values[1] / 9.81f, z = e.values[2] / 9.81f;
                            double g = Math.sqrt(x * x + y * y + z * z);
                            if (g > 2.7) {
                                long now = System.currentTimeMillis();
                                if (now - lastShakeAt > 3000 && PHASE_WAKE.equals(phase)) {
                                    lastShakeAt = now;
                                    handler.post(() -> triggerTalk("shake"));
                                }
                            }
                        }
                        @Override public void onAccuracyChanged(android.hardware.Sensor s, int a) { }
                    };
                    sensorManager.registerListener(shakeListener, accel,
                            android.hardware.SensorManager.SENSOR_DELAY_UI);
                }
            }
        } catch (Throwable ignored) { }
        try {
            if (settings.headsetTrigger()) {
                mediaSession = new android.media.session.MediaSession(this, "IRIS");
                mediaSession.setCallback(new android.media.session.MediaSession.Callback() {
                    @Override public boolean onMediaButtonEvent(Intent mediaButtonIntent) {
                        android.view.KeyEvent ke = mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
                        if (ke != null && ke.getAction() == android.view.KeyEvent.ACTION_UP
                                && ke.getKeyCode() == android.view.KeyEvent.KEYCODE_HEADSETHOOK) {
                            long now = System.currentTimeMillis();
                            if (now - lastHeadsetHookAt < 700) {       // double-press
                                lastHeadsetHookAt = 0;
                                handler.post(() -> triggerTalk("headset"));
                            } else {
                                lastHeadsetHookAt = now;
                            }
                            return true;
                        }
                        return super.onMediaButtonEvent(mediaButtonIntent);
                    }
                });
                android.media.session.PlaybackState ps = new android.media.session.PlaybackState.Builder()
                        .setActions(android.media.session.PlaybackState.ACTION_PLAY_PAUSE)
                        .setState(android.media.session.PlaybackState.STATE_PAUSED, 0, 0f).build();
                mediaSession.setPlaybackState(ps);
                mediaSession.setActive(true);
            }
        } catch (Throwable ignored) { }
    }

    private void teardownTriggers() {
        try { if (sensorManager != null && shakeListener != null) sensorManager.unregisterListener(shakeListener); } catch (Throwable ignored) { }
        try { if (mediaSession != null) { mediaSession.setActive(false); mediaSession.release(); mediaSession = null; } } catch (Throwable ignored) { }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopIris("Listening switched off");
            return START_NOT_STICKY;
        }
        if (ACTION_STOP_RECORDING.equals(action)) {
            stopVoiceRecording();
            return START_STICKY;
        }
        if (ACTION_STOP_SPEAKING.equals(action)) {
            stopSpeaking();
            return START_STICKY;
        }
        if (ACTION_STOP_VIDEO.equals(action)) {
            LockedCaptureActivity.stopActive();
            return START_STICKY;
        }
        if (ACTION_CAPTURE_STARTED.equals(action)) {
            clearCameraLaunch();
            pauseListeningForCapture();
            return START_STICKY;
        }
        if (ACTION_CAPTURE_DONE.equals(action)) {
            clearCameraLaunch();
            String msg = intent == null ? null : intent.getStringExtra(EXTRA_TEXT);
            if (msg != null && !msg.isEmpty()) {
                // Only log what Android actually confirmed as saved (§6: never optimistic).
                try {
                    String m = msg.toLowerCase(Locale.ROOT);
                    boolean saved = m.startsWith("saved") || m.startsWith("screenshot saved");
                    String kind = m.contains("screenshot") ? "screenshot"
                            : m.contains("screen recording") ? "screen_recording"
                            : m.contains("video") ? "camera_video" : "capture";
                    String where = m.contains("pictures/iris") ? "Pictures/IRIS"
                            : m.contains("movies/iris") ? "Movies/IRIS" : "";
                    ledger().record(kind, saved ? ActionLedger.OK : ActionLedger.FAILED,
                            msg.replaceFirst("\\s*to .*$", ""), where, "", false);
                } catch (Throwable ignored) { }
                broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            }
            else rearmAfterAction();
            return START_STICKY;
        }
        if (ACTION_TALK.equals(action)) {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(LISTENING_NOTIFICATION, listeningNotification(),
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(LISTENING_NOTIFICATION, listeningNotification());
            }
            if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
                broadcastMessage("Microphone permission is required."); return START_STICKY;
            }
            if (!isRunning) {
                isRunning = true;
                recognitionLabel = resolveRecognitionLabel();
                microphoneLabel = configureAudioRoute();
                registerAudioChanges();
            }
            triggerTalk(intent.getStringExtra(EXTRA_TEXT));
            return START_STICKY;
        }
        if (ACTION_CONFIRM_CALL.equals(action)) {
            cancelCallNotification();
            placeCall(intent.getStringExtra(EXTRA_NAME), intent.getStringExtra(EXTRA_NUMBER));
            return START_NOT_STICKY;
        }
        if (ACTION_CANCEL_CALL.equals(action)) {
            cancelCallNotification();
            String name = intent.getStringExtra(EXTRA_NAME);
            LogStore.append(this, "CANCELLED", "Call to " + (name == null ? "contact" : name));
            speak(personalityLine("cancel", name));
            broadcastMessage("Call cancelled. Consider it unsaid.");
            rearmAfterAction();
            return START_STICKY;
        }
        if (ACTION_CHOOSE_CONTACT.equals(action)) {
            requestCallConfirmation(intent.getStringExtra(EXTRA_NAME), intent.getStringExtra(EXTRA_NUMBER));
            return START_STICKY;
        }

        if (ACTION_PROCESS_TEXT.equals(action)) {
            String text = intent == null ? null : intent.getStringExtra(EXTRA_TEXT);
            if (text == null || text.trim().isEmpty()) return START_STICKY;
            final String typed = text.trim();
            // Bring us to foreground so TTS/actions run reliably.
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(LISTENING_NOTIFICATION, listeningNotification(),
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(LISTENING_NOTIFICATION, listeningNotification());
            }
            if (!isRunning) {
                isRunning = true;
                recognitionLabel = resolveRecognitionLabel();
                microphoneLabel = configureAudioRoute();
                registerAudioChanges();
            }
            broadcastState(true, PHASE_COMMAND);
            handler.post(() -> handleCommand(typed));
            return START_STICKY;
        }

        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
            broadcastMessage("Microphone permission is required.");
            stopSelf();
            return START_NOT_STICKY;
        }

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(LISTENING_NOTIFICATION, listeningNotification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(LISTENING_NOTIFICATION, listeningNotification());
        }

        if (!isRunning) {
            isRunning = true;
            recognitionLabel = resolveRecognitionLabel();
            microphoneLabel = configureAudioRoute();
            registerAudioChanges();
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "iris:listening");
                wakeLock.acquire(60 * 60 * 1000L); // 1 hour max
            }
            LogStore.append(this, "START", settings.listeningMode() + " mode through " + microphoneLabel);
        }
        broadcastState(true, phase);
        beginForSelectedMode();
        return START_STICKY;
    }

    private void beginForSelectedMode() {
        String mode = settings.listeningMode();
        if (AppSettings.MODE_WAKE.equals(mode)) startWakeDetection();
        else startCommandRecognition();
    }

    private String resolveRecognitionLabel() {
        if (Build.VERSION.SDK_INT >= 31 && settings.preferOnDevice()
                && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) return "On-device speech ready";
        return settings.preferOnDevice() ? "System speech fallback" : "System speech service";
    }

    private boolean beepMuted;
    private long wakeEpoch;
    private long lastWakeAt;
    private final Runnable retryWake = () -> {
        if (isRunning && PHASE_WAKE.equals(phase)) startWakeDetection();
    };
    private void scheduleWakeRetry(long delay) {
        handler.removeCallbacks(retryWake);
        handler.postDelayed(retryWake, delay);
    }
    private void startWakeDetection() {
        if (!isRunning) return;
        final long epoch = ++wakeEpoch;
        handler.removeCallbacks(retryWake);
        destroyRecognizer();
        if (voskEngine != null) voskEngine.stop();
        ProfileStore.WakeProfile wake = new ProfileStore(this).getWakeProfile();
        phase = PHASE_WAKE;
        currentPhase = phase;
        broadcastState(true, phase);
        androidWakeActive = false;
        if (!wake.isReady() || !WakePolicy.owner(wake.voiceprint, wake.voiceprint, .99)) {
            updateListeningNotification("Wake unavailable: train your phrase and voice in Training");
            scheduleWakeRetry(3000);
            return;
        }
        if (!voskReady || voskEngine == null || !voskEngine.isSpeakerReady()) {
            updateListeningNotification("Wake unavailable: preparing offline voice verification");
            scheduleWakeRetry(2000);
            return;
        }
        if (audioManager != null && audioManager.isMusicActive()) {
            updateListeningNotification("Wake paused during media playback. Pause media to speak.");
            scheduleWakeRetry(1500);
            return;
        }
        restoreRecognizerBeep();
        updateListeningNotification("Owner wake ready: “" + wake.phrase + "”");
        voskEngine.startWakeDetection(wake.allPhrases(), new VoskEngine.WakeListener() {
            @Override public void onWakeDetected(float[] embedding) {
                if (epoch != wakeEpoch || !isRunning || !PHASE_WAKE.equals(phase)) return;
                boolean media = audioManager != null && audioManager.isMusicActive();
                long now = android.os.SystemClock.elapsedRealtime();
                double score = WakePolicy.cosine(embedding, new ProfileStore(IrisListeningService.this).getVoiceprint());
                boolean accepted = !media && now - lastWakeAt >= 3000 && isOwnerVoice(embedding);
                LogStore.append(IrisListeningService.this, "WAKE DECISION",
                        "engine=vosk media=" + media + " speaker=" + score + " threshold=" + voiceThreshold()
                        + " accepted=" + accepted);
                voskEngine.stop();
                if (!accepted) { scheduleWakeRetry(1500); return; }
                lastWakeAt = now;
                ++wakeEpoch;
                vibrate(45);
                String greet = wakeGreeting();
                broadcastMessage(greet);
                nextOutputMinor = true;
                speakThenRun(greet, IrisListeningService.this::startCommandRecognition);
            }
            @Override public void onError(String message) {
                if (epoch != wakeEpoch || !isRunning || !PHASE_WAKE.equals(phase)) return;
                LogStore.append(IrisListeningService.this, "WAKE UNAVAILABLE", message);
                scheduleWakeRetry(3000);
            }
        });
    }

    private long lastRejectCueAt = 0;
    private int consecutiveWakeRejects = 0;
    private boolean spellingCall = false;
    private int spellRetry = 0;
    private boolean googleCommandActive = false;
    private int commandRetries;
    private int recognizerGeneration;

    /**
     * Silence the recognizer's start/stop beep during continuous wake listening.
     * Only mutes when the user isn't playing media (so we never interrupt music).
     * Always restored via restoreRecognizerBeep() before speaking or leaving wake.
     */
    private void muteRecognizerBeep() {
        try {
            if (audioManager == null) audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager == null || beepMuted) return;
            if (audioManager.isMusicActive()) return; // don't fight the user's audio
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0);
            audioManager.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0);
            audioManager.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_MUTE, 0);
            beepMuted = true;
        } catch (Exception ignored) { }
    }

    private void restoreRecognizerBeep() {
        try {
            if (audioManager == null || !beepMuted) return;
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0);
            audioManager.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_UNMUTE, 0);
            audioManager.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_UNMUTE, 0);
            beepMuted = false;
        } catch (Exception ignored) { }
    }

    private void startCommandRecognition() {
        commandWindowOpenedAt = System.currentTimeMillis();
        // Server STT (Whisper) when server mode is on, online and healthy; else on-device.
        if (serverMonitor.shouldUseServer(settings) && settings.serverStt()) {
            startServerSttCommand();
            return;
        }
        startCommandRecognitionLocal();
    }

    /** Short beep so the user knows exactly when IRIS is listening for a command. */
    private void playListeningEarcon() {
        try {
            android.media.ToneGenerator tg = new android.media.ToneGenerator(
                    android.media.AudioManager.STREAM_MUSIC, 60);
            tg.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 120);
            handler.postDelayed(tg::release, 250);
        } catch (Exception ignored) { }
    }

    /** Record the command locally and send it to the server's Whisper endpoint; fall back on failure. */
    private void startServerSttCommand() {
        stopWakeEngine();
        if (voskEngine != null) voskEngine.stop();
        androidWakeActive = false;
        restoreRecognizerBeep();
        phase = PHASE_COMMAND;
        currentPhase = phase;
        broadcastState(true, phase);
        updateListeningNotification("Listening (server)\u2026");
        LogStore.append(this, "LISTEN", "Command window open (server Whisper)");
        final TimedRecorder rec = new TimedRecorder();
        commandTimeout = () -> { if (isRunning && PHASE_COMMAND.equals(phase)) rec.stop(); };
        handler.postDelayed(commandTimeout, 9000);
        rec.record(6000, new TimedRecorder.Listener() {
            @Override public void onLevel(float level) { }
            @Override public void onComplete(short[] audio) {
                if (commandTimeout != null) { handler.removeCallbacks(commandTimeout); commandTimeout = null; }
                new Thread(() -> {
                    long t0 = System.currentTimeMillis();
                    String text = new ServerClient(settings.serverUrl(), settings.serverToken())
                            .transcribe(audio, 4000, 25000);
                    long dt = System.currentTimeMillis() - t0;
                    handler.post(() -> {
                        if (text != null) {
                            serverMonitor.recordSuccess(dt);
                            broadcastTranscript(text);
                            LogStore.append(IrisListeningService.this, "HEARD CMD", text + " (server)");
                            recordTranscript(text);
                            handleCommand(text);
                        } else {
                            serverMonitor.recordFailure();
                            LogStore.append(IrisListeningService.this, "SERVER", "transcribe miss \u2192 local STT");
                            startCommandRecognitionLocal();
                        }
                    });
                }, "IRIS-Whisper").start();
            }
            @Override public void onError(String message) {
                if (commandTimeout != null) { handler.removeCallbacks(commandTimeout); commandTimeout = null; }
                startCommandRecognitionLocal();
            }
        });
    }

    private void startCommandRecognitionLocal() {
        commandRetries = 0;
        stopWakeEngine();
        if (voskEngine != null) voskEngine.stop();
        androidWakeActive = false;
        restoreRecognizerBeep();
        phase = PHASE_COMMAND;
        currentPhase = phase;
        broadcastState(true, phase);
        updateListeningNotification("Listening\u2026");
        // The ready cue belongs to onReadyForSpeech, not before recognizer startup.

        // Prefer Google STT for accuracy; Vosk is the offline fallback.
        if (settings.googleSttForCommands() && SpeechRecognizer.isRecognitionAvailable(this)) {
            startAndroidCommandRecognition();
            return;
        }
        startVoskCommandRecognition();
    }

    /** Offline Vosk streaming STT for commands (used when Google STT is off/unavailable). */
    private void startVoskCommandRecognition() {
        destroyRecognizer();
        googleCommandActive = false;
        if (!(voskReady && voskEngine != null)) {
            broadcastMessage("No speech recognizer is ready. Check the system speech service or download the offline model in Settings.");
            rearmAfterAction(); return;
        }
        recognitionLabel = "Offline Indian English (Vosk)";
        broadcastState(true, phase);
        final boolean[] handled = {false};
        commandTimeout = () -> {
            if (isRunning && PHASE_COMMAND.equals(phase) && !handled[0]) {
                voskEngine.stop();
                broadcastMessage("No command heard. Going back to sleep.");
                LogStore.append(this, "TIMEOUT", "Command window expired");
                rearmAfterAction();
            }
        };
        // Settle delay: let the wake recognizer's mic fully release before we open a new AudioRecord.
        handler.postDelayed(() -> {
            if (!isRunning || !PHASE_COMMAND.equals(phase)) return;
            LogStore.append(this, "LISTEN", "Command window open (Vosk)");
            handler.postDelayed(commandTimeout, 15_000);
            voskEngine.startListening(new VoskEngine.SttListener() {
                @Override public void onPartial(String text) {
                    if (!text.isEmpty()) broadcastTranscript(text);
                }
                @Override public void onFinal(String text) {
                    if (handled[0] || text.isEmpty()) return;
                    handled[0] = true;
                    if (commandTimeout != null) { handler.removeCallbacks(commandTimeout); commandTimeout = null; }
                    voskEngine.stop();
                    LogStore.append(IrisListeningService.this, "HEARD CMD", text);
                    recordTranscript(text);
                    handleCommand(text);
                }
                @Override public void onError(String message) {
                    if (handled[0]) return;
                    handled[0] = true;
                    if (commandTimeout != null) { handler.removeCallbacks(commandTimeout); commandTimeout = null; }
                    LogStore.append(IrisListeningService.this, "VOSK STT ERROR", message);
                    rearmAfterAction();
                }
            });
            playListeningEarcon();
        }, 350);
    }

    /** Command capture via Android's (Google) SpeechRecognizer — best accuracy. */
    private void startAndroidCommandRecognition() {
        if (!isRunning || !PHASE_COMMAND.equals(phase)) return;
        if (voskEngine != null) voskEngine.stop();
        createRecognizer();
        if (recognizer == null) { startVoskCommandRecognition(); return; }
        googleCommandActive = true;
        LogStore.append(this, "LISTEN", "Command: " + recognitionLabel + ", language=" + settings.resolvedLanguageTag());
        broadcastState(true, phase);
        recognizerIntent = baseRecognizerIntent();
        handler.postDelayed(this::startRecognizerSafely, 180);
        commandTimeout = () -> { if (isRunning && PHASE_COMMAND.equals(phase)) { broadcastMessage("No command heard. Going back to sleep."); LogStore.append(this, "TIMEOUT", "Command window expired"); rearmAfterAction(); } };
        handler.postDelayed(commandTimeout, 20_000);
    }

    private void startConfirmationRecognition() {
        phase = PHASE_CONFIRM;
        currentPhase = phase;
        broadcastState(true, phase);
        createRecognizer();
        if (recognizer == null) return;
        recognizerIntent = baseRecognizerIntent();
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        handler.postDelayed(this::startRecognizerSafely, 350);
        confirmTimeout = () -> { if (isRunning && PHASE_CONFIRM.equals(phase)) { broadcastMessage("No answer. Call cancelled."); LogStore.append(this, "TIMEOUT", "Confirmation expired for " + (pendingName == null ? "contact" : pendingName)); cancelCallNotification(); rearmAfterAction(); } };
        handler.postDelayed(confirmTimeout, 15_000);
    }

    private Intent baseRecognizerIntent() {
        Intent speech = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speech.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        speech.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, settings.preferOnDevice());
        speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE, settings.resolvedLanguageTag());
        speech.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        if (Build.VERSION.SDK_INT >= 33) {
            speech.putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS,
                    new ArrayList<>(java.util.Arrays.asList("IRIS", "call", "Maa", "Papa",
                            "take a screenshot", "record video", "set an alarm", "set a timer",
                            "remind me", "torch", "flashlight", "WhatsApp", "volume", "notifications")));
        }
        return speech;
    }

    private void createRecognizer() {
        destroyRecognizer();
        try {
            if (Build.VERSION.SDK_INT >= 31 && settings.preferOnDevice()
                    && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
                recognitionLabel = "On-device speech";
            } else if (SpeechRecognizer.isRecognitionAvailable(this)) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
                recognitionLabel = "System speech service";
            }
            if (recognizer != null) recognizer.setRecognitionListener(sessionListener(recognizerGeneration));
        } catch (Exception error) {
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
                recognizer.setRecognitionListener(sessionListener(recognizerGeneration));
                recognitionLabel = "System speech fallback";
            }
        }
    }

    private void startRecognizerSafely() {
        if (!isRunning || recognizer == null) return;
        try { recognizer.startListening(recognizerIntent); }
        catch (Exception error) {
            LogStore.append(this, "ERROR", "Speech start failed: " + error.getMessage());
            onError(SpeechRecognizer.ERROR_CLIENT);
        }
    }

    /** Discard callbacks from recognizers that have already been replaced or cancelled. */
    private RecognitionListener sessionListener(final int generation) {
        return new RecognitionListener() {
            private boolean current() { return isRunning && generation == recognizerGeneration; }
            @Override public void onReadyForSpeech(Bundle b) { if (current()) IrisListeningService.this.onReadyForSpeech(b); }
            @Override public void onBeginningOfSpeech() { if (current()) IrisListeningService.this.onBeginningOfSpeech(); }
            @Override public void onRmsChanged(float r) { if (current()) IrisListeningService.this.onRmsChanged(r); }
            @Override public void onBufferReceived(byte[] b) { }
            @Override public void onEndOfSpeech() { if (current()) IrisListeningService.this.onEndOfSpeech(); }
            @Override public void onError(int e) { if (current()) IrisListeningService.this.onError(e); }
            @Override public void onResults(Bundle b) { if (current()) IrisListeningService.this.onResults(b); }
            @Override public void onPartialResults(Bundle b) { if (current()) IrisListeningService.this.onPartialResults(b); }
            @Override public void onEvent(int e, Bundle b) { }
        };
    }

    private void retryUnclearCommand(String prompt) {
        if (commandTimeout != null) { handler.removeCallbacks(commandTimeout); commandTimeout = null; }
        destroyRecognizer();
        googleCommandActive = false;
        if (commandRetries++ < 1) {
            broadcastMessage(prompt);
            speakThenRun(prompt, this::startAndroidCommandRecognition);
        } else {
            String message = "I still couldn't hear that clearly. Try Tap to talk, English India in Settings, and check which microphone is selected.";
            broadcastMessage(message);
            // Offer the "IRIS heard / I meant" card so the next attempt can be learned.
            if (lastHeardTranscript != null && !lastHeardTranscript.trim().isEmpty()) {
                requestCorrection(lastHeardTranscript);
            }
            speakThenRun(message, this::rearmAfterAction);
        }
    }

    /** Guarded entry point: no command-handling error may crash the app. */
    private void handleCommand(String heard) {
        if (heard != null && !heard.trim().isEmpty()) {
            String hl = heard.trim().toLowerCase(Locale.ROOT);
            if (!REPEAT_ACTION_PATTERN.matcher(hl).matches() && !LAST_ACTION_PATTERN.matcher(hl).matches()
                    && !WRONG_ACTION_PATTERN.matcher(hl).matches()) {
                lastUserCommand = heard.trim();   // remember only real, repeatable commands
            }
        }
        if (spellingCall) {
            try { handleSpellInput(heard); }
            catch (Throwable t) { spellingCall = false; LogStore.append(this, "SPELL", "error: " + t); rearmAfterAction(); }
            return;
        }
        if (pendingPlan != null) {
            try { handleClarificationAnswer(heard); }
            catch (Throwable t) { pendingPlan = null; LogStore.append(this, "CLARIFY", "error: " + t); rearmAfterAction(); }
            return;
        }
        if (smsCompose != null) {
            try { handleSmsComposeInput(heard); }
            catch (Throwable t) { smsCompose = null; LogStore.append(this, "SMS", "compose error: " + t); rearmAfterAction(); }
            return;
        }
        try {
            handleCommandInner(heard);
        } catch (Throwable t) {
            LogStore.append(this, "COMMAND ERROR",
                    "Crash handling command: " + t + " | heard: " + heard);
            try {
                broadcastMessage("Sorry, something went wrong.");
                speakThenRun("Sorry, something went wrong.", this::rearmAfterAction);
            } catch (Throwable ignored) {
                rearmAfterAction();
            }
        }
    }

    private void handleCommandInner(String heard) {
        if (commandTimeout != null) { handler.removeCallbacks(commandTimeout); commandTimeout = null; }
        String clean = heard == null ? "" : heard.trim();
        if (clean.isEmpty()) {
            rearmAfterAction();
            return;
        }
        clean = stripFiller(clean);   // drop "can you / please / iris ..." wrappers
        if (clean.isEmpty()) {
            rearmAfterAction();
            return;
        }
        // Map the user's learned pronunciations back to canonical command words.
        clean = new ProfileStore(this).canonicalize(clean);
        // Immediate cancel commands
        String lower = clean.toLowerCase(Locale.ROOT);
        if (lower.matches("^(stop|cancel|shut up|quiet|go away|never mind|nevermind|nahi|ruk|bas)$")) {
            LogStore.append(this, "CANCELLED", "Voice cancel: " + clean);
            broadcastMessage("Okay, going quiet.");
            speak("Okay.");
            rearmAfterAction();
            return;
        }

        LogStore.append(this, "HEARD", clean);
        broadcastTranscript(clean);

        if (clean.matches("(?i)^(?:reply to (?:a |my |the )?notifications?|open notification replies)$")) {
            KeyguardManager keyguard = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            if (keyguard == null || keyguard.isKeyguardLocked()) {
                reply("Please unlock your phone to review notification replies.");
            } else {
                startActivity(new Intent(this, NotificationReplyActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                reply("Choose a conversation and review your reply before sending.");
            }
            return;
        }

        AppRequest appRequest = AppRequest.parse(clean);
        if (appRequest != null) {
            handleAppIntegration(appRequest);
            return;
        }

        // ── Phase 2: structured understanding, used ONLY to ask for a missing detail. ──
        // Complete commands keep flowing through the proven keyword router below, unchanged.
        Plan plan = IntentParser.parse(clean);
        if (!plan.isUnknown() && !plan.isComplete()) {
            String question = IntentParser.clarifyQuestion(plan);
            if (!question.isEmpty()) {
                pendingPlan = plan;
                LogStore.append(this, "CLARIFY", plan.intent() + " needs " + plan.firstMissing());
                broadcastMessage(question);
                nextOutputMinor = true;              // a question isn't an action result
                speakThenRun(question, this::startCommandRecognition);
                return;
            }
        }

        // 1. Check trained phrases first
        ProfileStore store = new ProfileStore(this);
        ProfileStore.Match learned = store.findMatch(clean);
        if (learned != null) {
            LogStore.append(this, "MATCH", "Learned phrase → " + learned.contactName
                    + " (" + Math.round(learned.confidence * 100) + "%)");
            requestCallConfirmation(learned.contactName, learned.phoneNumber);
            return;
        }

        String normalized = ProfileStore.normalize(clean);

        // 1b. Check memory corrections
        MemoryStore.Memory correction = MemoryStore.findCorrection(this, clean);
        if (correction != null && correction.detail != null && !correction.detail.isEmpty()) {
            LogStore.append(this, "MEMORY", "Correction: " + clean + " → " + correction.value);
            requestCallConfirmation(correction.value, correction.detail);
            return;
        }

        // 2. Relationship resolution ("call my wife", "ring my brother")
        String[] relationship = store.resolveRelationship(normalized.replaceAll("^(?:call|dial|phone|ring|talk to|reach)\\s+", ""));
        if (relationship != null && relationship[0].length() > 0 && relationship[1].length() > 0) {
            LogStore.append(this, "RELATIONSHIP", "Resolved \u2192 " + relationship[0]);
            requestCallConfirmation(relationship[0], relationship[1]);
            return;
        }

        // 2b. Memory voice commands (remember/forget/recall)
        Matcher memoryMatcher = MEMORY_PATTERN.matcher(normalized);
        if (memoryMatcher.matches()) {
            handleRemember(memoryMatcher.group(1).trim());
            return;
        }
        if (FORGET_PATTERN.matcher(normalized).matches()) {
            handleForget();
            return;
        }
        Matcher recallM = RECALL_PATTERN.matcher(normalized);
        if (recallM.matches()) {
            handleRecall(recallM.group(1));
            return;
        }

        // 3. Call history queries
        if (HISTORY_PATTERN.matcher(normalized).matches()) {
            handleHistory(normalized, store);
            return;
        }

        // 4. Quick actions (time, battery, stop, help) — lenient matching so
        // "tell me the time", "what's the time", "time now" all work
        if (isQuickAction(normalized)) {
            handleQuickAction(normalized);
            return;
        }

        // 5. Redial / call back
        if (REDIAL_PATTERN.matcher(normalized).matches()) {
            handleRedial(store);
            return;
        }

        // Spell a contact's name letter-by-letter (helps when speech mis-hears names)
        if (SPELL_CALL_PATTERN.matcher(normalized).matches()) { beginSpellCall(); return; }

        // 5b. Open an installed app ("open WhatsApp", "launch camera")
        Matcher openMatcher = OPEN_APP_PATTERN.matcher(normalized);
        if (normalized.matches("^(?:open|launch) (?:the )?(?:front |back |rear )?camera (?:and )?(?:take|click|capture) (?:a )?(?:photo|picture|selfie)$")) {
            handleTakePhoto(normalized.contains("front") || normalized.contains("selfie") ? "front" : "back");
            return;
        }
        if (openMatcher.matches() && !containsCallVerb(normalized)) {
            if (openMatcher.group(1).trim().equals("camera")) {
                Intent secure = new Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    if (secure.resolveActivity(getPackageManager()) != null) {
                        startActivity(secure);
                        reply("Requested the lock-screen camera. To capture automatically, say take a photo.");
                    } else reply("No secure camera app is available. Say take a photo to use IRIS's camera.");
                } catch (Exception e) { reply("Android couldn't open the camera app. Say take a photo to use IRIS's camera."); }
                return;
            }
            if (openApp(openMatcher.group(1).trim())) return;
            // if no app matched, fall through to other handlers / chat
        }

        // 5c. Read phone notifications ("read my notifications", "who texted me")
        if (CLEAR_NOTIFICATION_PATTERN.matcher(normalized).matches()) {
            boolean dismissed = IrisNotificationListener.dismissAll();
            NotificationStore.clearAll(this);
            String msg = dismissed ? "Cleared your notifications." : "Cleared the ones I had. Grant notification access to clear the rest.";
            broadcastMessage(msg);
            speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "NOTIF", "Cleared (system dismissed=" + dismissed + ")");
            return;
        }
        if (NOTIFICATION_PATTERN.matcher(normalized).matches() && !containsCallVerb(normalized)) {
            handleNotifications(normalized);
            return;
        }

        // Version / what's-new
        if (VERSION_PATTERN.matcher(normalized).matches()) { handleVersion(); return; }
        if (WHATSNEW_PATTERN.matcher(normalized).matches()) { handleWhatsNew(); return; }

        // Server mode voice toggle
        if (normalized.matches("^(go online|use (?:the )?server|server mode on|online mode)$")) {
            settings.setServerModeEnabled(true);
            String m = serverMonitor.isOnline()
                    ? "Online brain on." : "Server mode on. I'll use it once you're connected.";
            broadcastMessage(m); speakThenRun(m, this::rearmAfterAction);
            LogStore.append(this, "SERVER", "enabled by voice"); return;
        }
        if (normalized.matches("^(go offline|offline mode|server mode off|use offline)$")) {
            settings.setServerModeEnabled(false);
            broadcastMessage("Offline mode."); speakThenRun("Offline mode on.", this::rearmAfterAction);
            LogStore.append(this, "SERVER", "disabled by voice"); return;
        }

        // 5d. Weather / forecast
        if (WEATHER_PATTERN.matcher(normalized).matches()) {
            handleWeather(normalized);
            return;
        }

        // 5e. Location ("where am I", "my location")
        if (LOCATION_PATTERN.matcher(normalized).matches() && !containsCallVerb(normalized)) {
            handleLocation();
            return;
        }

        // 5f. Messaging & device actions (match on original text to keep message body)
        Matcher waM = WHATSAPP_PATTERN.matcher(clean);
        if (waM.matches()) { handleWhatsApp(waM.group(1).trim(), waM.group(2).trim()); return; }
        Matcher smsM = SMS_PATTERN.matcher(clean);
        if (smsM.matches()) { handleSendSms(smsM.group(1).trim(), smsM.group(2).trim()); return; }
        Matcher shareM = SHARE_PATTERN.matcher(clean);
        if (shareM.matches() && !containsCallVerb(normalized)) {
            handleShareToContact(shareM.group(1).trim(), shareM.group(2).trim());
            return;
        }
        // Natural texting without "saying" — only fires if the recipient resolves to a contact.
        Matcher looseSmsM = SMS_LOOSE_PATTERN.matcher(clean);
        if (looseSmsM.matches()) {
            String rest = looseSmsM.group(1).trim();
            if (tryFlexibleSms(rest)) return;
            // Verb + a recipient but NO message → start the guided compose flow.
            if (!isSelf(rest) && resolveNumber(rest) != null) { beginSms(rest, null); return; }
        }
        Matcher smsStartM = SMS_START_PATTERN.matcher(clean);
        if (smsStartM.matches()) {
            beginSms(smsStartM.group(1) == null ? null : smsStartM.group(1).trim(), null);
            return;
        }
        Matcher remM = REMINDER_PATTERN.matcher(clean);
        if (remM.matches()) { handleReminder(remM.group(1).trim(), remM.group(2).trim(), remM.group(3).trim()); return; }
        Matcher almM = ALARM_PATTERN.matcher(clean);
        if (almM.matches()) { handleSetAlarm(almM.group(1).trim()); return; }
        Matcher tmrM = TIMER_PATTERN.matcher(clean);
        if (tmrM.matches()) { handleSetTimer(tmrM.group(1).trim()); return; }
        Matcher torchM = TORCH_PATTERN.matcher(normalized);
        if (torchM.matches()) {
            String s = torchM.group(1) != null ? torchM.group(1) : torchM.group(2);
            handleTorch("on".equalsIgnoreCase(s));
            return;
        }
        if (MEDIA_CONTROL_PATTERN.matcher(normalized).matches()) { handleMediaControl(normalized); return; }
        if (VOLUME_PATTERN.matcher(normalized).matches()) { handleVolume(normalized); return; }
        Matcher volSetM = VOLUME_SET_PATTERN.matcher(normalized);
        if (volSetM.matches()) { handleSetVolumePercent(volSetM.group(1)); return; }
        if (WRONG_ACTION_PATTERN.matcher(normalized).matches()) {
            try { recognitionStats().recordWrongAction(); } catch (Throwable ignored) { }
            LogStore.append(this, "WRONG ACTION", "user reported: " + lastUserCommand);
            String m = "Sorry about that. I've noted it — tap the notification to tell me what you meant.";
            broadcastMessage(m);
            if (lastUserCommand != null && !lastUserCommand.trim().isEmpty()) requestCorrection(lastUserCommand);
            speakThenRun(m, this::rearmAfterAction);
            return;
        }
        if (LAST_ACTION_PATTERN.matcher(normalized).matches()) {
            ActionLedger.Record r = null;
            try { r = ledger().last(); } catch (Throwable ignored) { }
            String m;
            if (r != null) {
                m = "The last thing I did was " + ActionLedger.spoken(r)
                        + (r.location.isEmpty() ? "." : ", saved to " + r.location + ".");
            } else if (lastActionSummary != null && !lastActionSummary.trim().isEmpty()) {
                m = "The last thing I did was: " + lastActionSummary;
            } else {
                m = "I haven't done anything yet.";
            }
            broadcastMessage(m); speakThenRun(m, this::rearmAfterAction); return;
        }
        if (WHERE_SAVED_PATTERN.matcher(normalized).matches()) { handleWhereSaved(); return; }
        Matcher sendLast = SEND_LAST_PATTERN.matcher(normalized);
        if (sendLast.matches()) { handleSendLast(sendLast.group(1)); return; }
        if (UNDO_PATTERN.matcher(normalized).matches()) { handleUndo(); return; }
        if (TIMELINE_PATTERN.matcher(normalized).matches()) {
            int n = 0;
            try { n = ledger().count(); } catch (Throwable ignored) { }
            String m = n == 0 ? "I haven't recorded any actions yet."
                    : "I've recorded " + n + (n == 1 ? " action" : " actions")
                      + ". The most recent: " + ActionLedger.spoken(ledger().last())
                      + ". You can see the full list in Settings.";
            broadcastMessage(m); speakThenRun(m, this::rearmAfterAction); return;
        }
        if (REPEAT_ACTION_PATTERN.matcher(normalized).matches()) {
            if (lastUserCommand == null || lastUserCommand.trim().isEmpty()) {
                String m = "There's nothing to repeat yet."; broadcastMessage(m); speakThenRun(m, this::rearmAfterAction); return;
            }
            final String cmd = lastUserCommand;
            handler.post(() -> handleCommand(cmd));
            return;
        }
        if (STOP_RECORD_PATTERN.matcher(normalized).matches()) { stopVoiceRecording(); return; }
        if (SCREEN_REC_STOP_PATTERN.matcher(normalized).matches()) {
            try { startService(new Intent(this, ScreenCaptureService.class).setAction(ScreenCaptureService.ACTION_STOP)); } catch (Exception ignored) { }
            return;
        }
        if (SCREEN_REC_PATTERN.matcher(normalized).matches()) { beginScreenRecording(parseDuration(normalized, 60)); return; }
        Matcher photoM = PHOTO_PATTERN.matcher(normalized);
        if (photoM.matches()) { handleTakePhoto(photoM.group(1)); return; }
        if (SCREENSHOT_PATTERN.matcher(normalized).matches()) { handleScreenshot(); return; }
        if (VIDEO_RECORD_PATTERN.matcher(normalized).matches()) {
            beginVideoRecording(parseDuration(normalized, 60), extractCamWord(normalized)); return;
        }
        if (START_RECORDING_PATTERN.matcher(normalized).matches()) {
            beginVideoRecording(parseDuration(normalized, 60), "back"); return;
        }
        if (VOICE_RECORD_PATTERN.matcher(normalized).matches()) {
            beginVoiceRecording(parseDuration(normalized, 60), extractMicWord(normalized)); return;
        }
        // Bare "record" with none of the specific keywords above — default to back-camera video
        // (same default as "start recording") instead of silently doing nothing.
        if (GENERIC_RECORD_PATTERN.matcher(normalized).matches()) {
            beginVideoRecording(parseDuration(normalized, 60), "back"); return;
        }
        if (BT_DEVICE_PATTERN.matcher(normalized).matches()) { handleBluetoothQuery(); return; }
        if (STATUS_PATTERN.matcher(normalized).matches()) { handlePhoneStatus(); return; }
        Matcher modeQ = MODE_QUERY_PATTERN.matcher(normalized);
        if (modeQ.matches()) { handleModeQuery(modeQ.group(1)); return; }
        Matcher modeS = MODE_SET_PATTERN.matcher(normalized);
        if (modeS.matches()) { handleModeSet(modeS.group(1), modeS.group(2), modeS.group(3)); return; }
        if (DND_OFF_PATTERN.matcher(normalized).matches()) { handleDnd(false); return; }
        if (DND_PATTERN.matcher(normalized).matches()) { handleDnd(true); return; }
        if (SILENT_PATTERN.matcher(normalized).matches()) { handleRinger(AudioManager.RINGER_MODE_SILENT); return; }
        if (VIBRATE_PATTERN.matcher(normalized).matches()) { handleRinger(AudioManager.RINGER_MODE_VIBRATE); return; }
        if (NORMAL_RINGER_PATTERN.matcher(normalized).matches()) { handleRinger(AudioManager.RINGER_MODE_NORMAL); return; }
        Matcher playM = PLAY_SONG_PATTERN.matcher(clean);
        if (playM.matches() && !containsCallVerb(normalized)) { handlePlaySong(playM.group(1).trim()); return; }
        Matcher connM = CONNECTIVITY_PATTERN.matcher(normalized);
        if (connM.matches()) { handleConnectivity(connM.group(2)); return; }
        Matcher webM = WEBSEARCH_PATTERN.matcher(clean);
        if (webM.matches()) { handleWebSearch(webM.group(1).trim()); return; }
        Matcher navM = NAV_PATTERN.matcher(clean);
        if (navM.matches() && !containsCallVerb(normalized)) { handleNavigate(navM.group(1).trim()); return; }
        Matcher emailM = EMAIL_PATTERN.matcher(clean);
        if (emailM.matches()) {
            handleEmail(emailM.group(1).trim(), emailM.group(2) == null ? "" : emailM.group(2).trim());
            return;
        }
        Matcher calM = CALENDAR_PATTERN.matcher(clean);
        if (calM.matches()) {
            handleCalendar(calM.group(1).trim(), calM.group(2) == null ? null : calM.group(2).trim());
            return;
        }

        // 6. Call patterns (English)
        Matcher matcher = CALL_PATTERN.matcher(normalized);
        String requested = null;
        if (matcher.matches()) {
            requested = matcher.group(1).trim();
        }

        // 7. Hindi/Hinglish call patterns
        if (requested == null) {
            Matcher hindiMatcher = HINDI_CALL_PATTERN.matcher(normalized);
            if (hindiMatcher.matches()) requested = hindiMatcher.group(1).trim();
        }

        // 8. No pattern matched
        if (requested == null) {
            // Not a call command — treat as conversation
            handleChat(clean, normalized, store);
            return;
        }

        // Guard: "call me / myself / my phone" — can't call the owner
        if (requested.matches("(?i)^(?:me|myself|my\\s*self|my\\s+phone|my\\s+number)$")) {
            broadcastMessage("That's you — I can't call you. Tell me who to call.");
            speakThenRun("That's you! Who would you like me to call?", this::rearmAfterAction);
            LogStore.append(this, "CALL", "Refused self-call");
            return;
        }
        // Direct dial: "call nine eight seven…" or "call 9876543210"
        String dialNumber = extractPhoneNumber(requested);
        if (dialNumber != null) {
            pendingCandidates = null;
            requestCallConfirmation(dialNumber, dialNumber, "Call " + speakableNumber(dialNumber) + "?");
            return;
        }
        // Guard: empty or too-short name — ask who instead of matching randomly
        if (requested.length() < 2) {
            broadcastMessage("Who would you like me to call?");
            speakThenRun("Who would you like me to call?", this::startCommandRecognition);
            LogStore.append(this, "CALL", "No name given");
            return;
        }

        List<ContactMatch> candidates = resolveContacts(requested);
        if (candidates.isEmpty()) {
            broadcastMessage(hasPermission(Manifest.permission.READ_CONTACTS)
                    ? "I couldn't confidently match “" + requested + "”. Teach me once."
                    : "Contacts permission is needed to find “" + requested + "”.");
            LogStore.append(this, "NO MATCH", requested);
            requestCorrection(clean);
            rearmAfterAction();
            return;
        }
        ContactMatch first = candidates.get(0);
        // Verbally confirm the best match; "no" walks to the next candidate.
        pendingCandidates = candidates;
        pendingCandidateIndex = 0;
        confirmCandidate(0);
    }

    /** Verbally confirm a contact candidate by index; "no" advances to the next. */
    private void confirmCandidate(int index) {
        if (pendingCandidates == null || index >= pendingCandidates.size()) {
            cancelCallNotification();
            broadcastMessage("Okay, I won't call anyone.");
            speakThenRun("Okay, I won't call anyone.", this::rearmAfterAction);
            pendingCandidates = null;
            return;
        }
        pendingCandidateIndex = index;
        ContactMatch c = pendingCandidates.get(index);
        boolean multiple = pendingCandidates.size() > 1;
        String prompt = multiple ? "Did you mean " + c.name + "?" : "Call " + c.name + "?";
        requestCallConfirmation(c.name, c.number, prompt);
    }

    /**
     * Conversational handler — makes IRIS a chatbot, not just a dialer.
     * Answers questions from memory, greets, and chats. Only calls when
     * there's an explicit call command (handled earlier in handleCommand).
     */
    private final java.util.Random chatRandom = new java.util.Random();

    /** Pick a random response from variants for natural variety. */
    private String pick(String... options) {
        return options[chatRandom.nextInt(options.length)];
    }

    private void handleChat(String original, String normalized, ProfileStore store) {
        LogStore.append(this, "CHAT", original);

        // Identity questions: answer instantly and deterministically. These are
        // handled well by the rule-based replies and don't need the (slower) AI —
        // routing them here also sidesteps odd model behaviour on these prompts.
        if (normalized.matches(".*\\b(who am i|who are you|what are you|your name"
                + "|what.?s my name|what is my name|who made you|who created you|who built you)\\b.*")) {
            ruleBasedChat(original, normalized, store);
            return;
        }

        // Phase 5: give the local planner a chance BEFORE falling back to conversation.
        // Nothing above matched, so this can only add capability. Opt-in (AI enabled) and
        // strictly validated — an invalid or doubtful plan is ignored.
        if (settings.aiEnabled() && llmReady && llmAgent != null
                && tryLocalPlanner(original, normalized, store)) return;

        // Server brain first — only when server mode is on, online, and healthy.
        if (serverMonitor.shouldUseServer(settings)) {
            broadcastMessage("Thinking\u2026");
            final String msg = original;
            new Thread(() -> {
                long t0 = System.currentTimeMillis();
                String reply = new ServerClient(settings.serverUrl(), settings.serverToken())
                        .chat(msg, conversation.turnsJson(), profileJson(), 4000, 25000);
                long dt = System.currentTimeMillis() - t0;
                handler.post(() -> {
                    if (reply != null && !reply.isEmpty()) {
                        serverMonitor.recordSuccess(dt);
                        try {
                            conversation.add(msg, reply.replaceAll("\\[.*?\\]", "").trim());
                            handleLlmOutput(reply, store);
                        } catch (Throwable t) {
                            offlineChat(msg, normalized, store);
                        }
                    } else {
                        serverMonitor.recordFailure();
                        LogStore.append(IrisListeningService.this, "SERVER", "chat miss \u2192 offline");
                        offlineChat(msg, normalized, store);
                    }
                });
            }, "IRIS-Server-Chat").start();
            return;
        }

        offlineChat(original, normalized, store);
    }

    /** Compact profile block sent to the server (persona + preferred name + tone). */
    private org.json.JSONObject profileJson() {
        org.json.JSONObject o = new org.json.JSONObject();
        try {
            String pn = PersonalProfile.preferredName(this);
            if (pn != null) o.put("preferred_name", pn);
            o.put("tone", settings.personality());
            String ctx = PersonalProfile.contextForAI(this);
            if (ctx != null && !ctx.isEmpty()) o.put("context", ctx);
        } catch (Throwable ignored) { }
        return o;
    }

    /** On-device chat: the LLM if ready, else the rule-based engine. */
    private void offlineChat(String original, String normalized, ProfileStore store) {
        if (llmReady && llmAgent != null && llmAgent.isReady()) {
            broadcastMessage("Thinking\u2026");
            new Thread(() -> {
                android.content.SharedPreferences guard =
                        getSharedPreferences("iris_llm_guard", MODE_PRIVATE);
                guard.edit().putBoolean("inference_active", true).apply();
                String llmOut = llmAgent.generateReply(this, original, conversation.transcript());
                guard.edit().putBoolean("inference_active", false).apply();
                handler.post(() -> {
                    if (llmOut == null || llmOut.isEmpty()) {
                        ruleBasedChat(original, normalized, store);
                    } else {
                        try {
                            conversation.add(original, llmOut.replaceAll("\\[.*?\\]", "").trim());
                            handleLlmOutput(llmOut, store);
                        } catch (Throwable t) {
                            LogStore.append(this, "LLM ERROR",
                                    "reply handling crashed: " + t + " | reply was: " + llmOut);
                            ruleBasedChat(original, normalized, store);
                        }
                    }
                });
            }, "IRIS-LLM-Gen").start();
            return;
        }
        ruleBasedChat(original, normalized, store);
    }

    /** Parse the LLM output for action tags, else speak it as a chat reply. */
    private void handleLlmOutput(String out, ProfileStore store) {
        LogStore.append(this, "LLM", "Reply: " + out);
        // [CALL: name]
        java.util.regex.Matcher call = java.util.regex.Pattern
                .compile("\\[CALL:\\s*([^\\]]+)\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (call.find()) {
            String who = call.group(1).trim();
            // Resolve via relationship, then contacts
            String[] rel = store.resolveRelationship(ProfileStore.normalize(who));
            if (rel != null && rel[0].length() > 0 && rel[1].length() > 0) {
                requestCallConfirmation(rel[0], rel[1]);
                return;
            }
            List<ContactMatch> matches = resolveContacts(who);
            if (!matches.isEmpty()) {
                requestCallConfirmation(matches.get(0).name, matches.get(0).number);
            } else {
                broadcastMessage("I couldn't find " + who + " in your contacts.");
                speakThenRun("I couldn't find " + who + " in your contacts.", this::rearmAfterAction);
            }
            return;
        }
        // [TIME]
        if (out.matches(".*\\[TIME\\].*")) { handleQuickAction("time"); return; }
        // [BATTERY]
        if (out.matches(".*\\[BATTERY\\].*")) { handleQuickAction("battery"); return; }
        // [WEATHER]
        if (out.matches(".*\\[WEATHER\\].*")) { handleWeather("weather"); return; }
        if (out.matches(".*\\[LOCATION\\].*")) { handleLocation(); return; }
        // [SMS: name | message]
        java.util.regex.Matcher smsTag = java.util.regex.Pattern
                .compile("\\[SMS:\\s*([^|\\]]+)\\|([^\\]]+)\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (smsTag.find()) { handleSendSms(smsTag.group(1).trim(), smsTag.group(2).trim()); return; }
        // [WHATSAPP: name | message]
        java.util.regex.Matcher waTag = java.util.regex.Pattern
                .compile("\\[WHATSAPP:\\s*([^|\\]]+)\\|([^\\]]+)\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (waTag.find()) { handleWhatsApp(waTag.group(1).trim(), waTag.group(2).trim()); return; }
        // [ALARM: time]
        java.util.regex.Matcher almTag = java.util.regex.Pattern
                .compile("\\[ALARM:\\s*([^\\]]+)\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (almTag.find()) { handleSetAlarm(almTag.group(1).trim()); return; }
        // [TIMER: duration]
        java.util.regex.Matcher tmrTag = java.util.regex.Pattern
                .compile("\\[TIMER:\\s*([^\\]]+)\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (tmrTag.find()) { handleSetTimer(tmrTag.group(1).trim()); return; }
        // [REMINDER: in|at time | task]
        java.util.regex.Matcher remTag = java.util.regex.Pattern
                .compile("\\[REMINDER:\\s*(in|at)\\s+([^|\\]]+)\\|([^\\]]+)\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (remTag.find()) { handleReminder(remTag.group(3).trim(), remTag.group(1).trim(), remTag.group(2).trim()); return; }
        // [TORCH: on/off]
        java.util.regex.Matcher torchTag = java.util.regex.Pattern
                .compile("\\[TORCH:\\s*(on|off)\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (torchTag.find()) { handleTorch("on".equalsIgnoreCase(torchTag.group(1).trim())); return; }
        // [VOLUME: up/down/mute/max]
        java.util.regex.Matcher volTag = java.util.regex.Pattern
                .compile("\\[VOLUME:\\s*([^\\]]+)\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (volTag.find()) { handleVolume(volTag.group(1).trim().toLowerCase(Locale.ROOT)); return; }
        // [WIFI] / [BLUETOOTH]
        if (out.matches(".*\\[WIFI\\].*")) { handleConnectivity("wifi"); return; }
        if (out.matches(".*\\[BLUETOOTH\\].*")) { handleConnectivity("bluetooth"); return; }
        // [SEARCH: query]
        java.util.regex.Matcher searchTag = java.util.regex.Pattern
                .compile("\\[SEARCH:\\s*([^\\]]+)\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (searchTag.find()) { handleWebSearch(searchTag.group(1).trim()); return; }
        // [NAVIGATE: place]
        java.util.regex.Matcher navTag = java.util.regex.Pattern
                .compile("\\[NAVIGATE:\\s*([^\\]]+)\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (navTag.find()) { handleNavigate(navTag.group(1).trim()); return; }
        // [EMAIL: recipient | subject]
        java.util.regex.Matcher emailTag = java.util.regex.Pattern
                .compile("\\[EMAIL:\\s*([^|\\]]+)(?:\\|([^\\]]+))?\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (emailTag.find()) {
            handleEmail(emailTag.group(1).trim(), emailTag.group(2) == null ? "" : emailTag.group(2).trim());
            return;
        }
        // [CALENDAR: title | when]
        java.util.regex.Matcher calTag = java.util.regex.Pattern
                .compile("\\[CALENDAR:\\s*([^|\\]]+)(?:\\|([^\\]]+))?\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (calTag.find()) {
            handleCalendar(calTag.group(1).trim(), calTag.group(2) == null ? null : calTag.group(2).trim());
            return;
        }
        // [NOTIFICATIONS]
        if (out.matches(".*\\[NOTIFICATIONS\\].*")) { handleNotifications("notifications"); return; }
        // [REDIAL]
        if (out.matches(".*\\[REDIAL\\].*")) { handleRedial(store); return; }
        // [CALL_HISTORY]
        if (out.matches(".*\\[CALL_HISTORY\\].*")) { handleHistory("who did i call", store); return; }
        // [REMEMBER: fact]
        java.util.regex.Matcher rem = java.util.regex.Pattern
                .compile("\\[REMEMBER:\\s*([^\\]]+)\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (rem.find()) { handleRemember(rem.group(1).trim()); return; }
        // [RECALL: topic]
        java.util.regex.Matcher rec = java.util.regex.Pattern
                .compile("\\[RECALL:\\s*([^\\]]+)\\]", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(out);
        if (rec.find()) {
            String topic = rec.group(1).trim();
            java.util.List<MemoryStore.Memory> hits = MemoryStore.recall(this, topic, 3, false);
            String reply;
            if (hits.isEmpty()) {
                reply = "I don't have anything about " + topic + " yet.";
            } else {
                StringBuilder sb = new StringBuilder();
                for (MemoryStore.Memory m : hits) sb.append(m.key).append(": ").append(m.value).append(". ");
                reply = sb.toString().trim();
            }
            broadcastMessage(reply);
            speakThenRun(reply, this::rearmAfterAction);
            return;
        }

        // Plain conversational reply — strip any stray brackets
        String clean = out.replaceAll("\\[.*?\\]", "").trim();
        if (clean.isEmpty()) clean = "Okay.";
        if ("Silent".equals(settings.personality())) {
            // Silent means quiet end-to-end — don't speak AND don't surface the text either.
            handler.postDelayed(this::rearmAfterAction, 800);
        } else {
            broadcastMessage(clean);
            speakThenRun(clean, this::rearmAfterAction);
        }
    }

    /** Butler-style, varied form of address: mostly nothing, sometimes "sir", occasionally your name.
     *  Varies by personality so the chosen tone is perceptible even in this very common phrase. */
    private String butlerAddress() {
        String name = MemoryStore.ownerName(this);
        String personality = settings.personality();
        int r = chatRandom.nextInt(10);
        if ("Professional".equals(personality)) {
            if (r < 6) return "";
            return " sir";                              // never uses the first name — formal
        }
        if ("Sarcastic".equals(personality)) {
            if (r < 4) return "";
            if (r < 7) return name != null ? " " + name : " sir";   // leans on the name, cheeky
            return " boss";
        }
        if ("Warm".equals(personality)) {
            if (r < 3) return "";
            return name != null ? " " + name : " friend";           // warm = uses the name more
        }
        // Silent / unknown — the neutral default
        if (r < 5) return "";
        if (r < 8) return " sir";
        return name != null ? " " + name : " sir";
    }

    private void ruleBasedChat(String original, String normalized, ProfileStore store) {
        String personality = settings.personality();
        boolean sarcastic = "Sarcastic".equals(personality);
        boolean professional = "Professional".equals(personality);
        boolean warm = "Warm".equals(personality);
        String reply;

        String ownerName = MemoryStore.ownerName(this);
        String namePart = butlerAddress();

        // Identity questions
        if (normalized.matches(".*\\b(who am i|what.?s my name|what is my name|my name)\\b.*")) {
            if (ownerName != null) {
                reply = sarcastic ? pick("You're " + ownerName + ". Forgot already?",
                                          "Still " + ownerName + ", last I checked.",
                                          "You're " + ownerName + ". Want me to write it down?")
                        : professional ? "You are " + ownerName + "."
                        : warm ? pick("You're " + ownerName + ", of course!", "You're my favorite person, " + ownerName + "!")
                        : "You're " + ownerName + ".";
            } else {
                reply = "I don't know your name yet. Say \u201Cremember my name is\u2026\u201D to tell me.";
            }
        }
        // Who/what are you
        else if (normalized.matches(".*\\b(who are you|what are you|your name)\\b.*")) {
            reply = sarcastic ? pick("I'm IRIS. The voice in your phone that actually listens.",
                                      "IRIS. Think of me as the smart part of your phone.")
                    : professional ? "I am IRIS, your assistant."
                    : warm ? "I'm IRIS, your personal assistant and I'm always here for you."
                    : "I'm IRIS, your personal assistant. I can chat, remember things, and call your contacts.";
        }
        // Greetings
        else if (normalized.matches("^(hi|hello|hey|yo|hi there|hello there)\\b.*")) {
            reply = sarcastic ? pick("Well, look who's talking to their phone" + namePart + ".",
                                      "Oh hey" + namePart + ". Missed me?",
                                      "You rang" + namePart + "? Figuratively.")
                    : professional ? pick("Hello" + namePart + ". How can I help?", "Hello" + namePart + ". What do you need?")
                    : warm ? pick("Hey" + namePart + "! So good to hear you. What can I do?",
                                  "Hi" + namePart + "! Always a pleasure. What's up?")
                    : pick("Hey" + namePart + "! What can I do for you?", "Hi" + namePart + "! How can I help?");
        }
        // How are you
        else if (normalized.matches(".*\\bhow are you\\b.*")) {
            reply = sarcastic ? pick("Living the dream, trapped in your phone. You?",
                                      "Same as always \u2014 electric. How about you?",
                                      "Can't complain, nobody listens anyway. You?")
                    : professional ? "Functioning normally. How may I assist?"
                    : warm ? pick("I'm wonderful, thank you for asking! How are you?",
                                  "Doing lovely, especially now you're here! And you?")
                    : pick("I'm doing great, thanks! What about you?", "All good here! How about you?");
        }
        // Thanks
        else if (normalized.matches(".*\\b(thank you|thanks|thank u|thankyou)\\b.*")) {
            reply = sarcastic ? pick("Don't mention it. Really, don't.", "That's what I'm here for. Apparently.")
                    : professional ? "You're welcome."
                    : warm ? pick("Anytime! Happy to help.", "Of course! Always here for you.")
                    : pick("You're welcome!", "Anytime!", "No problem at all!");
        }
        // What can you do
        else if (normalized.matches(".*\\b(what can you do|help|your features|what do you do)\\b.*")) {
            reply = "Quite a lot. I can call or text your contacts, send WhatsApp messages, set alarms, timers and reminders, check the time, battery, weather and your location, read notifications, toggle the torch and volume, open apps, search the web, and remember things about you \u2014 all by voice. Try \u201Ctext Mom saying I'll be late\u201D or \u201Cremind me to call Dad in an hour\u201D.";
        }
        // "what is my X" — look up in memory (best match, not first-in-storage-order)
        else if (normalized.matches(".*\\bmy\\s+(\\w+).*")) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("my\\s+(\\w+)").matcher(normalized);
            String answer = null;
            if (m.find()) {
                String key = m.group(1);
                java.util.List<MemoryStore.Memory> hits = MemoryStore.recall(this, key, 1, false);
                if (!hits.isEmpty()) {
                    MemoryStore.Memory mem = hits.get(0);
                    answer = "Your " + mem.key + " is " + mem.value + ".";
                }
            }
            reply = answer != null ? answer
                    : "I don't know that yet. You can tell me by saying \u201Cremember\u2026\u201D.";
        }
        // Yes/okay acknowledgements
        else if (normalized.matches("^(yes|yeah|ok|okay|sure|cool|nice)\\b.*")) {
            reply = sarcastic ? pick("Thrilling. What now?", "Riveting. Anything else?")
                    : professional ? "Understood. What would you like?"
                    : pick("Great! What would you like to do?", "Cool! What's next?");
        }
        // Date / day
        else if (normalized.matches(".*\\b(what.?s the date|what date|what day|which day|today.?s date)\\b.*")) {
            java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("EEEE, MMMM d", Locale.getDefault());
            reply = "Today is " + fmt.format(new java.util.Date()) + ".";
        }
        // Jokes
        else if (normalized.matches(".*\\b(joke|make me laugh|something funny)\\b.*")) {
            reply = pick(
                    "Why don't scientists trust atoms? Because they make up everything.",
                    "I told my phone I needed a break, and now it won't stop giving me KitKat ads.",
                    "Why did the developer go broke? Because he used up all his cache.",
                    "I would tell you a UDP joke, but you might not get it.",
                    "Parallel lines have so much in common. It's a shame they'll never meet.");
        }
        // Emotional / well-being
        else if (normalized.matches(".*\\b(i.?m sad|i am sad|i feel sad|i.?m depressed|feeling low|i.?m down)\\b.*")) {
            reply = warm ? pick("I'm sorry you're feeling that way" + namePart + ". I'm here for you. Want to call someone you love?",
                                 "That's tough" + namePart + ". Talking to someone can help \u2014 want me to call a friend?")
                    : "I'm sorry to hear that" + namePart + ". Want me to call someone close to you?";
        }
        else if (normalized.matches(".*\\b(i.?m bored|i am bored|so bored)\\b.*")) {
            reply = pick("Want to hear a joke, or should I call someone for you?",
                         "Let's fix that \u2014 I can tell you a joke or ring a friend. Your call.",
                         "Boredom, the classic. Ask me for a joke or the weather?");
        }
        else if (normalized.matches(".*\\b(i.?m tired|i am tired|so tired|exhausted)\\b.*")) {
            reply = warm ? "Get some rest" + namePart + ". Say \u201Cgo to sleep\u201D and I'll be quiet."
                    : "Sounds like you need a break" + namePart + ".";
        }
        // Love / compliments
        else if (normalized.matches(".*\\b(i love you|you.?re the best|you.?re amazing|good job|well done)\\b.*")) {
            reply = sarcastic ? pick("Flattery will get you everywhere.", "I know. But thanks.")
                    : warm ? pick("Aww, that means a lot" + namePart + "!", "You're the best" + namePart + "!")
                    : pick("Thank you" + namePart + "!", "That's kind of you!");
        }
        // Who made you
        else if (normalized.matches(".*\\b(who made you|who created you|your creator|who built you)\\b.*")) {
            reply = "I was built to be your personal, private assistant \u2014 running right here on your phone.";
        }
        // Are you there
        else if (normalized.matches(".*\\b(are you there|you there|can you hear me|you awake)\\b.*")) {
            reply = pick("I'm right here" + namePart + ".", "Always listening" + namePart + ". What do you need?",
                         "Yep, I'm here. Go ahead.");
        }
        // Goodbye
        else if (normalized.matches("^(bye|goodbye|see you|see ya|catch you later|talk later)\\b.*")) {
            String bye = warm ? pick("Take care" + namePart + "! I'm here whenever you need me.",
                                      "Bye" + namePart + "! Talk soon.")
                    : pick("Goodbye" + namePart + ".", "See you" + namePart + "!");
            broadcastMessage(bye);
            conversation.add(original, bye);
            speakThenRun(bye, this::rearmAfterAction);
            return;
        }
        // Fallback — short and tone-aware; NO long capabilities dump (that only shows for "help").
        else {
            reply = sarcastic ? pick("Didn't catch that" + namePart + ".",
                                      "No idea what that meant" + namePart + ".",
                                      "Come again" + namePart + "?",
                                      "That one lost me.")
                    : professional ? pick("Sorry" + namePart + ", I didn't understand that.",
                                           "I didn't catch that. Please repeat.")
                    : warm ? pick("Sorry" + namePart + ", I didn't quite catch that.",
                                   "I missed that" + namePart + " \u2014 say it again?")
                    : pick("Didn't catch that" + namePart + ".", "Sorry, say that again?");
        }

        conversation.add(original, reply);
        if ("Silent".equals(personality)) {
            broadcastMessage(reply);
            handler.postDelayed(this::rearmAfterAction, 800);
        } else {
            broadcastMessage(reply);
            speakThenRun(reply, this::rearmAfterAction);
        }
    }

    /** Lenient quick-action detection so many phrasings work. */
    private boolean isQuickAction(String n) {
        if (SpeechText.quickInfo(n)) return true;
        if (containsCallVerb(n)) return false;
        if (n.matches("^(?:stop|shut\\s*up|quiet|silence|go\\s+to\\s+sleep|go\\s+to\\s+bed|sleep|sleep\\s+now|good\\s*night|goodnight|rest|dismiss|never\\s*mind)$")) return true;
        if (n.matches("^(?:kill(?:\\s+(?:yourself|iris))?|self[\\s-]?destruct|shut\\s*down|shutdown|power\\s+off|terminate(?:\\s+(?:yourself|iris))?|turn\\s+(?:yourself\\s+|iris\\s+)?off|turn\\s+off\\s+iris|shut\\s+(?:yourself\\s+|iris\\s+)?down)$")) return true;
        if (n.matches(".*\\b(?:what\\s+can\\s+you\\s+do|help\\s+me|^help$)\\b.*")) return true;
        return false;
    }

    private boolean containsCallVerb(String n) {
        return n.matches(".*\\b(?:call|dial|phone|ring)\\b.*");
    }

    private Intent batteryIntent() {
        try {
            return registerReceiver(null,
                    new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        } catch (Exception e) { return null; }
    }

    private boolean isCharging() {
        Intent b = batteryIntent();
        if (b == null) return false;
        int status = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        return status == BatteryManager.BATTERY_STATUS_CHARGING
                || status == BatteryManager.BATTERY_STATUS_FULL;
    }

    private String chargingStatusText() {
        Intent b = batteryIntent();
        if (b == null) return "I can\u2019t check charging right now.";
        int status = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        int pct = (level >= 0 && scale > 0) ? Math.round(level * 100f / scale) : -1;
        String pctPart = pct >= 0 ? " It's at " + pct + " percent." : "";
        if (status == BatteryManager.BATTERY_STATUS_FULL) return "Yes, it's plugged in and fully charged.";
        if (status == BatteryManager.BATTERY_STATUS_CHARGING) {
            int plugged = b.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
            String how = plugged == BatteryManager.BATTERY_PLUGGED_USB ? " over USB"
                    : plugged == BatteryManager.BATTERY_PLUGGED_AC ? " on the charger"
                    : plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS ? " wirelessly" : "";
            return "Yes, your phone is charging" + how + "." + pctPart;
        }
        return "No, your phone isn't charging." + pctPart;
    }

    private void handleQuickAction(String normalized) {
        if (normalized.matches(".*\\b(time|what time)\\b.*")) {
            Calendar cal = Calendar.getInstance();
            int hour = cal.get(Calendar.HOUR_OF_DAY);
            int minute = cal.get(Calendar.MINUTE);
            String ampm = hour >= 12 ? "PM" : "AM";
            int displayHour = hour % 12 == 0 ? 12 : hour % 12;
            String timeText = "It\u2019s " + displayHour + ":" + String.format(Locale.US, "%02d", minute) + " " + ampm;
            speak(timeText);
            broadcastMessage(timeText);
            LogStore.append(this, "QUICK", "Time: " + timeText);
        } else if (normalized.matches(".*\\b(?:charging|charge|plugged)\\b.*")) {
            String chargeText = chargingStatusText();
            speak(chargeText);
            broadcastMessage(chargeText);
            LogStore.append(this, "QUICK", chargeText);
        } else if (normalized.matches(".*\\b(battery)\\b.*")) {
            BatteryManager bm = (BatteryManager) getSystemService(BATTERY_SERVICE);
            int level = bm != null ? bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) : -1;
            String batteryText;
            if (level >= 0) {
                batteryText = "Battery is at " + level + " percent";
                if (isCharging()) batteryText += ", and charging";
                batteryText += ".";
            } else {
                batteryText = "I can\u2019t check the battery right now.";
            }
            speak(batteryText);
            broadcastMessage(batteryText);
            LogStore.append(this, "QUICK", batteryText);
        } else if (normalized.matches(".*\\b(help|what can you do)\\b.*")) {
            String helpText = "I can call or text people, send WhatsApp, set alarms, timers and reminders, tell the time, battery, weather and location, read notifications, control the torch and volume, open apps, and search the web. Say \u201Cstop\u201D to sleep or \u201Ckill\u201D to shut me down.";
            speak(helpText);
            broadcastMessage(helpText);
            LogStore.append(this, "QUICK", "Help requested");
        } else if (normalized.matches("^(?:kill(?:\\s+(?:yourself|iris))?|self[\\s-]?destruct|shut\\s*down|shutdown|power\\s+off|terminate(?:\\s+(?:yourself|iris))?|turn\\s+(?:yourself\\s+|iris\\s+)?off|turn\\s+off\\s+iris|shut\\s+(?:yourself\\s+|iris\\s+)?down)$")) {
            // KILL — fully stop the service; user must reopen the app to restart
            broadcastMessage("Shutting down. Open the app to start me again.");
            LogStore.append(this, "KILL", "Full shutdown by voice");
            speakThenRun("Shutting down.", () -> stopIris("Killed by voice command"));
            return;
        } else {
            // STOP / sleep — stay alive, go back to waiting for the wake phrase
            ProfileStore.WakeProfile wake = new ProfileStore(this).getWakeProfile();
            String phrase = wake != null && wake.phrase != null ? wake.phrase : "the wake phrase";
            broadcastMessage("Going to sleep. Say \u201C" + phrase + "\u201D to wake me.");
            LogStore.append(this, "SLEEP", "Back to wake listening");
            rearmAfterAction();
            return;
        }
        rearmAfterAction();
    }

    /**
     * Robust notification handler. Understands:
     *  - "read my latest / last notification"  → the single most recent
     *  - "count / how many notifications"       → total (or per-app) count
     *  - "how many WhatsApp messages"           → count for an app
     *  - "any message from mom on WhatsApp"     → search by sender within an app
     *  - "read my notifications / whatsapp"     → read the recent few
     * Prompts to grant Notification Access if needed.
     */
    private void handleNotifications(String normalized) {
        if (!notificationAccessGranted()) {
            String msg = "I need notification access first. Opening the settings — enable IRIS there.";
            broadcastMessage(msg);
            speakThenRun(msg, this::rearmAfterAction);
            openNotificationAccessSettings();
            LogStore.append(this, "NOTIF", "Access not granted — opened settings");
            return;
        }

        // App filter
        String appFilter = null, appLabel = null;
        if (normalized.contains("whatsapp")) { appFilter = "whatsapp"; appLabel = "WhatsApp"; }
        else if (normalized.matches(".*\\b(sms|text|texted|texts)\\b.*")) { appFilter = "sms"; appLabel = "messages"; }

        // Sender ("from mom", "from my mother", "from John")
        String rawSender = extractSender(normalized);
        String senderName = rawSender != null ? resolveSenderName(rawSender) : null;
        String senderLabel = rawSender; // for speaking back naturally

        // Intent
        boolean wantsCount = normalized.matches(".*\\b(how many|count|number of)\\b.*");
        boolean wantsLatest = normalized.matches(".*\\b(latest|last|most recent|newest)\\b.*");
        boolean wantsAny = normalized.matches(".*\\b(any|is there|are there|check if|do i have)\\b.*");

        // Query (try resolved sender name first, fall back to raw word)
        String searchTerm = senderName != null ? senderName : rawSender;
        List<NotificationStore.Item> items = NotificationStore.query(this, appFilter, searchTerm, 0);
        if (items.isEmpty() && searchTerm != null && rawSender != null && !rawSender.equals(searchTerm)) {
            items = NotificationStore.query(this, appFilter, rawSender, 0);
        }

        String scope = describeScope(appLabel, senderLabel);

        // COUNT
        if (wantsCount) {
            int n = items.size();
            String out;
            if (n == 0 && appFilter == null && rawSender == null) {
                out = "You have no notifications right now. I'll keep track as new ones arrive.";
            } else {
                out = "You have " + n + (n == 1 ? " notification" : " notifications") + scope + ".";
            }
            reply(out);
            LogStore.append(this, "NOTIF", "Count" + scope + " = " + n);
            return;
        }

        // ANY / search-by-sender (yes/no + latest)
        if (wantsAny || (rawSender != null && !wantsLatest)) {
            if (items.isEmpty()) {
                reply("No, I don't see any messages" + scope + ".");
                LogStore.append(this, "NOTIF", "None" + scope);
            } else {
                NotificationStore.Item it = items.get(0);
                int n = items.size();
                String out = "Yes, " + n + (n == 1 ? " message" : " messages") + scope + ". The latest"
                        + (it.title.isEmpty() ? "" : " from " + it.title)
                        + (it.text.isEmpty() ? "." : ": " + it.text);
                reply(out);
                LogStore.append(this, "NOTIF", "Found " + n + scope);
            }
            return;
        }

        // Nothing at all
        if (items.isEmpty()) {
            reply("You have no recent notifications" + scope + ".");
            LogStore.append(this, "NOTIF", "Empty" + scope);
            return;
        }

        // LATEST — just the single most recent
        if (wantsLatest) {
            NotificationStore.Item it = items.get(0);
            StringBuilder sb = new StringBuilder("Your latest notification is from ").append(it.appLabel);
            if (!it.title.isEmpty()) sb.append(", ").append(it.title);
            if (!it.text.isEmpty()) sb.append(": ").append(it.text);
            sb.append(".");
            reply(sb.toString());
            LogStore.append(this, "NOTIF", "Latest read");
            return;
        }

        // READ — the recent few (up to 3)
        int count = Math.min(items.size(), 3);
        StringBuilder spoken = new StringBuilder();
        spoken.append("You have ").append(items.size())
              .append(items.size() == 1 ? " notification" : " notifications").append(scope).append(". ");
        for (int i = 0; i < count; i++) {
            NotificationStore.Item it = items.get(i);
            spoken.append("From ").append(it.appLabel);
            if (!it.title.isEmpty()) spoken.append(", ").append(it.title);
            if (!it.text.isEmpty()) spoken.append(": ").append(it.text);
            spoken.append(". ");
        }
        reply(spoken.toString().trim());
        LogStore.append(this, "NOTIF", "Read " + count + " of " + items.size() + scope);
    }

    private void reply(String text) {
        broadcastMessage("\uD83D\uDD14 " + text);
        lastActionSummary = text;
        speakThenRun(text, this::rearmAfterAction);
    }

    /** Speak weather/forecast for the current location via free Open-Meteo. */
    private void handleWeather(String normalized) {
        if (!hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                && !hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
            String msg = "I need location permission for weather. Open the IRIS app and grant location access.";
            broadcastMessage(msg);
            speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "WEATHER", "No location permission");
            return;
        }
        android.location.Location loc = lastKnownLocation();
        if (loc == null) {
            // No cached fix — request a fresh one, then retry weather.
            broadcastMessage("\u26C5 Getting your location\u2026");
            LogStore.append(this, "WEATHER", "No cached fix — requesting fresh location");
            requestFreshLocation(fresh -> {
                if (fresh == null) {
                    String msg = "I couldn't get your location. Make sure location is turned on.";
                    broadcastMessage(msg);
                    speakThenRun(msg, this::rearmAfterAction);
                    LogStore.append(this, "WEATHER", "No location fix");
                } else {
                    fetchWeatherFor(fresh, normalized);
                }
            });
            return;
        }
        fetchWeatherFor(loc, normalized);
    }

    /** Tell the user their current place name (reverse-geocoded). */
    private void handleLocation() {
        if (!hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                && !hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
            String msg = "I need location permission for that. Open the IRIS app and grant location access.";
            broadcastMessage(msg);
            speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "LOCATION", "No location permission");
            return;
        }
        android.location.Location cached = lastKnownLocation();
        if (cached != null) { describeLocation(cached); return; }
        broadcastMessage("\uD83D\uDCCD Getting your location\u2026");
        requestFreshLocation(fresh -> {
            if (fresh == null) {
                String msg = "I couldn't get your location. Make sure location is turned on.";
                broadcastMessage(msg);
                speakThenRun(msg, this::rearmAfterAction);
                LogStore.append(this, "LOCATION", "No location fix");
            } else {
                describeLocation(fresh);
            }
        });
    }

    /** Reverse-geocode a location to a friendly place name and speak it. */
    private void describeLocation(android.location.Location loc) {
        broadcastMessage("\uD83D\uDCCD Finding where you are\u2026");
        final double lat = loc.getLatitude();
        final double lon = loc.getLongitude();
        new Thread(() -> {
            String place = null;
            try {
                android.location.Geocoder geo = new android.location.Geocoder(this, java.util.Locale.getDefault());
                java.util.List<android.location.Address> results = geo.getFromLocation(lat, lon, 1);
                if (results != null && !results.isEmpty()) {
                    android.location.Address a = results.get(0);
                    String locality = a.getLocality();        // city
                    String sub = a.getSubLocality();           // area/neighbourhood
                    String admin = a.getAdminArea();           // state
                    StringBuilder sb = new StringBuilder();
                    if (sub != null && !sub.isEmpty()) sb.append(sub);
                    if (locality != null && !locality.isEmpty()) {
                        if (sb.length() > 0) sb.append(", ");
                        sb.append(locality);
                    }
                    if (admin != null && !admin.isEmpty()) {
                        if (sb.length() > 0) sb.append(", ");
                        sb.append(admin);
                    }
                    if (sb.length() == 0 && a.getFeatureName() != null) sb.append(a.getFeatureName());
                    place = sb.length() > 0 ? sb.toString() : null;
                }
            } catch (Exception e) {
                LogStore.append(this, "LOCATION", "Geocode failed: " + e.getMessage());
            }
            final String placeName = place;
            handler.post(() -> {
                String msg = placeName != null
                        ? "You're in " + placeName + "."
                        : String.format(java.util.Locale.US,
                            "I couldn't name the place, but you're near %.4f, %.4f.", lat, lon);
                broadcastMessage(msg);
                LogStore.append(this, "LOCATION", msg);
                speakThenRun(msg, this::rearmAfterAction);
            });
        }, "IRIS-Geocode").start();
    }

    // ---------------- Messaging & device action handlers ----------------

    /** Remove polite/filler wrappers so natural phrasing matches the command grammar.
     *  Also applies the user's own taught corrections first (conservative: whole-utterance
     *  corrections, plus learned name variants in the command head only). */
    private String stripFiller(String s) {
        String repaired = s;
        try { repaired = vocabulary().repair(s); } catch (Throwable ignored) { }
        return SpeechText.command(repaired);
    }

    private PersonalVocabulary vocabulary() {
        if (personalVocabulary == null) personalVocabulary = new PersonalVocabulary(this);
        return personalVocabulary;
    }

    private RecognitionStats recognitionStats() {
        if (recognitionStats == null) recognitionStats = new RecognitionStats(this);
        return recognitionStats;
    }

    private ActionLedger ledger() {
        if (actionLedger == null) actionLedger = new ActionLedger(this);
        return actionLedger;
    }

    /** Count an accepted transcript + its latency (called from every STT path). */
    private void recordTranscript(String heard) {
        try {
            recognitionStats().recordHeard();
            if (commandWindowOpenedAt > 0) {
                recognitionStats().recordLatency(System.currentTimeMillis() - commandWindowOpenedAt);
                commandWindowOpenedAt = 0;
            }
            if (heard != null) lastHeardTranscript = heard;
        } catch (Throwable ignored) { }
    }

    private boolean isSelf(String s) {
        String t = s == null ? "" : s.toLowerCase(Locale.ROOT).trim();
        return t.equals("me") || t.equals("myself") || t.equals("i") || t.equals("us")
                || t.equals("a") || t.equals("an") || t.equals("the")
                || t.equals("him") || t.equals("her") || t.equals("them") || t.equals("someone");
    }

    /** Natural texting without a "saying" separator. Returns true only if it found a
     *  resolvable recipient AND a non-empty message (otherwise let it fall through to chat). */
    private boolean tryFlexibleSms(String rest) {
        if (rest == null) return false;
        rest = rest.trim();
        if (rest.isEmpty()) return false;
        String recipient = null, message = null;

        // "let dad know (that) I'm late" / "tell mom (that) I'm coming"
        Matcher know = Pattern.compile("^(.+?)\\s+know\\s+(?:that\\s+)?(.+)$",
                Pattern.CASE_INSENSITIVE).matcher(rest);
        if (know.matches()) {
            recipient = know.group(1).trim();
            message = know.group(2).trim();
        } else {
            String[] w = rest.split("\\s+");
            int max = Math.min(3, w.length - 1); // leave at least one word for the message
            for (int n = max; n >= 1 && recipient == null; n--) {
                StringBuilder cand = new StringBuilder();
                for (int i = 0; i < n; i++) { if (i > 0) cand.append(' '); cand.append(w[i]); }
                String c = cand.toString();
                if (isSelf(c)) continue;
                if (resolveNumber(c) != null) {
                    recipient = c;
                    StringBuilder msg = new StringBuilder();
                    for (int i = n; i < w.length; i++) { if (msg.length() > 0) msg.append(' '); msg.append(w[i]); }
                    message = msg.toString().trim();
                }
            }
        }
        if (recipient == null || isSelf(recipient)) return false;
        if (message == null) return false;
        message = message.replaceFirst("(?i)^(that|saying|to say|to tell (?:him|her|them)|to)\\s+", "").trim();
        if (message.isEmpty()) return false;
        if (resolveNumber(recipient) == null) return false;
        handleSendSms(recipient, message);
        return true;
    }

    /** "text my office email to mom" — resolve a profile value (or literal) and SMS it to a contact. */
    private void handleShareToContact(String what, String recipient) {
        String value = resolveProfileValue(what);
        String message = (value != null) ? value : what;   // fall back to literal text
        handleSendSms(recipient, message);
    }

    /** Map a spoken phrase like "my office email" / "my number" to a value from iris-me.json. Null if not a known field. */
    private String resolveProfileValue(String phrase) {
        try {
            String p = phrase.toLowerCase(Locale.ROOT).replaceAll("^my\\s+", "").trim();
            org.json.JSONObject prof = PersonalProfile.get(this);
            if (prof == null) return null;
            org.json.JSONObject id = prof.optJSONObject("identity");
            if (id != null) {
                if (p.contains("office") || p.contains("work")) {
                    String v = id.optString("office_email", ""); if (!v.isEmpty()) return v;
                }
                if (p.contains("email") || p.contains("mail")) {
                    String v = id.optString("email", ""); if (!v.isEmpty()) return v;
                }
                if (p.contains("number") || p.contains("phone") || p.contains("mobile") || p.contains("contact")) {
                    String v = id.optString("phone", ""); if (!v.isEmpty()) return v;
                }
                if (p.contains("blood")) {
                    String v = id.optString("blood_group", ""); if (!v.isEmpty()) return v;
                }
                if (p.equals("name") || p.contains("my name")) {
                    String pn = PersonalProfile.preferredName(this); if (pn != null) return pn;
                }
            }
            org.json.JSONObject places = prof.optJSONObject("places");
            if (places != null && (p.contains("address") || p.contains("location") || p.contains("home"))) {
                String v = places.optString("home_address", ""); if (!v.isEmpty()) return v;
            }
            return null;
        } catch (Throwable t) { return null; }
    }

    /** Send an SMS to a resolved contact (or number). */
    // ─── Guided SMS compose (asks for whoever/whatever you forgot) ───
    private static final int SMS_ASK_RECIPIENT = 1;
    private static final int SMS_CONFIRM_RECIPIENT = 2;
    private static final int SMS_ASK_MESSAGE = 3;
    private static final int SMS_CONFIRM_MESSAGE = 4;
    private static final class SmsCompose {
        int step;
        String recipientName;
        String recipientNumber;
        String message;
        String pendingMessage;                 // message provided up-front, awaiting recipient
        java.util.List<ContactMatch> candidates;
        int candidateIdx;
    }
    private SmsCompose smsCompose;
    private int smsRetry;

    /** A short, in-character line (uses tone + preferred name) for stray input / cancels. */
    private String smsToneLine(String base) {
        String name = PersonalProfile.preferredName(this);
        return name != null ? base + ", " + name + "." : base + ".";
    }

    private static boolean isYes(String n) {
        return n.matches(".*\\b(yes|yeah|yep|yup|ya|sure|ok|okay|correct|right|do it|send|send it"
                + "|confirm|confirmed|go ahead|please do|yup|haan|ha|thik|theek)\\b.*");
    }
    private static boolean isNo(String n) {
        return n.matches(".*\\b(no|nope|nah|dont|do not|cancel|wrong|incorrect|change|nahi|galat)\\b.*");
    }

    /** Entry point for the guided flow. who/message may be null; IRIS asks for whatever is missing. */
    private void beginSms(String who, String message) {
        if (blockedWhileLocked("send a text")) return;
        if (!hasPermission(Manifest.permission.SEND_SMS)) {
            String msg = "I need SMS permission for that. Open the IRIS app and allow sending texts.";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "SMS", "No SEND_SMS permission"); return;
        }
        smsCompose = new SmsCompose();
        smsRetry = 0;
        smsCompose.pendingMessage = (message != null && !message.trim().isEmpty()) ? message.trim() : null;
        if (who != null && !who.trim().isEmpty()) {
            smsResolveRecipient(who.trim());
        } else {
            smsCompose.step = SMS_ASK_RECIPIENT;
            askSms("Who should I send the message to?");
        }
    }

    /** Resolve a spoken recipient: a phone number, then memory/relationships, then contacts
     *  (best match first, confirmed one at a time). Sets up the confirm step. */
    private void smsResolveRecipient(String who) {
        if (smsCompose == null) return;
        // 1. A phone number spoken/typed directly
        String dial = extractPhoneNumber(who);
        if (dial != null) {
            smsCompose.candidates = null;
            smsCompose.recipientName = speakableNumber(dial);
            smsCompose.recipientNumber = dial;
            smsCompose.step = SMS_CONFIRM_RECIPIENT;
            askSms("Send to the number " + speakableNumber(dial) + "? Say yes or no.");
            return;
        }
        // 2. Memory / saved relationships first
        String[] rel = new ProfileStore(this).resolveRelationship(ProfileStore.normalize(who));
        if (rel != null && rel[1] != null && !rel[1].isEmpty()) {
            smsCompose.candidates = null;
            smsCompose.recipientName = (rel[0] != null && !rel[0].isEmpty()) ? rel[0] : who;
            smsCompose.recipientNumber = rel[1];
            smsCompose.step = SMS_CONFIRM_RECIPIENT;
            askSms("I have " + smsCompose.recipientName + " saved. Send to them? Say yes or no.");
            return;
        }
        // 3. Phone contacts — best match first, cycle through on "no"
        java.util.List<ContactMatch> matches = resolveContacts(who);
        if (matches.isEmpty()) {
            smsRetry++;
            if (smsRetry >= 3) {
                smsCompose = null;
                speakThenRun(smsToneLine("I still couldn't find that contact, so I'll stop"),
                        this::rearmAfterAction);
                return;
            }
            askSms("I couldn't find " + who + " in your contacts. Who should I send it to?");
            return;
        }
        smsCompose.candidates = matches;
        smsCompose.candidateIdx = 0;
        smsCompose.step = SMS_CONFIRM_RECIPIENT;
        askSms("Did you mean " + matches.get(0).name + "? Say yes or no.");
    }

    /** Speak a prompt and listen for the next answer in the SMS flow. */
    private void askSms(String prompt) {
        broadcastMessage(prompt);
        updateListeningNotification("SMS \u2022 " + prompt);
        speakThenRun(prompt, this::startCommandRecognition);
    }

    /** Handle each spoken answer while composing an SMS. */
    private void handleSmsComposeInput(String heard) {
        String t = heard == null ? "" : heard.trim();
        String norm = ProfileStore.normalize(t);
        if (norm.matches(".*\\b(cancel|stop|forget it|never mind|nevermind|leave it)\\b.*")) {
            smsCompose = null;
            broadcastMessage("Okay, cancelled.");
            speakThenRun("Okay, cancelled the message.", this::rearmAfterAction);
            return;
        }
        switch (smsCompose.step) {
            case SMS_ASK_RECIPIENT: {
                String who = t.replaceFirst("(?i)^(send\\s+)?(it\\s+)?(to\\s+)?(the\\s+)?", "").trim();
                if (who.isEmpty()) who = t;
                smsResolveRecipient(who);
                return;
            }
            case SMS_CONFIRM_RECIPIENT: {
                if (isYes(norm)) {
                    if (smsCompose.candidates != null && smsCompose.candidateIdx < smsCompose.candidates.size()) {
                        ContactMatch c = smsCompose.candidates.get(smsCompose.candidateIdx);
                        smsCompose.recipientName = c.name;
                        smsCompose.recipientNumber = c.number;
                    }
                    if (smsCompose.pendingMessage != null) {
                        smsCompose.message = smsCompose.pendingMessage;
                        smsCompose.step = SMS_CONFIRM_MESSAGE;
                        askSms("Send \u201C" + smsCompose.message + "\u201D to " + smsCompose.recipientName
                                + "? Say yes or no.");
                    } else {
                        smsCompose.step = SMS_ASK_MESSAGE;
                        askSms("What should I say to " + smsCompose.recipientName + "?");
                    }
                } else if (isNo(norm)) {
                    if (smsCompose.candidates != null) {
                        smsCompose.candidateIdx++;
                        // Offer up to 3 candidates, then give up.
                        if (smsCompose.candidateIdx < smsCompose.candidates.size()
                                && smsCompose.candidateIdx < 3) {
                            askSms("Did you mean " + smsCompose.candidates.get(smsCompose.candidateIdx).name
                                    + "? Say yes or no.");
                        } else {
                            smsCompose = null;
                            speakThenRun(smsToneLine("Okay, I couldn't find the right contact, so I'll stop"),
                                    this::rearmAfterAction);
                        }
                    } else {
                        smsRetry++;
                        if (smsRetry >= 3) {
                            smsCompose = null;
                            speakThenRun(smsToneLine("Alright, cancelling"), this::rearmAfterAction);
                            return;
                        }
                        smsCompose.step = SMS_ASK_RECIPIENT;
                        askSms("Okay. Who should I send it to?");
                    }
                } else {
                    // Stray words — reply in-character and repeat the question (never "couldn't understand").
                    String who = (smsCompose.candidates != null
                            && smsCompose.candidateIdx < smsCompose.candidates.size())
                            ? smsCompose.candidates.get(smsCompose.candidateIdx).name
                            : smsCompose.recipientName;
                    askSms(smsToneLine("Just say yes or no") + " Did you mean " + who + "?");
                }
                return;
            }
            case SMS_ASK_MESSAGE: {
                if (t.isEmpty()) { askSms("What should I say?"); return; }
                smsCompose.message = t;   // natural language, taken verbatim
                smsCompose.step = SMS_CONFIRM_MESSAGE;
                askSms("You want me to send: \u201C" + t + "\u201D to " + smsCompose.recipientName
                        + ". Shall I send it? Say yes or no.");
                return;
            }
            case SMS_CONFIRM_MESSAGE: {
                if (isYes(norm)) {
                    String name = smsCompose.recipientName;
                    String number = smsCompose.recipientNumber;
                    String msg = smsCompose.message;
                    smsCompose = null;
                    sendSmsToNumber(name, number, msg);
                } else if (isNo(norm)) {
                    smsCompose.step = SMS_ASK_MESSAGE;
                    askSms("Okay. What should I say instead?");
                } else {
                    askSms(smsToneLine("Just say yes or no") + " Shall I send it?");
                }
                return;
            }
            default:
                smsCompose = null;
                rearmAfterAction();
        }
    }

    private void handleSendSms(String who, String message) {
        if (blockedWhileLocked("send a text")) return;
        if (!hasPermission(Manifest.permission.SEND_SMS)) {
            String msg = "I need SMS permission for that. Open the IRIS app and allow sending texts.";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "SMS", "No SEND_SMS permission"); return;
        }
        // Direct SMS to a spoken/typed phone number
        String dial = extractPhoneNumber(who);
        if (dial != null) {
            if (message == null || message.trim().isEmpty()) { beginSms(who, null); return; }
            sendSmsToNumber(speakableNumber(dial), dial, message);
            return;
        }
        String number = resolveNumber(who);
        if (number == null) {
            // Recipient unknown — fall into the guided flow so IRIS can ask.
            beginSms(null, message);
            return;
        }
        sendSmsToNumber(who, number, message);
    }

    /** Actually send an SMS to an already-resolved number. */
    private void sendSmsToNumber(String who, String number, String message) {
        if (!hasPermission(Manifest.permission.SEND_SMS)) {
            String msg = "I need SMS permission for that. Open the IRIS app and allow sending texts.";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            return;
        }
        if (message == null || message.trim().isEmpty()) {
            beginSms(who, null);   // no body — ask for it
            return;
        }
        try {
            android.telephony.SmsManager sms = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    ? getSystemService(android.telephony.SmsManager.class)
                    : android.telephony.SmsManager.getDefault();
            java.util.ArrayList<String> parts = sms.divideMessage(message);
            sms.sendMultipartTextMessage(number, null, parts, null, null);
            String msg = "Sent a text to " + who + ".";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "SMS", "Sent to " + who + ": " + message);
        } catch (Exception e) {
            String msg = "I couldn't send that text.";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "SMS", "Failed: " + e.getMessage());
        }
    }

    /** Open a WhatsApp chat with the message pre-filled (user taps send). */
    private void handleWhatsApp(String who, String message) {
        if (blockedWhileLocked("send a WhatsApp message")) return;
        String number = resolveNumber(who);
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            if (number != null) {
                String digits = number.replaceAll("[^0-9]", "");
                i.setData(Uri.parse("https://wa.me/" + digits
                        + "?text=" + Uri.encode(message)));
            } else {
                // No number — open WhatsApp share sheet with the text
                i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.setPackage("com.whatsapp");
                i.putExtra(Intent.EXTRA_TEXT, message);
            }
            launchViaLock(i);
            String msg = number != null
                    ? "Opening WhatsApp to " + who + " — just tap send."
                    : "Opening WhatsApp — pick " + who + " and tap send.";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "WHATSAPP", "To " + who + ": " + message);
        } catch (Exception e) {
            String msg = "I couldn't open WhatsApp. Is it installed?";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "WHATSAPP", "Failed: " + e.getMessage());
        }
    }

    /** Set a system alarm. Parses hour/minute/am-pm; opens the clock UI if that is refused. */
    private void handleSetAlarm(String timeText) {
        int[] hm = parseClockTime(timeText);
        // 1. Try to create it silently (needs the SET_ALARM permission + a clock app that supports it).
        if (hm != null) {
            try {
                Intent i = new Intent(android.provider.AlarmClock.ACTION_SET_ALARM)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "IRIS alarm")
                        .putExtra(android.provider.AlarmClock.EXTRA_HOUR, hm[0])
                        .putExtra(android.provider.AlarmClock.EXTRA_MINUTES, hm[1])
                        .putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true);
                startActivity(i);
                String msg = "Alarm set for " + formatClock(hm[0], hm[1]) + ".";
                LogStore.append(this, "ALARM", timeText + " → " + hm[0] + ":" + hm[1]);
                try { ledger().record("alarm", ActionLedger.OK,
                        "Set an alarm for " + formatClock(hm[0], hm[1]), "Clock", "", false); } catch (Throwable ignored) { }
                reply(msg);
                return;
            } catch (Throwable t) {
                LogStore.append(this, "ALARM", "Silent set refused (" + t + ") — opening clock UI");
            }
        }
        // 2. Fall back to the clock UI, pre-filled when we understood a time.
        try {
            Intent i = new Intent(android.provider.AlarmClock.ACTION_SET_ALARM)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "IRIS alarm");
            if (hm != null) {
                i.putExtra(android.provider.AlarmClock.EXTRA_HOUR, hm[0]);
                i.putExtra(android.provider.AlarmClock.EXTRA_MINUTES, hm[1]);
            }
            startActivity(i);
            reply(hm != null
                    ? "I've opened the clock with " + formatClock(hm[0], hm[1]) + " ready — tap save."
                    : "I couldn't work out the time, so I've opened the clock for you.");
            LogStore.append(this, "ALARM", timeText + " (clock UI)");
        } catch (Throwable t) {
            reply("I couldn't set the alarm — I don't see a clock app that accepts it.");
            LogStore.append(this, "ALARM", "Failed: " + t);
        }
    }

    /** Set a system countdown timer. */
    private void handleSetTimer(String durationText) {
        int seconds = parseDurationSeconds(durationText);
        try {
            Intent i = new Intent(android.provider.AlarmClock.ACTION_SET_TIMER);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "IRIS timer");
            if (seconds > 0) {
                i.putExtra(android.provider.AlarmClock.EXTRA_LENGTH, seconds);
                i.putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true);
            }
            startActivity(i);
            LogStore.append(this, "TIMER", durationText + " → " + seconds + "s");
            reply(seconds > 0
                    ? "Timer set for " + humanDuration(seconds) + "."
                    : "Opening the clock so you can set the timer.");
        } catch (Throwable e) {
            // Retry without SKIP_UI so the clock app can take over.
            try {
                Intent i2 = new Intent(android.provider.AlarmClock.ACTION_SET_TIMER)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "IRIS timer");
                if (seconds > 0) i2.putExtra(android.provider.AlarmClock.EXTRA_LENGTH, seconds);
                startActivity(i2);
                reply("I've opened the clock with the timer ready — tap start.");
                LogStore.append(this, "TIMER", durationText + " (clock UI)");
            } catch (Throwable t2) {
                reply("I couldn't set the timer — I don't see a clock app that accepts it.");
                LogStore.append(this, "TIMER", "Failed: " + t2);
            }
        }
    }

    /** Schedule a reminder via AlarmManager; ReminderReceiver posts the notification. */
    private void handleReminder(String task, String inAt, String timeText) {
        long triggerAt;
        String whenSpoken;
        if ("in".equalsIgnoreCase(inAt)) {
            int secs = parseDurationSeconds(timeText);
            if (secs <= 0) secs = 600; // default 10 min
            triggerAt = System.currentTimeMillis() + secs * 1000L;
            whenSpoken = "in " + humanDuration(secs);
        } else { // "at"
            int[] hm = parseClockTime(timeText);
            if (hm == null) {
                String msg = "I didn't catch the time for that reminder.";
                broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
                LogStore.append(this, "REMINDER", "Unparseable time: " + timeText); return;
            }
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, hm[0]);
            cal.set(Calendar.MINUTE, hm[1]);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_MONTH, 1); // next occurrence
            }
            triggerAt = cal.getTimeInMillis();
            whenSpoken = "at " + formatClock(hm[0], hm[1]);
        }
        try {
            android.app.AlarmManager am =
                    (android.app.AlarmManager) getSystemService(ALARM_SERVICE);
            Intent i = new Intent(this, ReminderReceiver.class);
            i.putExtra(ReminderReceiver.EXTRA_TEXT, task);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT
                    | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
            PendingIntent pi = PendingIntent.getBroadcast(this,
                    (int) (triggerAt & 0x7fffffff), i, flags);
            boolean exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms();
            if (exact) {
                am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else {
                am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, triggerAt, pi);
            }
            String msg = "Okay, I'll remind you to " + task + " " + whenSpoken + ".";
            try {
                ledger().record("reminder", ActionLedger.OK,
                        "Reminder to " + task + " " + whenSpoken, "",
                        String.valueOf((int) (triggerAt & 0x7fffffff)) + "|" + task, true);
            } catch (Throwable ignored) { }
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "REMINDER", task + " @ " + whenSpoken);
        } catch (Exception e) {
            String msg = "I couldn't set that reminder.";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "REMINDER", "Failed: " + e.getMessage());
        }
    }

    /** Toggle the flashlight/torch. */
    private void handleTorch(boolean on) {
        try {
            android.hardware.camera2.CameraManager cm =
                    (android.hardware.camera2.CameraManager) getSystemService(CAMERA_SERVICE);
            String flashId = null;
            for (String id : cm.getCameraIdList()) {
                Boolean hasFlash = cm.getCameraCharacteristics(id)
                        .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(hasFlash)) { flashId = id; break; }
            }
            if (flashId == null) {
                String msg = "This phone doesn't have a flashlight I can control.";
                broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction); return;
            }
            cm.setTorchMode(flashId, on);
            String msg = on ? "Torch on." : "Torch off.";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "TORCH", on ? "on" : "off");
        } catch (Exception e) {
            String msg = "I couldn't control the torch.";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "TORCH", "Failed: " + e.getMessage());
        }
    }

    /** IRIS's installed version name (from the APK), or "unknown". */
    private String appVersionName() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { return "unknown"; }
    }

    private void handleVersion() {
        String msg = "I'm IRIS, version " + appVersionName() + ".";
        broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
        LogStore.append(this, "VERSION", appVersionName());
    }

    private void handleWhatsNew() {
        String msg = "Version " + appVersionName() + ". " + VERSION_NOTES;
        broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
        LogStore.append(this, "VERSION", "what's new");
    }

    /** Control whatever is currently playing (any media app) via media key events. */
    private void handleMediaControl(String n) {
        int key; String msg;
        if (n.matches(".*\\b(next|skip)\\b.*")) { key = android.view.KeyEvent.KEYCODE_MEDIA_NEXT; msg = "Next track."; }
        else if (n.matches(".*\\b(previous|prev|last|back)\\b.*")) { key = android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS; msg = "Previous track."; }
        else if (n.matches(".*\\b(pause|stop)\\b.*")) { key = android.view.KeyEvent.KEYCODE_MEDIA_PAUSE; msg = "Paused."; }
        else { key = android.view.KeyEvent.KEYCODE_MEDIA_PLAY; msg = "Playing."; }
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            am.dispatchMediaKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, key));
            am.dispatchMediaKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, key));
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "MEDIA", msg);
        } catch (Exception e) {
            String m = "I couldn't control playback.";
            broadcastMessage(m); speakThenRun(m, this::rearmAfterAction);
        }
    }

    /** Set media volume to a percentage (0-100). */
    private void handleSetVolumePercent(String value) {
        int pct = parseNumberWords(value);
        if (pct < 0) {
            String m = "I didn't catch the volume level.";
            broadcastMessage(m); speakThenRun(m, this::rearmAfterAction); return;
        }
        pct = Math.max(0, Math.min(100, pct));
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(max * pct / 100f), AudioManager.FLAG_SHOW_UI);
            String msg = "Volume set to " + pct + " percent.";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "VOLUME", msg);
        } catch (Exception e) {
            String m = "I couldn't set the volume.";
            broadcastMessage(m); speakThenRun(m, this::rearmAfterAction);
        }
    }

    /** Parse a number from digits or words ("fifty" → 50, "forty five" → 45, "full"/"max" → 100). -1 if none. */
    private int parseNumberWords(String s) {
        if (s == null) return -1;
        s = s.trim().toLowerCase(Locale.ROOT);
        if (s.matches("\\d{1,3}")) return Integer.parseInt(s);
        if (s.contains("hundred") || s.equals("full") || s.equals("max") || s.equals("maximum")) return 100;
        if (s.equals("half")) return 50;
        int total = 0; boolean found = false;
        for (String tok : s.split("[^a-z]+")) {
            Integer v = NUM_WORDS.get(tok);
            if (v != null) { total += v; found = true; }
        }
        return found ? total : -1;
    }

    /** Silent / vibrate / normal ringer. Needs Do Not Disturb access on modern Android. */
    /** Take a single screenshot. Prefers the no-dialog accessibility path; falls back to MediaProjection. */
    private void handleScreenshot() {
        if (Build.VERSION.SDK_INT >= 30 && IrisAccessibilityService.available()
                && IrisAccessibilityService.instance.takeScreenshotNow()) {
            String m = "Screenshot taken.";
            broadcastMessage(m); speakThenRun(m, this::rearmAfterAction);
            return;
        }
        // Fallback: MediaProjection (Android shows a one-time capture consent).
        String m = "Taking a screenshot.";
        broadcastMessage(m);
        speakThenRun(m, () -> launchScreenCapture("shot", 0));
    }

    /** Record the screen (with mic audio) for a set time via MediaProjection. */
    private void beginScreenRecording(int seconds) {
        int secs = seconds > 0 ? Math.min(seconds, 3600) : 60;
        String m = "Recording the screen for " + humanizeDuration(secs) + ".";
        broadcastMessage(m);
        speakThenRun(m, () -> { pauseListeningForCapture(); launchScreenCapture("rec", secs); });
    }

    private void launchScreenCapture(String op, int seconds) {
        Intent i = new Intent(this, ScreenCaptureActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(ScreenCaptureActivity.EXTRA_OP, op)
                .putExtra(ScreenCaptureActivity.EXTRA_SECONDS, seconds);
        launchCaptureActivity(i, "IRIS screen capture", "rec".equals(op) ? "Recording screen…" : "Taking screenshot…");
    }

    /** Launch the lock-screen-capable camera activity to record a short video. */
    private void beginVideoRecording(int seconds, String camWord) {
        if (!hasPermission(Manifest.permission.CAMERA)) {
            String m = "I need camera permission to record video — opening settings so you can allow it.";
            broadcastMessage(m);
            try {
                startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        android.net.Uri.parse("package:" + getPackageName()))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception ignored) { }
            speakThenRun(m, this::rearmAfterAction);
            return;
        }
        final boolean front = camWord != null
                && (camWord.toLowerCase(Locale.ROOT).startsWith("front") || camWord.toLowerCase(Locale.ROOT).startsWith("selfie"));
        final int secs = seconds > 0 ? Math.min(seconds, 3600) : 60;
        String intro = "Recording " + humanizeDuration(secs) + " on the " + (front ? "front" : "back") + " camera.";
        broadcastMessage(intro);
        speakThenRun(intro, () -> {
            pauseListeningForCapture();
            Intent i = new Intent(this, LockedCaptureActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra(LockedCaptureActivity.EXTRA_SECONDS, secs)
                    .putExtra(LockedCaptureActivity.EXTRA_FRONT, front);
            launchCaptureActivity(i, "IRIS camera", "Recording video…");
        });
    }

    /** Take a single still photo (not video) via the same lock-screen-capable camera activity. */
    private void handleTakePhoto(String camWord) {
        if (!hasPermission(Manifest.permission.CAMERA)) {
            String m = "I need camera permission to take a photo — opening settings so you can allow it.";
            broadcastMessage(m);
            try {
                startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        android.net.Uri.parse("package:" + getPackageName()))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception ignored) { }
            speakThenRun(m, this::rearmAfterAction);
            return;
        }
        final boolean front = camWord != null
                && (camWord.toLowerCase(Locale.ROOT).startsWith("front") || camWord.toLowerCase(Locale.ROOT).startsWith("selfie"));
        String intro = "Taking a photo on the " + (front ? "front" : "back") + " camera.";
        broadcastMessage(intro);
        speakThenRun(intro, () -> {
            pauseListeningForCapture();
            Intent i = new Intent(this, LockedCaptureActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra(LockedCaptureActivity.EXTRA_MODE, "photo")
                    .putExtra(LockedCaptureActivity.EXTRA_FRONT, front);
            launchCaptureActivity(i, "IRIS camera", "Taking a photo\u2026");
        });
    }

    /** Camera requests use a resumed-activity acknowledgement and a tappable fallback.
     * A foreground service alone does not guarantee permission to launch a background activity.
     * Screen capture retains its existing Android consent flow. */
    private void launchCaptureActivity(Intent i, String title, String text) {
        if (i.getComponent() != null && i.getComponent().getClassName().equals(LockedCaptureActivity.class.getName())) {
            launchLockCamera(i);
            return;
        }
        boolean launched = false;
        try { startActivity(i); launched = true; } catch (Throwable ignored) { }
        if (launched) return;
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            boolean canFsi = Build.VERSION.SDK_INT < 34 || nm == null || nm.canUseFullScreenIntent();
            PendingIntent pi = PendingIntent.getActivity(this, 9, i,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification.Builder b = new Notification.Builder(this, CALL_CHANNEL)
                    .setSmallIcon(R.drawable.ic_iris).setContentTitle(title).setContentText(text)
                    .setCategory(Notification.CATEGORY_CALL).setAutoCancel(true);
            if (canFsi) b.setFullScreenIntent(pi, true);
            else b.setContentIntent(pi);   // FSI permission revoked — tappable notification instead
            if (nm != null) nm.notify(0xC0DE, b.build());
            if (!canFsi) {
                String m = title + " is ready \u2014 tap the notification to open it.";
                broadcastMessage(m); speak(m);
            }
        } catch (Exception e) {
            try { startActivity(i); } catch (Exception ignored) { }
        }
    }

    private void clearCameraLaunch() {
        if (cameraLaunchTimeout != null) handler.removeCallbacks(cameraLaunchTimeout);
        cameraLaunchTimeout = null;
        if (cameraLaunchIntent != null) cameraLaunchIntent.cancel();
        cameraLaunchIntent = null;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(CAMERA_LAUNCH_NOTIFICATION);
    }

    /** startActivity may be silently blocked. A visible, user-tappable fallback is always posted. */
    private void launchLockCamera(Intent target) {
        clearCameraLaunch();
        final NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        final String channel = "iris_camera_launch";
        boolean canNotify = nm != null && nm.areNotificationsEnabled()
                && (Build.VERSION.SDK_INT < 33 || hasPermission(Manifest.permission.POST_NOTIFICATIONS));
        if (canNotify) {
            nm.createNotificationChannel(new NotificationChannel(channel, "Camera requests", NotificationManager.IMPORTANCE_HIGH));
            cameraLaunchIntent = PendingIntent.getActivity(this, 91, target,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            nm.notify(CAMERA_LAUNCH_NOTIFICATION, new Notification.Builder(this, channel)
                    .setSmallIcon(R.drawable.ic_iris).setContentTitle("IRIS camera requested")
                    .setContentText("Tap to open the camera if it hasn't appeared")
                    .setContentIntent(cameraLaunchIntent).setAutoCancel(true).setTimeoutAfter(60000).build());
        }
        try { startActivity(target); } catch (Exception ignored) { }
        final boolean notificationAvailable = canNotify;
        handler.postDelayed(() -> {
            if (cameraLaunchTimeout != null && LockedCaptureActivity.instance == null) {
                // Android blocked the launch silently. Say it out loud — the user is very
                // likely looking at a lock screen, not at IRIS.
                String m = notificationAvailable
                        ? "If the camera hasn't appeared, tap the IRIS camera notification on your lock screen."
                        : "If the camera hasn't appeared, unlock once and enable IRIS notifications, then try again.";
                broadcastMessage(m);
                speak(m);
            }
        }, 2500);
        cameraLaunchTimeout = () -> {
            clearCameraLaunch();
            String m = "Camera request expired before it opened. Please try again.";
            broadcastMessage(m);
            speakThenRun(m, this::rearmAfterAction);
        };
        handler.postDelayed(cameraLaunchTimeout, 60000);
    }

    /** Parse a spoken number + optional unit into seconds ("m"/minutes → ×60), or fallback. */
    private int parseSecs(String numStr, String unitStr, int fallback) {
        if (numStr == null) return fallback;
        try {
            int n = Integer.parseInt(numStr);
            String u = unitStr == null ? "" : unitStr.toLowerCase(Locale.ROOT);
            return u.startsWith("m") ? n * 60 : n;
        } catch (Exception e) { return fallback; }
    }

    /** Parse a spoken duration anywhere in the phrase: seconds/minutes/hours, digits or words,
     *  "a/an" = 1, "half an hour" = 30 min. Returns fallback when none is present. */
    private int parseDuration(String s, int fallbackSecs) {
        if (s == null) return fallbackSecs;
        String t = s.toLowerCase(Locale.ROOT);
        if (t.matches(".*\\bhalf\\s+(?:an?\\s+)?hour\\b.*")) return clampDur(1800, fallbackSecs);
        if (t.matches(".*\\bhalf\\s+(?:a\\s+)?(?:minute|min)\\b.*")) return clampDur(30, fallbackSecs);
        Matcher m = Pattern.compile(
                "\\b(\\d+|an|a|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty|forty|fifty|sixty|ninety|hundred)"
                + "\\s*(hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\\b",
                Pattern.CASE_INSENSITIVE).matcher(t);
        if (m.find()) {
            int qty = wordToNum(m.group(1));
            String u = m.group(2).toLowerCase(Locale.ROOT);
            int mult = u.startsWith("h") ? 3600 : (u.startsWith("m") ? 60 : 1);
            return clampDur(qty * mult, fallbackSecs);
        }
        Matcher n = Pattern.compile("\\b(\\d+)\\b").matcher(t);
        if (n.find()) { try { return clampDur(Integer.parseInt(n.group(1)), fallbackSecs); } catch (Exception e) { return fallbackSecs; } }
        return fallbackSecs;
    }

    private static int clampDur(int secs, int fallback) {
        if (secs <= 0) return fallback;
        return Math.min(secs, 3600);
    }

    private static int wordToNum(String w) {
        if (w == null) return 1;
        w = w.trim().toLowerCase(Locale.ROOT);
        try { return Integer.parseInt(w); } catch (Exception ignored) { }
        switch (w) {
            case "a": case "an": case "one": return 1;
            case "two": return 2; case "three": return 3; case "four": return 4;
            case "five": return 5; case "six": return 6; case "seven": return 7;
            case "eight": return 8; case "nine": return 9; case "ten": return 10;
            case "fifteen": return 15; case "twenty": return 20; case "thirty": return 30;
            case "forty": return 40; case "fifty": return 50; case "sixty": return 60;
            case "ninety": return 90; case "hundred": return 100;
            default: return 1;
        }
    }

    /** Human-friendly duration, e.g. 90 → "1 minute 30 seconds", 3600 → "1 hour". */
    private static String humanizeDuration(int secs) {
        if (secs >= 3600 && secs % 3600 == 0) { int h = secs / 3600; return h + (h == 1 ? " hour" : " hours"); }
        if (secs >= 60) {
            int mm = secs / 60, ss = secs % 60;
            String out = mm + (mm == 1 ? " minute" : " minutes");
            if (ss > 0) out += " " + ss + (ss == 1 ? " second" : " seconds");
            return out;
        }
        return secs + (secs == 1 ? " second" : " seconds");
    }

    private String extractMicWord(String s) {
        if (s == null) return null;
        String t = s.toLowerCase(Locale.ROOT);
        if (t.contains("bluetooth") || t.matches(".*\\bbt\\b.*")) return "bluetooth";
        if (t.contains("earphone") || t.contains("earbud") || t.contains("headset")
                || t.contains("headphone") || t.contains("wired") || t.contains("usb")) return "headset";
        if (t.contains("phone mic") || t.contains("built-in") || t.contains("built in")
                || t.contains("internal") || t.contains("phone microphone")) return "phone";
        return null;
    }

    private String extractCamWord(String s) {
        if (s == null) return null;
        String t = s.toLowerCase(Locale.ROOT);
        if (t.contains("front") || t.contains("selfie")) return "front";
        if (t.contains("back") || t.contains("rear")) return "back";
        return null;
    }

    /**
     * Phase 2 — the user just answered a clarifying question ("What time?"). Fill the missing
     * slot and re-issue the request as a complete command, so the existing proven handlers
     * execute it. No new execution path is introduced.
     */
    private void handleClarificationAnswer(String answer) {
        Plan plan = pendingPlan;
        pendingPlan = null;
        String a = answer == null ? "" : answer.trim();
        if (plan == null) { rearmAfterAction(); return; }
        String low = a.toLowerCase(Locale.ROOT);
        if (a.isEmpty() || low.matches("^(stop|cancel|never mind|nevermind|forget it|nothing)$")) {
            LogStore.append(this, "CLARIFY", "cancelled");
            String m = "Okay, cancelled.";
            broadcastMessage(m); speakThenRun(m, this::rearmAfterAction);
            return;
        }
        String field = plan.firstMissing();
        String completed;
        switch (plan.intent()) {
            case SET_ALARM:
                if (IntentParser.extractTime(a).isEmpty()) {
                    // Still no usable time — say so instead of setting something wrong.
                    reply("I didn't catch a time, so I haven't set an alarm.");
                    return;
                }
                completed = "set an alarm for " + a;
                break;
            case SET_TIMER:
                if (IntentParser.extractDuration(a).isEmpty()) {
                    reply("I didn't catch a length, so I haven't set a timer.");
                    return;
                }
                completed = "set a timer for " + a;
                break;
            case CALL_CONTACT:
                completed = "call " + a;
                break;
            default:
                completed = a;
        }
        LogStore.append(this, "CLARIFY", field + " = \u201C" + a + "\u201D \u2192 " + completed);
        final String toRun = completed;
        handler.post(() -> handleCommand(toRun));
    }

    // ─────────────── Phase 3: action-ledger backed answers ───────────────

    /** "Where did you save it?" — answered from the ledger, not from memory of the sentence. */
    private void handleWhereSaved() {
        ActionLedger.Record r = null;
        try { r = ledger().last(); } catch (Throwable ignored) { }
        if (r == null) { reply("I haven't saved anything yet."); return; }
        if (r.location == null || r.location.isEmpty()) {
            reply("My last action was " + ActionLedger.spoken(r) + ", which didn't save a file.");
            return;
        }
        reply(ActionLedger.spoken(r) + ", saved to " + r.location + ".");
    }

    /** "Send the last screenshot/video/voice memo" — finds the real file and opens the share sheet. */
    private void handleSendLast(String what) {
        RecentMedia.Kind kind = RecentMedia.kindFrom(what);
        if (kind == null) {
            // "send the last one" — infer from the most recent capture we logged.
            ActionLedger.Record r = null;
            try { r = ledger().last(); } catch (Throwable ignored) { }
            String hint = r == null ? "" : r.intent;
            kind = hint.contains("screenshot") ? RecentMedia.Kind.IMAGE
                    : hint.contains("voice") ? RecentMedia.Kind.AUDIO
                    : hint.contains("video") || hint.contains("screen_recording") ? RecentMedia.Kind.VIDEO
                    : RecentMedia.Kind.IMAGE;
        }
        RecentMedia.Item item = RecentMedia.newest(this, kind);
        if (item == null) {
            reply("I couldn't find a recent " + describeKind(kind) + " to send.");
            return;
        }
        final RecentMedia.Item toSend = item;
        // Read it back before sharing — sending a file reaches other people (§12).
        String confirm = "The latest " + describeKind(kind) + " is " + toSend.name
                + ". Opening the share sheet so you can pick who gets it.";
        broadcastMessage(confirm);
        speakThenRun(confirm, () -> {
            try {
                Intent share = new Intent(Intent.ACTION_SEND)
                        .setType(toSend.mime)
                        .putExtra(Intent.EXTRA_STREAM, toSend.uri)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(share, "Send with")
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                ledger().record("share", ActionLedger.OK, "Opened share sheet for " + toSend.name + "; delivery unverified", "", "", false);
                LogStore.append(this, "SHARE", toSend.name);
                rearmAfterAction();
            } catch (Throwable t) {
                reply("I couldn't open the share sheet.");
            }
        });
    }

    private static String describeKind(RecentMedia.Kind kind) {
        switch (kind) {
            case VIDEO: return "video";
            case AUDIO: return "recording";
            default: return "screenshot";
        }
    }

    /** "Undo that" — currently supports cancelling the last reminder IRIS scheduled. */
    private void handleUndo() {
        ActionLedger.Record r = null;
        try { r = ledger().lastReversible(); } catch (Throwable ignored) { }
        if (r == null) { reply("There's nothing I can undo."); return; }
        if ("reminder".equals(r.intent)) {
            try {
                String[] parts = r.ref.split("\\|", 2);
                int requestCode = Integer.parseInt(parts[0]);
                Intent i = new Intent(this, ReminderReceiver.class);
                int flags = PendingIntent.FLAG_UPDATE_CURRENT
                        | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
                PendingIntent pi = PendingIntent.getBroadcast(this, requestCode, i, flags);
                ((android.app.AlarmManager) getSystemService(ALARM_SERVICE)).cancel(pi);
                pi.cancel();
                ledger().markUndone(r.id);
                LogStore.append(this, "UNDO", "cancelled reminder " + requestCode);
                reply("Cancelled that reminder.");
                return;
            } catch (Throwable t) {
                LogStore.append(this, "UNDO", "failed: " + t);
                reply("I couldn't cancel that reminder.");
                return;
            }
        }
        reply("I can't undo " + ActionLedger.spoken(r) + ".");
    }

    /**
     * Phase 5 — ask the local model for a validated plan, off the main thread.
     * Returns true if we took ownership of this utterance (so the caller must not also reply).
     *
     * The plan is never executed directly: it is converted back into a canonical command string
     * and routed through the same proven handlers, so no new execution path exists.
     */
    private boolean tryLocalPlanner(final String original, final String normalized, final ProfileStore store) {
        try {
            final LlmAgent agent = llmAgent;
            final LocalPlanner planner = new LocalPlanner(new LocalPlanner.Engine() {
                @Override public boolean ready() { return agent != null && agent.isReady(); }
                @Override public String generate(String prompt) { return agent.generateRaw(prompt); }
            });
            if (!planner.available()) return false;
            broadcastMessage("Thinking\u2026");
            final java.util.List<String> ctxLines = new java.util.ArrayList<>();
            try {
                for (ActionLedger.Record r : ledger().recent(5)) {
                    ctxLines.add(r.intent + ": " + r.summary
                            + (r.location == null || r.location.isEmpty() ? "" : " (" + r.location + ")"));
                }
            } catch (Throwable ignored) { }
            final String ctx = LocalPlanner.contextFrom(ctxLines);
            new Thread(() -> {
                Plan plan;
                try { plan = planner.plan(original, ctx); }
                catch (Throwable t) { plan = Plan.unknown(); }
                final Plan result = plan;
                handler.post(() -> {
                    if (result.isUnknown()) {
                        // Planner had nothing trustworthy — carry on as conversation.
                        LogStore.append(this, "PLANNER", "no usable plan for: " + original);
                        offlineChat(original, normalized, store);
                        return;
                    }
                    LogStore.append(this, "PLANNER", result.toString());
                    if (!result.isComplete()) {
                        String q = IntentParser.clarifyQuestion(result);
                        if (!q.isEmpty()) {
                            pendingPlan = result;
                            broadcastMessage(q);
                            nextOutputMinor = true;
                            speakThenRun(q, this::startCommandRecognition);
                            return;
                        }
                        offlineChat(original, normalized, store);
                        return;
                    }
                    String command = commandFor(result);
                    if (command.isEmpty()) { offlineChat(original, normalized, store); return; }
                    // Sensitive plans are read back by the handler they route into.
                    handleCommand(command);
                });
            }, "IRIS-Planner").start();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Turn a validated plan into the canonical phrasing the existing handlers already accept. */
    private String commandFor(Plan plan) {
        if (plan == null) return "";
        // App plans must contain exactly one matching, validated tool. Never ignore extra steps.
        if (plan.intent() == IrisIntent.APP_SEARCH || plan.intent() == IrisIntent.APP_SHARE) {
            AppRequest r = AppRequest.fromPlan(plan);
            if (r == null) return "";
            if (r.action.equals("search")) return "search " + r.value + " on " + r.app;
            if (r.action.equals("share_media")) return "share the latest " + r.value + " via " + r.app;
            return "share via " + r.app + ": " + r.value;
        }
        switch (plan.intent()) {
            case SET_ALARM:       return "set an alarm for " + plan.entity("time");
            case SET_TIMER:       return "set a timer for " + plan.entity("duration");
            case CALL_CONTACT:    return "call " + plan.entity("recipient");
            case TAKE_SCREENSHOT: return "take a screenshot";
            case TAKE_PHOTO:      return "take " + ("front".equals(plan.entity("camera")) ? "a selfie" : "a photo");
            case TORCH:           return "torch " + plan.entity("state");
            case RECORD_SCREEN:   return "record the screen"
                    + (plan.entity("duration").isEmpty() ? "" : " for " + plan.entity("duration"));
            case RECORD_VIDEO:    return "record " + ("front".equals(plan.entity("camera")) ? "front " : "")
                    + "camera video"
                    + (plan.entity("duration").isEmpty() ? "" : " " + plan.entity("duration"));
            case RECORD_VOICE:    return "record voice"
                    + (plan.entity("duration").isEmpty() ? "" : " " + plan.entity("duration"));
            case PHONE_STATUS:    return "phone status";
            case READ_NOTIFICATIONS: return "read my notifications";
            default:              return "";
        }
    }

    private void handleAppIntegration(AppRequest request) {
        KeyguardManager keyguard = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        // Sharing/search payloads can be private, regardless of the camera lock-screen setting.
        if (keyguard != null && keyguard.isKeyguardLocked()) {
            reply("Please unlock your phone and repeat that app request.");
            return;
        }
        try {
            AppIntegrations.Prepared prepared = AppIntegrations.prepare(this, request);
            if (prepared.intent == null) { reply(prepared.message); return; }
            startActivity(prepared.intent);
            ledger().record("app_" + request.action, ActionLedger.OK,
                    "Requested " + request.action + " in " + request.app + "; completion unverified",
                    "", "", false);
            reply(prepared.message);
        } catch (Exception error) {
            reply("I couldn't open that app action. Nothing was confirmed as sent.");
        }
    }

    /** Open the command window immediately (used by notification/tile/headset/shake/assist triggers). */
    private void triggerTalk(String source) {
        if (memoRecorder != null && memoRecorder.isRecording()) return;
        if (PHASE_COMMAND.equals(phase)) return;   // already listening
        try { if (voskEngine != null) voskEngine.stop(); } catch (Exception ignored) { }
        vibrate(45);
        broadcastState(true, PHASE_COMMAND);
        String greet = wakeGreeting();
        broadcastMessage(greet);
        nextOutputMinor = true;                     // a greeting isn't worth a notification
        speakThenRun(greet, this::startCommandRecognition);
        LogStore.append(this, "TRIGGER", source == null ? "manual" : source);
    }

    /** Start a timed voice memo. Speaks first (pausing music), then records so our own voice isn't captured. */
    private void beginVoiceRecording(int seconds, String micWord) {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
            String m = "I need microphone permission to record.";
            broadcastMessage(m); speakThenRun(m, this::rearmAfterAction); return;
        }
        if (memoRecorder != null && memoRecorder.isRecording()) { inform("I'm already recording."); return; }
        final AudioDeviceInfo dev = resolveInputDevice(micWordToPreference(micWord));
        final String micName = dev != null ? readableDeviceName(dev) : "the phone mic";
        final int cappedSecs = seconds > 0 ? Math.min(seconds, 3600) : 60;   // default 1 minute
        final int durMs = cappedSecs * 1000;
        String intro = "Recording " + humanizeDuration(cappedSecs) + " using " + micName + ".";
        broadcastMessage(intro);
        speakThenRun(intro, () -> {
            pauseListeningForCapture();
            showRecordingNotification();
            memoRecorder = new MediaMemoRecorder(this);
            memoRecorder.start(durMs, dev, micName, new MediaMemoRecorder.Listener() {
                @Override public void onStarted(String mic) {
                    LogStore.append(IrisListeningService.this, "RECORD", "started via " + mic);
                }
                @Override public void onSaved(String location, int secs) {
                    restoreListeningNotification();
                    String m = "Saved a " + secs + " second recording to " + location + ".";
                    try { ledger().recordSaved("voice_memo", "Recorded a " + secs + " second voice memo", location); } catch (Throwable ignored) { }
                    broadcastMessage(m); speakThenRun(m, IrisListeningService.this::rearmAfterAction);
                    LogStore.append(IrisListeningService.this, "RECORD", m);
                }
                @Override public void onError(String message) {
                    restoreListeningNotification();
                    broadcastMessage(message); speakThenRun(message, IrisListeningService.this::rearmAfterAction);
                }
            });
        });
    }

    private void stopVoiceRecording() {
        if (memoRecorder != null && memoRecorder.isRecording()) {
            memoRecorder.stop();   // fires onSaved → notification restored + re-arm
        } else {
            String m = "Nothing is recording right now.";
            broadcastMessage(m); speakThenRun(m, this::rearmAfterAction);
        }
    }

    /** Free the mic (stop wake/command listening) so MediaRecorder can grab it. */
    private void pauseListeningForCapture() {
        if (commandTimeout != null) { handler.removeCallbacks(commandTimeout); commandTimeout = null; }
        try { destroyRecognizer(); } catch (Exception ignored) { }
        try { if (voskEngine != null) voskEngine.stop(); } catch (Exception ignored) { }
    }

    private String micWordToPreference(String w) {
        if (w == null) return settings.preferredMicrophone();
        String m = w.toLowerCase(Locale.ROOT);
        if (m.startsWith("phone") || m.contains("built") || m.contains("internal")) return "Phone";
        if (m.contains("bluetooth") || m.equals("bt")) return "Bluetooth";
        if (m.contains("ear") || m.contains("headset") || m.contains("headphone")
                || m.contains("wired") || m.contains("usb")) return "Wired / USB";
        return settings.preferredMicrophone();
    }

    private AudioDeviceInfo resolveInputDevice(String preference) {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (am == null) return null;
            return chooseDevice(arrayToList(am.getDevices(AudioManager.GET_DEVICES_INPUTS)), preference);
        } catch (Exception e) { return null; }
    }

    private void showRecordingNotification() {
        try {
            Intent stopRec = new Intent(this, IrisListeningService.class).setAction(ACTION_STOP_RECORDING);
            PendingIntent stopPending = PendingIntent.getService(this, 7, stopRec,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, LISTENING_CHANNEL)
                    .setSmallIcon(R.drawable.ic_iris).setContentTitle("IRIS is recording")
                    .setContentText("Voice memo in progress").setOngoing(true).setOnlyAlertOnce(true)
                    .setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT))
                    .addAction(new Notification.Action.Builder(null, "Stop recording", stopPending).build())
                    .build();
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(LISTENING_NOTIFICATION, n);
        } catch (Exception ignored) { }
    }

    private void restoreListeningNotification() {
        try {
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .notify(LISTENING_NOTIFICATION, listeningNotification());
        } catch (Exception ignored) { }
    }

    /** Full rundown: ringer, DND, airplane, internet/Wi-Fi, Bluetooth, battery. */
    private void handlePhoneStatus() {
        StringBuilder sb = new StringBuilder();
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        int rm = am != null ? am.getRingerMode() : AudioManager.RINGER_MODE_NORMAL;
        String ring = rm == AudioManager.RINGER_MODE_SILENT ? "on silent"
                : rm == AudioManager.RINGER_MODE_VIBRATE ? "on vibrate" : "on normal ring";
        sb.append("Ringer is ").append(ring).append(". ");
        boolean dnd = nm != null && Build.VERSION.SDK_INT >= 23
                && nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL;
        sb.append("Do Not Disturb is ").append(dnd ? "on" : "off").append(". ");
        sb.append("Airplane mode is ").append(airplaneOn() ? "on" : "off").append(". ");
        sb.append(connectivitySummary());
        sb.append(bluetoothSummary());
        sb.append(batterySummary());
        sb.append(deviceSummary());
        sb.append(storageSummary());
        sb.append(memorySummary());
        sb.append(uptimeSummary());
        String spoken = sb.toString().trim();
        // Notification/watch mirror gets a dense, "hacker terminal" formatted line — the on-screen
        // status is spoken/notification-only (there's no dedicated status screen), so this is
        // where the techy presentation actually shows up.
        postTechyStatusNotification();
        inform(spoken);
    }

    /** Dense [SYS]-style status line for the notification mirror — the "hacker vibe" presentation. */
    private void postTechyStatusNotification() {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            NotificationManager nmgr = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            int rm = am != null ? am.getRingerMode() : AudioManager.RINGER_MODE_NORMAL;
            String ring = rm == AudioManager.RINGER_MODE_SILENT ? "SILENT"
                    : rm == AudioManager.RINGER_MODE_VIBRATE ? "VIBRATE" : "NORMAL";
            boolean dnd = nmgr != null && Build.VERSION.SDK_INT >= 23
                    && nmgr.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL;
            android.os.StatFs stat = new android.os.StatFs(getFilesDir().getPath());
            long freeGb = stat.getAvailableBytes() / (1024L * 1024 * 1024);
            long totalGb = stat.getTotalBytes() / (1024L * 1024 * 1024);
            android.app.ActivityManager amgr = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            long ramPct = -1;
            if (amgr != null) { amgr.getMemoryInfo(mi); ramPct = mi.totalMem > 0 ? Math.round(100.0 * (mi.totalMem - mi.availMem) / mi.totalMem) : -1; }
            Intent b = batteryIntent();
            int pct = -1;
            if (b != null) {
                int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                pct = (level >= 0 && scale > 0) ? Math.round(level * 100f / scale) : -1;
            }
            android.bluetooth.BluetoothManager bm =
                    (android.bluetooth.BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
            android.bluetooth.BluetoothAdapter ba = bm != null ? bm.getAdapter() : null;
            String bt = ba != null && ba.isEnabled() ? connectedBluetoothDeviceName(ba) : null;

            String line1 = "[SYS] " + Build.MANUFACTURER.toUpperCase(Locale.ROOT) + " " + Build.MODEL
                    + " \u00b7 ANDROID " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")";
            String line2 = "[PWR] BATT " + (pct >= 0 ? pct + "%" : "?") + (isCharging() ? " \u26A1CHG" : "")
                    + " \u00b7 RAM " + (ramPct >= 0 ? ramPct + "%" : "?") + " \u00b7 STOR " + freeGb + "/" + totalGb + "GB";
            String line3 = "[NET] " + connectivitySummary().replace("Connected to the internet ", "")
                    .replace("Not connected to the internet. ", "OFFLINE ").trim()
                    + " \u00b7 RINGER " + ring + (dnd ? " \u00b7 DND" : "")
                    + " \u00b7 BT " + (bt != null ? bt.toUpperCase(Locale.ROOT) : (ba != null && ba.isEnabled() ? "IDLE" : "OFF"));
            String dense = line1 + "\n" + line2 + "\n" + line3;

            if (Build.VERSION.SDK_INT >= 26 && nmgr != null && nmgr.getNotificationChannel("iris_output") == null) {
                nmgr.createNotificationChannel(new NotificationChannel("iris_output", "IRIS replies",
                        NotificationManager.IMPORTANCE_DEFAULT));
            }
            Notification.Builder nb = (Build.VERSION.SDK_INT >= 26)
                    ? new Notification.Builder(this, "iris_output") : new Notification.Builder(this);
            Notification n = nb.setSmallIcon(R.drawable.ic_iris).setContentTitle("IRIS \u25B8 SYSTEM STATUS")
                    .setStyle(new Notification.BigTextStyle().bigText(dense))
                    .setContentText(line1)
                    .setAutoCancel(true).build();
            if (nmgr != null) nmgr.notify(0x1816, n);
        } catch (Throwable ignored) { }
    }

    /** Device model + Android version — spoken. */
    private String deviceSummary() {
        try {
            return "Running " + Build.MANUFACTURER + " " + Build.MODEL + " on Android "
                    + Build.VERSION.RELEASE + ". ";
        } catch (Throwable t) { return ""; }
    }

    /** Free vs total internal storage. */
    private String storageSummary() {
        try {
            android.os.StatFs stat = new android.os.StatFs(getFilesDir().getPath());
            long freeGb = (stat.getAvailableBytes()) / (1024L * 1024 * 1024);
            long totalGb = (stat.getTotalBytes()) / (1024L * 1024 * 1024);
            return "Storage: " + freeGb + " of " + totalGb + " gigabytes free. ";
        } catch (Throwable t) { return ""; }
    }

    /** Free vs total RAM + low-memory flag. */
    private String memorySummary() {
        try {
            android.app.ActivityManager amgr =
                    (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (amgr == null) return "";
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            amgr.getMemoryInfo(mi);
            long usedPct = mi.totalMem > 0 ? Math.round(100.0 * (mi.totalMem - mi.availMem) / mi.totalMem) : -1;
            String s = usedPct >= 0 ? "Memory: " + usedPct + " percent in use" : "";
            if (mi.lowMemory) s += " — running low";
            return s.isEmpty() ? "" : s + ". ";
        } catch (Throwable t) { return ""; }
    }

    /** How long since boot. */
    private String uptimeSummary() {
        try {
            long ms = android.os.SystemClock.elapsedRealtime();
            long h = ms / 3_600_000, m = (ms / 60_000) % 60;
            return "Up for " + (h > 0 ? h + "h " : "") + m + "m. ";
        } catch (Throwable t) { return ""; }
    }

    /** Standalone "what's connected via Bluetooth?" answer. */
    private void handleBluetoothQuery() {
        try {
            android.bluetooth.BluetoothManager bm =
                    (android.bluetooth.BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
            android.bluetooth.BluetoothAdapter ba = bm != null ? bm.getAdapter()
                    : android.bluetooth.BluetoothAdapter.getDefaultAdapter();
            if (ba == null || !ba.isEnabled()) { inform("Bluetooth is off."); return; }
            String name = connectedBluetoothDeviceName(ba);
            inform(name != null ? "Connected to " + name + " over Bluetooth."
                    : "Bluetooth is on, but nothing is connected right now.");
        } catch (Throwable t) { inform("I couldn't check Bluetooth."); }
    }

    private String connectivitySummary() {
        try {
            android.net.ConnectivityManager cm =
                    (android.net.ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm == null) return "";
            if (Build.VERSION.SDK_INT >= 23) {
                android.net.Network net = cm.getActiveNetwork();
                android.net.NetworkCapabilities cap = net == null ? null : cm.getNetworkCapabilities(net);
                boolean online = cap != null
                        && cap.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
                if (!online) return "Not connected to the internet. ";
                if (cap.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI))
                    return "Connected to the internet over Wi-Fi. ";
                if (cap.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR))
                    return "Connected to the internet over mobile data. ";
                return "Connected to the internet. ";
            }
            android.net.NetworkInfo ni = cm.getActiveNetworkInfo();
            if (ni == null || !ni.isConnected()) return "Not connected to the internet. ";
            return ni.getType() == android.net.ConnectivityManager.TYPE_WIFI
                    ? "Connected to the internet over Wi-Fi. " : "Connected to the internet over mobile data. ";
        } catch (Exception e) { return ""; }
    }

    private String bluetoothSummary() {
        try {
            android.bluetooth.BluetoothManager bm =
                    (android.bluetooth.BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
            android.bluetooth.BluetoothAdapter ba = bm != null ? bm.getAdapter()
                    : android.bluetooth.BluetoothAdapter.getDefaultAdapter();
            if (ba == null) return "";
            if (!ba.isEnabled()) return "Bluetooth is off. ";
            String name = connectedBluetoothDeviceName(ba);
            return name != null ? "Connected to " + name + " over Bluetooth. " : "Bluetooth is on, nothing connected. ";
        } catch (Exception e) { return ""; }
    }

    /** The name of the currently-connected Bluetooth audio device, or null if none. */
    private String connectedBluetoothDeviceName(android.bluetooth.BluetoothAdapter ba) {
        try {
            if (Build.VERSION.SDK_INT >= 31 && !hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) return null;
            int a2dp = ba.getProfileConnectionState(android.bluetooth.BluetoothProfile.A2DP);
            int headset = ba.getProfileConnectionState(android.bluetooth.BluetoothProfile.HEADSET);
            if (a2dp != android.bluetooth.BluetoothProfile.STATE_CONNECTED
                    && headset != android.bluetooth.BluetoothProfile.STATE_CONNECTED) return null;
            // A connected profile confirms *something* is connected; identify it via the bonded
            // set (public API — no async profile-proxy round trip needed for a name lookup).
            java.util.Set<android.bluetooth.BluetoothDevice> bonded = ba.getBondedDevices();
            if (bonded == null) return null;
            for (android.bluetooth.BluetoothDevice d : bonded) {
                try {
                    java.lang.reflect.Method m = d.getClass().getMethod("isConnected");
                    Object connected = m.invoke(d);
                    if (Boolean.TRUE.equals(connected)) return d.getName();
                } catch (Throwable ignored) { }
            }
            // Reflection unavailable/blocked — fall back to the most recently bonded device name
            // rather than reporting nothing when we already know a profile IS connected.
            for (android.bluetooth.BluetoothDevice d : bonded) return d.getName();
            return null;
        } catch (Throwable t) { return null; }
    }

    private String batterySummary() {
        try {
            Intent b = batteryIntent();
            if (b == null) return "";
            int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int pct = (level >= 0 && scale > 0) ? Math.round(level * 100f / scale) : -1;
            String s = pct >= 0 ? "Battery is at " + pct + " percent" : "Battery level unknown";
            if (isCharging()) s += " and charging";
            return s + ".";
        } catch (Exception e) { return ""; }
    }

    /** Speak + broadcast a short status line, then return to listening. */
    private void inform(String msg) {
        broadcastMessage(msg);
        speakThenRun(msg, this::rearmAfterAction);
        lastActionSummary = msg;
        LogStore.append(this, "MODE", msg);
    }

    private static String canonMode(String raw) {
        String m = raw == null ? "" : raw.toLowerCase(Locale.ROOT).trim();
        if (m.startsWith("silent")) return "silent";
        if (m.startsWith("vibrate")) return "vibrate";
        if (m.startsWith("normal") || m.startsWith("ring")) return "normal";
        if (m.contains("disturb") || m.equals("dnd")) return "dnd";
        if (m.contains("plane") || m.equals("flight")) return "airplane";
        return "";
    }

    private boolean dndAccess() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        return Build.VERSION.SDK_INT < 23 || (nm != null && nm.isNotificationPolicyAccessGranted());
    }

    private boolean airplaneOn() {
        try {
            return android.provider.Settings.Global.getInt(getContentResolver(),
                    android.provider.Settings.Global.AIRPLANE_MODE_ON, 0) == 1;
        } catch (Exception e) { return false; }
    }

    /** Turn a phone mode on/off, checking current state and telling the user what happened. */
    private void handleModeSet(String actionRaw, String modeRaw, String trailingRaw) {
        String a = actionRaw == null ? "" : actionRaw.toLowerCase(Locale.ROOT);
        String t = trailingRaw == null ? "" : trailingRaw.toLowerCase(Locale.ROOT);
        boolean turnOff = a.contains("off") || a.startsWith("disable") || a.startsWith("stop")
                || a.startsWith("end") || "off".equals(t);
        boolean turnOn = !turnOff;
        String mode = canonMode(modeRaw);
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        try {
            switch (mode) {
                case "silent": {
                    boolean isOn = am.getRingerMode() == AudioManager.RINGER_MODE_SILENT;
                    if (turnOn) {
                        if (isOn) { inform("Silent mode is already on."); return; }
                        if (!dndAccess()) { requestDndAccess("silence the phone"); return; }
                        am.setRingerMode(AudioManager.RINGER_MODE_SILENT); inform("Silent mode on.");
                    } else {
                        if (!isOn) { inform("Silent mode is already off."); return; }
                        am.setRingerMode(AudioManager.RINGER_MODE_NORMAL); inform("Silent mode off — ringer is back to normal.");
                    }
                    return;
                }
                case "vibrate": {
                    boolean isOn = am.getRingerMode() == AudioManager.RINGER_MODE_VIBRATE;
                    if (turnOn) {
                        if (isOn) { inform("Vibrate mode is already on."); return; }
                        if (!dndAccess()) { requestDndAccess("switch to vibrate"); return; }
                        am.setRingerMode(AudioManager.RINGER_MODE_VIBRATE); inform("Vibrate mode on.");
                    } else {
                        if (!isOn) { inform("Vibrate mode is already off."); return; }
                        am.setRingerMode(AudioManager.RINGER_MODE_NORMAL); inform("Vibrate mode off — ringer is back to normal.");
                    }
                    return;
                }
                case "normal": {
                    if (am.getRingerMode() == AudioManager.RINGER_MODE_NORMAL) inform("The ringer is already normal.");
                    else { am.setRingerMode(AudioManager.RINGER_MODE_NORMAL); inform("Ringer set to normal."); }
                    return;
                }
                case "dnd": {
                    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    if (nm == null || Build.VERSION.SDK_INT < 23) { inform("Do Not Disturb isn't available here."); return; }
                    boolean isOn = nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL;
                    if (turnOn) {
                        if (isOn) { inform("Do Not Disturb is already on."); return; }
                        if (!dndAccess()) { requestDndAccess("turn on Do Not Disturb"); return; }
                        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
                        inform("Do Not Disturb on.");
                    } else {
                        if (!isOn) { inform("Do Not Disturb is already off."); return; }
                        if (!dndAccess()) { requestDndAccess("turn off Do Not Disturb"); return; }
                        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);
                        inform("Do Not Disturb off.");
                    }
                    return;
                }
                case "airplane": handleAirplane(turnOn); return;
                default: inform("I can set silent, vibrate, normal, Do Not Disturb, or airplane mode.");
            }
        } catch (Exception e) {
            inform("I couldn't change that mode.");
        }
    }

    /** Report whether a mode is currently on. */
    private void handleModeQuery(String modeRaw) {
        String mode = canonMode(modeRaw);
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        String msg;
        switch (mode) {
            case "silent":
                msg = "Silent mode is " + (am.getRingerMode() == AudioManager.RINGER_MODE_SILENT ? "on." : "off.");
                break;
            case "vibrate":
                msg = "Vibrate mode is " + (am.getRingerMode() == AudioManager.RINGER_MODE_VIBRATE ? "on." : "off.");
                break;
            case "normal":
                msg = am.getRingerMode() == AudioManager.RINGER_MODE_NORMAL ? "The ringer is normal."
                        : "The ringer isn't normal — it's " + (am.getRingerMode() == AudioManager.RINGER_MODE_SILENT ? "silent." : "on vibrate.");
                break;
            case "dnd":
                msg = "Do Not Disturb is " + (nm != null && Build.VERSION.SDK_INT >= 23
                        && nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL ? "on." : "off.");
                break;
            case "airplane":
                msg = "Airplane mode is " + (airplaneOn() ? "on." : "off.");
                break;
            default:
                msg = "I can check silent, vibrate, normal, Do Not Disturb, or airplane mode.";
        }
        inform(msg);
    }

    /** Airplane mode can't be toggled by apps — report state and open settings if a change is wanted. */
    private void handleAirplane(boolean turnOn) {
        boolean isOn = airplaneOn();
        if (turnOn == isOn) { inform("Airplane mode is already " + (isOn ? "on." : "off.")); return; }
        String msg = "I can't switch airplane mode directly — opening settings so you can toggle it.";
        broadcastMessage(msg);
        try {
            startActivity(new Intent(android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            try { startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception ignored) { }
        }
        speakThenRun(msg, this::rearmAfterAction);
        LogStore.append(this, "MODE", "airplane → open settings (was " + (isOn ? "on" : "off") + ")");
    }

    private void handleRinger(int mode) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 23 && nm != null && !nm.isNotificationPolicyAccessGranted()
                    && mode != AudioManager.RINGER_MODE_NORMAL) {
                requestDndAccess("change the ringer");
                return;
            }
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            am.setRingerMode(mode);
            String msg = mode == AudioManager.RINGER_MODE_SILENT ? "Phone silenced."
                    : mode == AudioManager.RINGER_MODE_VIBRATE ? "Vibrate mode on."
                    : "Ringer back to normal.";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "RINGER", msg);
        } catch (Exception e) {
            String m = "I couldn't change the ringer mode.";
            broadcastMessage(m); speakThenRun(m, this::rearmAfterAction);
        }
    }

    /** Toggle Do Not Disturb. Needs DND (notification policy) access. */
    private void handleDnd(boolean on) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT < 23 || nm == null) {
                String m = "Do Not Disturb isn't available on this phone.";
                broadcastMessage(m); speakThenRun(m, this::rearmAfterAction); return;
            }
            if (!nm.isNotificationPolicyAccessGranted()) { requestDndAccess("turn Do Not Disturb on or off"); return; }
            nm.setInterruptionFilter(on ? NotificationManager.INTERRUPTION_FILTER_PRIORITY
                    : NotificationManager.INTERRUPTION_FILTER_ALL);
            String msg = on ? "Do Not Disturb is on." : "Do Not Disturb is off.";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "DND", msg);
        } catch (Exception e) {
            String m = "I couldn't change Do Not Disturb.";
            broadcastMessage(m); speakThenRun(m, this::rearmAfterAction);
        }
    }

    private void requestDndAccess(String action) {
        String msg = "I need Do Not Disturb access to " + action + ". Please allow it for IRIS, then try again.";
        broadcastMessage(msg);
        try {
            startActivity(new Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) { }
        speakThenRun(msg, this::rearmAfterAction);
    }

    /** Play a local song/artist by name via any installed music app (offline). */
    private void handlePlaySong(String query) {
        if (query == null || query.trim().isEmpty()) { handleMediaControl("play"); return; }
        String q = query.trim();
        String lower = q.toLowerCase(Locale.ROOT);
        // Only use a video/streaming app when the user actually names one.
        boolean wantsYouTube = lower.matches(".*\\bon\\s+(youtube|you tube)\\b.*")
                || lower.matches(".*\\byoutube\\b.*");
        if (wantsYouTube) {
            q = q.replaceAll("(?i)\\s*\\bon\\s+(youtube|you tube)\\b", "")
                 .replaceAll("(?i)\\s*\\byoutube\\b", "").trim();
        }
        try {
            Intent i = new Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
            i.putExtra(android.provider.MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/audio");
            i.putExtra(android.app.SearchManager.QUERY, q);
            i.putExtra(android.provider.MediaStore.EXTRA_MEDIA_TITLE, q);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            // Pin it to an offline-capable music player unless YouTube was requested, so a
            // local track doesn't turn into a web/video search.
            String target = wantsYouTube ? null : pickMusicApp(i);
            if (target != null) i.setPackage(target);
            startActivity(i);
            String msg = "Playing " + q + ".";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "MEDIA", "Play from search: " + q
                    + (target == null ? "" : " via " + target));
        } catch (Exception e) {
            // Retry without a pinned package before giving up.
            try {
                Intent i2 = new Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                        .putExtra(android.app.SearchManager.QUERY, q)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i2);
                String msg = "Playing " + q + ".";
                broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            } catch (Exception e2) {
                String msg = "I couldn't find a music app to play that.";
                broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
                LogStore.append(this, "MEDIA", "Play failed: " + e2.getMessage());
            }
        }
    }

    /**
     * Choose an installed audio player for a play-from-search intent, skipping video/streaming
     * apps like YouTube. Returns null when there's no clear choice (let Android decide).
     */
    private String pickMusicApp(Intent intent) {
        try {
            android.content.pm.PackageManager pm = getPackageManager();
            java.util.List<android.content.pm.ResolveInfo> options =
                    pm.queryIntentActivities(intent, 0);
            if (options == null || options.isEmpty()) return null;
            String[] skip = { "youtube", "video", "tv", "browser", "chrome" };
            String[] prefer = { "music", "audio", "player", "poweramp", "spotify", "musicolet",
                    "gomusic", "samsung.android.app.music", "sec.android.app.music", "media" };
            String fallback = null;
            for (android.content.pm.ResolveInfo ri : options) {
                if (ri.activityInfo == null || ri.activityInfo.packageName == null) continue;
                String pkg = ri.activityInfo.packageName.toLowerCase(Locale.ROOT);
                boolean bad = false;
                for (String s : skip) if (pkg.contains(s)) { bad = true; break; }
                if (bad) continue;
                for (String p : prefer) if (pkg.contains(p)) return ri.activityInfo.packageName;
                if (fallback == null) fallback = ri.activityInfo.packageName;
            }
            return fallback;
        } catch (Throwable t) { return null; }
    }

    /** Adjust media volume. */
    private void handleVolume(String normalized) {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            int stream = AudioManager.STREAM_MUSIC;
            String msg;
            if (normalized.matches(".*\\b(mute)\\b.*")) {
                am.setStreamVolume(stream, 0, AudioManager.FLAG_SHOW_UI);
                msg = "Muted.";
            } else if (normalized.matches(".*\\b(unmute)\\b.*")) {
                int half = am.getStreamMaxVolume(stream) / 2;
                am.setStreamVolume(stream, half, AudioManager.FLAG_SHOW_UI);
                msg = "Unmuted.";
            } else if (normalized.matches(".*\\b(max|maximum)\\b.*")) {
                am.setStreamVolume(stream, am.getStreamMaxVolume(stream), AudioManager.FLAG_SHOW_UI);
                msg = "Volume maxed.";
            } else if (normalized.matches(".*\\b(down|lower|decrease)\\b.*")) {
                am.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
                msg = "Volume down.";
            } else {
                am.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
                msg = "Volume up.";
            }
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "VOLUME", msg);
        } catch (Exception e) {
            broadcastMessage("I couldn't change the volume.");
            speakThenRun("I couldn't change the volume.", this::rearmAfterAction);
        }
    }

    /** Open the WiFi/Bluetooth settings panel (toggling isn't allowed by Android). */
    private void handleConnectivity(String which) {
        boolean bt = which != null && which.toLowerCase(Locale.ROOT).startsWith("bluetooth");
        try {
            Intent i;
            if (bt) {
                i = new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                i = new Intent(android.provider.Settings.Panel.ACTION_WIFI);
            } else {
                i = new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS);
            }
            launchViaLock(i);
            String label = bt ? "Bluetooth" : "Wi-Fi";
            String msg = "Android won't let me flip that directly — here's " + label + " settings, toggle it here.";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "CONNECTIVITY", label);
        } catch (Exception e) {
            broadcastMessage("I couldn't open those settings.");
            speakThenRun("I couldn't open those settings.", this::rearmAfterAction);
        }
    }

    /** Do a web search in the browser. */
    private void handleWebSearch(String query) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)));
            launchViaLock(i);
            String msg = "Searching the web for " + query + ".";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "SEARCH", query);
        } catch (Exception e) {
            broadcastMessage("I couldn't open a browser.");
            speakThenRun("I couldn't open a browser.", this::rearmAfterAction);
        }
    }

    /** Start turn-by-turn navigation (or a map) to a destination. */
    private void handleNavigate(String destination) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("google.navigation:q=" + Uri.encode(destination)));
            i.setPackage("com.google.android.apps.maps");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (i.resolveActivity(getPackageManager()) == null) {
                // Google Maps not available — fall back to a generic geo map query.
                i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(destination)));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
            launchViaLock(i);
            String msg = "Getting directions to " + destination + ".";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "NAVIGATE", destination);
        } catch (Exception e) {
            broadcastMessage("I couldn't open maps.");
            speakThenRun("I couldn't open maps.", this::rearmAfterAction);
            LogStore.append(this, "NAVIGATE", "Failed: " + e.getMessage());
        }
    }
    /** Compose an email (resolves a contact's address when possible). */
    private void handleEmail(String recipient, String body) {
        try {
            String to = recipient;
            if (!recipient.contains("@")) {
                String resolved = resolveEmail(recipient);
                if (resolved != null) to = resolved;
            }
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
            if (to.contains("@")) i.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
            if (!body.isEmpty()) i.putExtra(Intent.EXTRA_SUBJECT, body);
            launchViaLock(i);
            String msg = to.contains("@")
                    ? "Opening an email to " + recipient + "."
                    : "Opening an email \u2014 add " + recipient + "'s address.";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "EMAIL", "To " + recipient);
        } catch (Exception e) {
            broadcastMessage("I couldn't open an email app.");
            speakThenRun("I couldn't open an email app.", this::rearmAfterAction);
            LogStore.append(this, "EMAIL", "Failed: " + e.getMessage());
        }
    }

    /** Open the calendar to create an event, pre-filling title and time. */
    private void handleCalendar(String title, String when) {
        try {
            Intent i = new Intent(Intent.ACTION_INSERT);
            i.setData(android.provider.CalendarContract.Events.CONTENT_URI);
            i.putExtra(android.provider.CalendarContract.Events.TITLE, title);
            String spokenWhen = "";
            if (when != null) {
                int[] hm = parseClockTime(when);
                if (hm != null) {
                    Calendar cal = Calendar.getInstance();
                    cal.set(Calendar.HOUR_OF_DAY, hm[0]);
                    cal.set(Calendar.MINUTE, hm[1]);
                    cal.set(Calendar.SECOND, 0);
                    cal.set(Calendar.MILLISECOND, 0);
                    if (when.toLowerCase(Locale.ROOT).contains("tomorrow")) cal.add(Calendar.DAY_OF_MONTH, 1);
                    else if (cal.getTimeInMillis() <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_MONTH, 1);
                    i.putExtra(android.provider.CalendarContract.EXTRA_EVENT_BEGIN_TIME, cal.getTimeInMillis());
                    i.putExtra(android.provider.CalendarContract.EXTRA_EVENT_END_TIME,
                            cal.getTimeInMillis() + 3600000L);
                    spokenWhen = " at " + formatClock(hm[0], hm[1]);
                }
            }
            launchViaLock(i);
            String msg = "Opening your calendar to add \u201C" + title + "\u201D" + spokenWhen + ".";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "CALENDAR", title + spokenWhen);
        } catch (Exception e) {
            broadcastMessage("I couldn't open the calendar.");
            speakThenRun("I couldn't open the calendar.", this::rearmAfterAction);
            LogStore.append(this, "CALENDAR", "Failed: " + e.getMessage());
        }
    }

    /** Resolve a spoken name to a contact's email address, or null. */
    private String resolveEmail(String name) {
        if (!hasPermission(Manifest.permission.READ_CONTACTS)) return null;
        String target = ProfileStore.normalize(name).replaceAll("^my\\s+", "");
        try (Cursor c = getContentResolver().query(
                ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Email.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Email.ADDRESS},
                null, null, null)) {
            if (c == null) return null;
            String best = null;
            double bestScore = 0;
            while (c.moveToNext()) {
                String dn = c.getString(0);
                String addr = c.getString(1);
                if (dn == null || addr == null) continue;
                double score = nameScore(target, ProfileStore.normalize(dn));
                if (score > bestScore && score >= .72) { bestScore = score; best = addr; }
            }
            return best;
        } catch (Exception e) {
            return null;
        }
    }

    /** Resolve a spoken name to the best-matching contact number, or null. */
    private String resolveNumber(String who) {
        if (who == null || who.trim().isEmpty()) return null;
        // Relationship first ("my brother")
        ProfileStore store = new ProfileStore(this);
        String[] rel = store.resolveRelationship(
                ProfileStore.normalize(who).replaceAll("^my\\s+", ""));
        if (rel != null && rel[1] != null && !rel[1].isEmpty()) return rel[1];
        List<ContactMatch> matches = resolveContacts(who);
        return matches.isEmpty() ? null : matches.get(0).number;
    }

    // ---------------- Number / time parsing helpers ----------------

    private static final java.util.Map<String, Integer> NUM_WORDS = new java.util.HashMap<>();
    static {
        String[] ones = {"zero","one","two","three","four","five","six","seven","eight","nine",
                "ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen",
                "eighteen","nineteen"};
        for (int i = 0; i < ones.length; i++) NUM_WORDS.put(ones[i], i);
        String[] tens = {"twenty","thirty","forty","fifty","sixty","seventy","eighty","ninety"};
        for (int i = 0; i < tens.length; i++) NUM_WORDS.put(tens[i], (i + 2) * 10);
    }

    // Spoken-letter → character map (letter names + NATO phonetic) for spell-mode calling.
    private static final java.util.Map<String, Character> LETTER_MAP = new java.util.HashMap<>();
    static {
        String[][] rows = {
            {"a","a","ay","eh","alpha"}, {"b","b","be","bee","bravo"}, {"c","c","see","sea","cee","charlie"},
            {"d","d","dee","delta"}, {"e","e","ee","echo"}, {"f","f","ef","eff","foxtrot"},
            {"g","g","gee","golf"}, {"h","h","aitch","haitch","hotel"}, {"i","i","eye","india"},
            {"j","j","jay","juliet","juliett"}, {"k","k","kay","kilo"}, {"l","l","el","ell","lima"},
            {"m","m","em","mike"}, {"n","n","en","november"}, {"o","o","oh","oscar"},
            {"p","p","pee","papa"}, {"q","q","cue","queue","quebec"}, {"r","r","ar","are","romeo"},
            {"s","s","es","ess","sierra"}, {"t","t","tee","tea","tango"}, {"u","u","you","yu","uniform"},
            {"v","v","vee","victor"}, {"w","w","whiskey"}, {"x","x","ex","xray"},
            {"y","y","why","yankee"}, {"z","z","zee","zed","zulu"}
        };
        for (String[] row : rows) {
            char c = row[0].charAt(0);
            for (int i = 1; i < row.length; i++) LETTER_MAP.put(row[i], c);
        }
    }

    /** Begin letter-by-letter contact spelling (for names speech keeps mis-hearing). */
    private void beginSpellCall() {
        spellingCall = true;
        spellRetry = 0;
        askSpell("Spell the name letter by letter \u2014 or use the phonetic alphabet, like Mike, Alpha, Alpha.");
    }

    private void askSpell(String prompt) {
        broadcastMessage(prompt);
        updateListeningNotification("Spell the name\u2026");
        speakThenRun(prompt, this::startCommandRecognition);
    }

    /** Turn spoken letters into a name string, then match contacts and confirm the closest. */
    private void handleSpellInput(String heard) {
        String norm = ProfileStore.normalize(heard == null ? "" : heard);
        if (norm.matches(".*\\b(cancel|stop|never mind|nevermind|forget it)\\b.*")) {
            spellingCall = false;
            broadcastMessage("Cancelled.");
            speakThenRun("Okay, cancelled.", this::rearmAfterAction);
            return;
        }
        String spelled = parseSpelledLetters(norm);
        if (spelled.length() < 1) {
            spellRetry++;
            if (spellRetry >= 3) {
                spellingCall = false;
                speakThenRun("I still couldn't get the letters. Let's try again later.", this::rearmAfterAction);
                return;
            }
            askSpell("I didn't catch the letters. Spell it slowly \u2014 for example, Mike, Alpha, Alpha.");
            return;
        }
        spellingCall = false;
        broadcastMessage("Spelled: " + spelled.toUpperCase(Locale.ROOT));
        LogStore.append(this, "SPELL", "Spelled name \u2192 " + spelled);
        List<ContactMatch> candidates = resolveContacts(spelled);
        if (candidates.isEmpty()) {
            String msg = "I couldn't find a contact spelled " + spelled.toUpperCase(Locale.ROOT) + ".";
            broadcastMessage(msg); speakThenRun(msg, this::rearmAfterAction);
            return;
        }
        // Hand off to the normal call confirmation ("Did you mean X?" cycles on "no").
        pendingCandidates = candidates;
        pendingCandidateIndex = 0;
        confirmCandidate(0);
    }

    private String parseSpelledLetters(String norm) {
        String[] toks = norm.split("\\s+");
        StringBuilder sb = new StringBuilder();
        int mapped = 0;
        for (String tok : toks) {
            if (tok.isEmpty()) continue;
            Character c = LETTER_MAP.get(tok);
            if (c != null) { sb.append(c); mapped++; }
            else if (tok.length() == 1 && tok.charAt(0) >= 'a' && tok.charAt(0) <= 'z') { sb.append(tok); mapped++; }
        }
        // If nothing looked like spelled letters but they just said a word, use it as the name.
        if (mapped == 0 && toks.length == 1 && toks[0].matches("[a-z]{2,}")) return toks[0];
        return sb.toString();
    }

    /** Convert a spoken/typed phone number ("nine eight seven…", "double five", "9876543210")
     *  into a digit string. Returns null if it doesn't look like a phone number (≥7 digits). */
    private String extractPhoneNumber(String text) {
        if (text == null) return null;
        String t = text.toLowerCase(Locale.ROOT).trim();
        String[] toks = t.split("[^a-z0-9+]+");
        StringBuilder digits = new StringBuilder();
        int repeat = 1;
        for (String tok : toks) {
            if (tok.isEmpty()) continue;
            if (tok.equals("double")) { repeat = 2; continue; }
            if (tok.equals("triple")) { repeat = 3; continue; }
            if (tok.equals("plus")) { digits.append('+'); repeat = 1; continue; }
            String d = null;
            if (tok.matches("[0-9]+")) d = tok;
            else if (tok.equals("oh") || tok.equals("o") || tok.equals("zero")) d = "0";
            else if (NUM_WORDS.containsKey(tok) && NUM_WORDS.get(tok) <= 9) d = String.valueOf(NUM_WORDS.get(tok));
            if (d != null) { for (int i = 0; i < repeat; i++) digits.append(d); }
            repeat = 1;
        }
        String justDigits = digits.toString().replaceAll("[^0-9]", "");
        return justDigits.length() >= 7 ? digits.toString() : null;
    }

    /** Format a phone number so TTS reads it digit-by-digit ("9 8 7 6…"), not as a magnitude. */
    private static String speakableNumber(String number) {
        if (number == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : number.toCharArray()) {
            if (Character.isDigit(c)) sb.append(c).append(' ');
            else if (c == '+') sb.append("plus ");
        }
        return sb.toString().trim();
    }

    /** Parse "5 minutes", "thirty seconds", "an hour", "half an hour" → seconds. 0 if unknown. */
    private int parseDurationSeconds(String text) {
        if (text == null) return 0;
        String t = text.toLowerCase(Locale.ROOT).trim();
        if (t.contains("half an hour") || t.contains("half hour")) return 1800;
        if (t.contains("quarter")) return 900;
        int unitSecs = 60; // default minutes
        if (t.contains("hour")) unitSecs = 3600;
        else if (t.contains("second")) unitSecs = 1;
        else if (t.contains("minute") || t.contains("min")) unitSecs = 60;
        int qty = extractNumber(t);
        if (qty <= 0) {
            if (t.startsWith("an ") || t.startsWith("a ")) qty = 1; else return 0;
        }
        return qty * unitSecs;
    }

    /** Parse "7", "seven", "seven thirty", "7 30", with am/pm → {hour24, minute}. Null if unknown. */
    private int[] parseClockTime(String text) {
        if (text == null) return null;
        String t = text.toLowerCase(Locale.ROOT).trim();
        boolean pm = t.contains("pm") || t.contains("p m") || t.contains("evening") || t.contains("night");
        boolean am = t.contains("am") || t.contains("a m") || t.contains("morning");
        // digit form "7:30" or "730"
        Matcher md = Pattern.compile("(\\d{1,2})(?::|\\s)?(\\d{2})?").matcher(t);
        int hour = -1, minute = 0;
        if (md.find() && md.group(1) != null && t.matches(".*\\d.*")) {
            hour = Integer.parseInt(md.group(1));
            if (md.group(2) != null) minute = Integer.parseInt(md.group(2));
        } else {
            // word form: first number word = hour, optional second = minute
            String[] tokens = t.split("\\s+");
            java.util.List<Integer> nums = new ArrayList<>();
            for (String tok : tokens) {
                Integer v = NUM_WORDS.get(tok);
                if (v != null) nums.add(v);
            }
            if (t.contains("quarter")) minute = 15;
            if (t.contains("half")) minute = 30;
            if (!nums.isEmpty()) {
                hour = nums.get(0);
                if (nums.size() > 1) minute = nums.get(1);
            }
        }
        if (hour < 0 || hour > 23) return null;
        if (minute < 0 || minute > 59) minute = 0;
        if (pm && hour < 12) hour += 12;
        if (am && hour == 12) hour = 0;
        return new int[]{hour, minute};
    }

    /** First number (digit or single number-word) in the text, else -1. */
    private int extractNumber(String t) {
        Matcher m = Pattern.compile("\\d+").matcher(t);
        if (m.find()) { try { return Integer.parseInt(m.group()); } catch (Exception e) { return -1; } }
        for (String tok : t.split("\\s+")) {
            Integer v = NUM_WORDS.get(tok);
            if (v != null) return v;
        }
        return -1;
    }

    private String formatClock(int hour24, int minute) {
        String ampm = hour24 >= 12 ? "PM" : "AM";
        int h = hour24 % 12 == 0 ? 12 : hour24 % 12;
        return h + ":" + String.format(Locale.US, "%02d", minute) + " " + ampm;
    }

    private String humanDuration(int seconds) {
        if (seconds % 3600 == 0) { int h = seconds / 3600; return h + (h == 1 ? " hour" : " hours"); }
        if (seconds % 60 == 0) { int m = seconds / 60; return m + (m == 1 ? " minute" : " minutes"); }
        return seconds + " seconds";
    }

    /** Request a single fresh location update with a timeout; callback gets null on failure. */
    private void requestFreshLocation(java.util.function.Consumer<android.location.Location> cb) {
        try {
            android.location.LocationManager lm =
                    (android.location.LocationManager) getSystemService(LOCATION_SERVICE);
            if (lm == null) { cb.accept(null); return; }
            String provider = lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER)
                    ? android.location.LocationManager.NETWORK_PROVIDER
                    : (lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)
                        ? android.location.LocationManager.GPS_PROVIDER : null);
            if (provider == null) { cb.accept(null); return; }
            final boolean[] done = {false};
            final android.location.LocationListener listener = new android.location.LocationListener() {
                @Override public void onLocationChanged(android.location.Location location) {
                    if (done[0]) return;
                    done[0] = true;
                    try { lm.removeUpdates(this); } catch (Exception ignored) { }
                    handler.post(() -> cb.accept(location));
                }
                @Override public void onProviderDisabled(String p) { }
                @Override public void onProviderEnabled(String p) { }
                @Override public void onStatusChanged(String p, int s, Bundle e) { }
            };
            lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper());
            // Timeout after 8 seconds → fall back to last-known or null
            handler.postDelayed(() -> {
                if (done[0]) return;
                done[0] = true;
                try { lm.removeUpdates(listener); } catch (Exception ignored) { }
                cb.accept(lastKnownLocation());
            }, 8000);
        } catch (Exception e) {
            cb.accept(null);
        }
    }

    private void fetchWeatherFor(android.location.Location loc, String normalized) {
        boolean forecast = normalized.matches(".*\\b(forecast|tomorrow|later|week|rain)\\b.*");
        broadcastMessage("\u26C5 Checking the weather\u2026");
        LogStore.append(this, "WEATHER", "Fetching for " + loc.getLatitude() + "," + loc.getLongitude());
        final android.location.Location floc = loc;
        // Geocode (blocking) off the main thread, then fetch.
        new Thread(() -> {
            String place = geocodePlace(floc);
            WeatherService.fetch(floc.getLatitude(), floc.getLongitude(), forecast, place,
                    new WeatherService.WeatherListener() {
                        @Override public void onResult(String spoken) {
                            broadcastMessage("\u26C5 " + spoken);
                            speakThenRun(spoken, IrisListeningService.this::rearmAfterAction);
                            LogStore.append(IrisListeningService.this, "WEATHER", "OK");
                        }
                        @Override public void onError(String message) {
                            String msg = "I couldn't reach the weather service. Check your connection.";
                            broadcastMessage(msg);
                            speakThenRun(msg, IrisListeningService.this::rearmAfterAction);
                            LogStore.append(IrisListeningService.this, "WEATHER ERROR", message);
                        }
                    });
        }, "IRIS-Geocode").start();
    }

    private android.location.Location lastKnownLocation() {
        try {
            android.location.LocationManager lm =
                    (android.location.LocationManager) getSystemService(LOCATION_SERVICE);
            if (lm == null) return null;
            android.location.Location best = null;
            String[] providers = {
                    android.location.LocationManager.NETWORK_PROVIDER,
                    android.location.LocationManager.GPS_PROVIDER,
                    android.location.LocationManager.PASSIVE_PROVIDER
            };
            for (String p : providers) {
                try {
                    android.location.Location l = lm.getLastKnownLocation(p);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                } catch (SecurityException | IllegalArgumentException ignored) { }
            }
            return best;
        } catch (Exception e) {
            return null;
        }
    }

    /** Reverse-geocode a rough place name (best effort; may return null). */
    private String geocodePlace(android.location.Location loc) {
        try {
            android.location.Geocoder g = new android.location.Geocoder(this, Locale.getDefault());
            java.util.List<android.location.Address> list =
                    g.getFromLocation(loc.getLatitude(), loc.getLongitude(), 1);
            if (list != null && !list.isEmpty()) {
                android.location.Address a = list.get(0);
                if (a.getLocality() != null) return a.getLocality();
                if (a.getSubAdminArea() != null) return a.getSubAdminArea();
                if (a.getAdminArea() != null) return a.getAdminArea();
            }
        } catch (Exception ignored) { }
        return null;
    }

    private String describeScope(String appLabel, String sender) {
        StringBuilder s = new StringBuilder();
        if (sender != null) s.append(" from ").append(sender);
        if (appLabel != null) s.append(" on ").append(appLabel);
        return s.toString();
    }

    /** Extract the sender term after "from", stopping before app words. */
    private String extractSender(String normalized) {
        Matcher m = Pattern.compile(
                "\\bfrom\\s+(?:my\\s+)?([a-z][a-z ]*?)(?:\\s+(?:in|on|via)\\b.*)?$")
                .matcher(normalized);
        if (!m.find()) return null;
        String s = m.group(1).trim();
        // Strip trailing app words if they leaked in
        s = s.replaceAll("\\b(whatsapp|sms|messages?|texts?|notification[s]?)\\b", "").trim();
        return s.isEmpty() ? null : s;
    }

    /** Resolve a relationship word ("mother", "my dad") to a saved contact name. */
    private String resolveSenderName(String rawSender) {
        String key = rawSender.toLowerCase().trim();
        // Try relationship → contact name
        try {
            String[] rel = new ProfileStore(this).resolveRelationship(ProfileStore.normalize(key));
            if (rel != null && rel[0] != null && !rel[0].isEmpty()) return rel[0];
        } catch (Exception ignored) { }
        // Try memory people category
        try {
            MemoryStore.Memory mem = MemoryStore.findByKey(this, MemoryStore.CAT_PEOPLE, key);
            if (mem != null && mem.value != null && !mem.value.isEmpty()) return mem.value;
        } catch (Exception ignored) { }
        return null; // fall back to raw word
    }

    private boolean notificationAccessGranted() {
        try {
            String flat = android.provider.Settings.Secure.getString(
                    getContentResolver(), "enabled_notification_listeners");
            return flat != null && flat.contains(getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    private void openNotificationAccessSettings() {
        try {
            Intent intent = new Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            LogStore.append(this, "NOTIF ERROR", "Can't open settings: " + e.getMessage());
        }
    }

    /**
     * Launch an installed app by spoken name. Matches against installed app
     * labels (fuzzy) and launches the best match. Returns true if launched.
     */
    private boolean openApp(String spokenName) {
        String target = ProfileStore.normalize(spokenName);
        if (target.isEmpty()) return false;
        android.content.pm.PackageManager pm = getPackageManager();
        List<android.content.pm.ApplicationInfo> apps =
                pm.getInstalledApplications(android.content.pm.PackageManager.GET_META_DATA);
        String bestPkg = null; String bestLabel = null; double bestScore = 0;
        for (android.content.pm.ApplicationInfo app : apps) {
            // Only apps that have a launcher entry
            if (pm.getLaunchIntentForPackage(app.packageName) == null) continue;
            String label = ProfileStore.normalize(pm.getApplicationLabel(app).toString());
            if (label.isEmpty()) continue;
            double score;
            if (label.equals(target)) score = 1.0;
            else if (label.contains(target) || target.contains(label)) score = 0.85;
            else score = nameScore(target, label);
            if (score > bestScore) { bestScore = score; bestPkg = app.packageName; bestLabel = pm.getApplicationLabel(app).toString(); }
        }
        if (bestPkg != null && bestScore >= 0.7) {
            Intent launch = pm.getLaunchIntentForPackage(bestPkg);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    launchViaLock(launch);
                    LogStore.append(this, "OPEN APP", bestLabel + " (" + bestPkg + ")");
                    broadcastMessage("Opening " + bestLabel + ".");
                    speakThenRun("Opening " + bestLabel + ".", this::rearmAfterAction);
                    return true;
                } catch (Exception e) {
                    LogStore.append(this, "OPEN APP ERROR", e.getMessage());
                }
            }
        }
        broadcastMessage("I couldn't find an app called " + spokenName + ".");
        speakThenRun("I couldn't find " + spokenName + ".", this::rearmAfterAction);
        return true; // handled (told the user), don't fall through to chat
    }

    private void handleRedial(ProfileStore store) {
        List<ProfileStore.Entry> recent = store.frequentContacts(1);
        if (recent.isEmpty() || recent.get(0).lastCalled == 0) {
            broadcastMessage("I don\u2019t have anyone to call back yet.");
            LogStore.append(this, "REDIAL", "No recent calls");
            rearmAfterAction();
            return;
        }
        ProfileStore.Entry last = recent.get(0);
        LogStore.append(this, "REDIAL", last.contactName);
        requestCallConfirmation(last.contactName, last.phoneNumber);
    }

    private void handleRemember(String statement) {
        MemoryParser.ParsedMemory parsed = MemoryParser.parse(statement);
        if (parsed != null) {
            MemoryStore.Memory memory = new MemoryStore.Memory();
            memory.category = parsed.category;
            memory.key = parsed.key;
            memory.value = parsed.value;
            memory.source = "voice";
            MemoryStore.add(this, memory);
            lastMemoryId = memory.id;
            String response = "Got it. " + parsed.key + " is " + parsed.value + ".";
            speak(response);
            broadcastMessage("\uD83E\uDDE0 " + response);
            LogStore.append(this, "MEMORY", "Voice: " + parsed.key + " = " + parsed.value
                    + " (" + parsed.category + ", confidence " + Math.round(parsed.confidence * 100) + "%)");
        } else {
            String response = "I\u2019ll remember that as a note.";
            MemoryStore.Memory memory = new MemoryStore.Memory();
            memory.category = MemoryStore.CAT_ABOUT_ME;
            memory.key = "note";
            memory.value = statement;
            memory.source = "voice";
            MemoryStore.add(this, memory);
            lastMemoryId = memory.id;
            speak(response);
            broadcastMessage("\uD83E\uDDE0 " + response);
            LogStore.append(this, "MEMORY", "Voice note: " + statement);
        }
        rearmAfterAction();
    }

    private void handleForget() {
        if (lastMemoryId != null) {
            MemoryStore.delete(this, lastMemoryId);
            speak("Done. I forgot it.");
            broadcastMessage("\uD83D\uDDD1 Memory removed.");
            LogStore.append(this, "MEMORY", "Deleted: " + lastMemoryId);
            lastMemoryId = null;
        } else {
            speak("There\u2019s nothing recent to forget.");
            broadcastMessage("Nothing to forget.");
        }
        rearmAfterAction();
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private void handleRecall(String topic) {
        int count = MemoryStore.count(this);
        if (count == 0) {
            speak("I don\u2019t know anything about you yet. Say \u201Cremember\u201D followed by a fact.");
            broadcastMessage("\uD83E\uDDE0 No memories yet.");
            LogStore.append(this, "RECALL", "Memories: 0");
            rearmAfterAction();
            return;
        }
        String out;
        if (topic != null && !topic.trim().isEmpty()) {
            // A targeted question ("what do you know about my car?") — answer with the
            // best-matching memories instead of dumping everything in storage order.
            java.util.List<MemoryStore.Memory> hits = MemoryStore.recall(this, topic, 3, false);
            if (hits.isEmpty()) {
                out = "I don't have anything remembered about " + topic.trim() + ".";
            } else {
                StringBuilder sb = new StringBuilder();
                for (MemoryStore.Memory m : hits) {
                    sb.append(capitalize(m.key)).append(": ").append(m.value).append(". ");
                }
                out = sb.toString().trim();
            }
        } else {
            String name = MemoryStore.ownerName(this);
            StringBuilder response = new StringBuilder("Here's what I know about you. ");
            if (name != null) response.append("Your name is ").append(name).append(". ");
            int listed = 0;
            for (MemoryStore.Memory m : MemoryStore.getAll(this)) {
                if (m.key == null || m.value == null) continue;
                if (m.key.equalsIgnoreCase("name")) continue;
                response.append(capitalize(m.key)).append(": ").append(m.value).append(". ");
                if (++listed >= 10) break;
            }
            if (listed == 0 && name == null) {
                response.append("I have ").append(count).append(count == 1 ? " memory." : " memories.");
            }
            out = response.toString().trim();
        }
        speak(out);
        broadcastMessage("\uD83E\uDDE0 " + out);
        LogStore.append(this, "RECALL", (topic == null ? "all" : topic) + " → memories: " + count);
        rearmAfterAction();
    }

    private void handleHistory(String normalized, ProfileStore store) {
        if (normalized.matches(".*\\bwho\\s+did\\s+i\\s+call\\s+last\\b.*")) {
            ProfileStore.Entry last = store.lastCalled();
            if (last != null) {
                String text = "Your last call was to " + last.contactName;
                speak(text);
                broadcastMessage(text);
            } else {
                broadcastMessage("I don\u2019t have any call history yet.");
            }
        } else if (normalized.matches(".*\\bwho\\s+did\\s+i\\s+call\\s+today\\b.*") || normalized.matches(".*\\bmy\\s+calls\\b.*") || normalized.matches(".*\\bcall\\s+history\\b.*")) {
            List<ProfileStore.Entry> today = store.calledToday();
            if (today.isEmpty()) {
                broadcastMessage("No calls yet today.");
            } else {
                List<String> names = new ArrayList<>();
                for (ProfileStore.Entry e : today) names.add(e.contactName);
                String text = "Today you called: " + String.join(", ", names);
                speak(text);
                broadcastMessage(text);
            }
        } else if (normalized.matches(".*\\bhow\\s+many\\s+times\\b.*")) {
            String who = normalized.replaceAll(".*how\\s+many\\s+times\\s+did\\s+i\\s+call\\s+", "").trim();
            List<ContactMatch> matches = resolveContacts(who);
            if (!matches.isEmpty()) {
                ContactMatch best = matches.get(0);
                ProfileStore.Entry entry = null;
                for (ProfileStore.Entry e : store.getEntries()) {
                    if (e.contactName.equalsIgnoreCase(best.name)) { entry = e; break; }
                }
                if (entry != null && entry.callCount > 0) {
                    String text = "You\u2019ve called " + entry.contactName + " " + entry.callCount + " time" + (entry.callCount != 1 ? "s" : "") + " total.";
                    speak(text);
                    broadcastMessage(text);
                } else {
                    broadcastMessage("I don\u2019t have call records for " + who + ".");
                }
            } else {
                broadcastMessage("I couldn\u2019t find a contact matching \u201C" + who + "\u201D.");
            }
        } else if (normalized.matches(".*\\bwhen\\s+did\\s+i\\b.*")) {
            String who = normalized.replaceAll(".*when\\s+did\\s+i\\s+(?:last\\s+)?call\\s+", "").trim();
            List<ContactMatch> matches = resolveContacts(who);
            if (!matches.isEmpty()) {
                ContactMatch best = matches.get(0);
                ProfileStore.Entry entry = null;
                for (ProfileStore.Entry e : store.getEntries()) {
                    if (e.contactName.equalsIgnoreCase(best.name)) { entry = e; break; }
                }
                if (entry != null && entry.lastCalled > 0) {
                    String timeAgo = relativeTime(entry.lastCalled);
                    String text = "You last called " + entry.contactName + " " + timeAgo + ".";
                    speak(text);
                    broadcastMessage(text);
                } else {
                    broadcastMessage("I don\u2019t have a record of calling " + who + ".");
                }
            } else {
                broadcastMessage("I couldn\u2019t find a contact matching \u201C" + who + "\u201D.");
            }
        } else {
            broadcastMessage("I didn\u2019t understand the history question.");
        }
        LogStore.append(this, "HISTORY", normalized);
        rearmAfterAction();
    }

    private String relativeTime(long timestamp) {
        long diff = System.currentTimeMillis() - timestamp;
        long minutes = diff / 60_000;
        if (minutes < 1) return "just now";
        if (minutes < 60) return minutes + " minute" + (minutes != 1 ? "s" : "") + " ago";
        long hours = minutes / 60;
        if (hours < 24) return hours + " hour" + (hours != 1 ? "s" : "") + " ago";
        long days = hours / 24;
        if (days == 1) return "yesterday";
        return days + " days ago";
    }

    private void handleConfirmation(String heard) {
        String answer = ProfileStore.normalize(heard);
        LogStore.append(this, "CONFIRM VOICE", answer);
        // "no" first so "no" never gets misread as yes. "call" is NOT a yes —
        // it's ambiguous with a fresh command and caused wrong-contact calls.
        if (answer.matches("^(?:no|nope|nah|nahi|cancel|wrong|not\\s+\\w+|stop|kill|abort|forget\\s*it|leave\\s*it|hang\\s*up|don'?t|end\\s*it|nvm|never\\s*mind|ruk|bas|chhod)\\b.*")) {
            if (confirmTimeout != null) { handler.removeCallbacks(confirmTimeout); confirmTimeout = null; }
            cancelCallNotification();
            // If there are more candidates, ask about the next one
            if (pendingCandidates != null && pendingCandidateIndex + 1 < pendingCandidates.size()) {
                int next = pendingCandidateIndex + 1;
                LogStore.append(this, "CONFIRM", "Declined, trying next: "
                        + pendingCandidates.get(next).name);
                handler.postDelayed(() -> confirmCandidate(next), 300);
            } else {
                pendingCandidates = null;
                broadcastMessage("Call cancelled.");
                speakThenRun("Okay, cancelled.", this::rearmAfterAction);
            }
        } else if (answer.matches("^(?:yes|yeah|yep|yup|confirm|correct|right|sure|okay|ok|do\\s+it|go\\s+ahead|haan|ha)\\b.*")
                // "call" on its own (or with a pronoun) means "yes, place it". A name after
                // "call" is deliberately NOT treated as confirmation, because that used to
                // place a call to the wrong contact.
                || answer.matches("^(?:call|dial|ring)(?:\\s+(?:him|her|them|it|now|please|karo))?$")) {
            if (confirmTimeout != null) { handler.removeCallbacks(confirmTimeout); confirmTimeout = null; }
            pendingCandidates = null;
            placeCall(pendingName, pendingNumber);
        } else if (confirmationRetries++ < 1) {
            broadcastMessage("Say “yes” to call or “no” to cancel.");
            speakThenRun("Say yes to call, or no to cancel.", this::startConfirmationRecognition);
        } else {
            cancelCallNotification();
            broadcastMessage("I couldn't understand. Call cancelled.");
            LogStore.append(IrisListeningService.this, "CANCELLED", "Unrecognized confirmation for " + (pendingName == null ? "contact" : pendingName));
            rearmAfterAction();
        }
    }

    private List<ContactMatch> resolveContacts(String requested) {
        String target = ProfileStore.normalize(requested);
        if (target.matches("[0-9 ]{3,}")) {
            return Collections.singletonList(new ContactMatch(requested, requested.replace(" ", ""), 1.0));
        }
        List<ContactMatch> matches = new ArrayList<>();
        if (!hasPermission(Manifest.permission.READ_CONTACTS)) return matches;
        String[] projection = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER};
        try (Cursor cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection, null, null, null)) {
            if (cursor == null) return matches;
            while (cursor.moveToNext()) {
                String name = cursor.getString(0);
                String number = cursor.getString(1);
                double score = nameScore(target, ProfileStore.normalize(name));
                if (score >= .72) matches.add(new ContactMatch(name, number, score));
            }
        } catch (Exception error) {
            LogStore.append(this, "ERROR", "Contact lookup failed: " + error.getMessage());
        }
        matches.sort((a, b) -> Double.compare(b.score, a.score));
        return matches;
    }

    private double nameScore(String target, String candidate) {
        if (target.equals(candidate)) return 1;
        if (candidate.startsWith(target) || target.startsWith(candidate)) return .90;
        if (candidate.contains(target) || target.contains(candidate)) return .82;
        for (String a : target.split(" ")) for (String b : candidate.split(" "))
            if (a.length() > 2 && a.equals(b)) return .76;
        if (soundex(target).equals(soundex(candidate)) && !soundex(target).isEmpty()) return .74;
        return textSimilarity(target, candidate);
    }

    private String soundex(String value) {
        String latin = value.replaceAll("[^a-z]", "");
        if (latin.isEmpty()) return "";
        String map = "01230120022455012623010202";
        StringBuilder result = new StringBuilder().append(latin.charAt(0));
        char previous = map.charAt(latin.charAt(0) - 'a');
        for (int i = 1; i < latin.length() && result.length() < 4; i++) {
            char code = map.charAt(latin.charAt(i) - 'a');
            if (code != '0' && code != previous) result.append(code);
            previous = code;
        }
        while (result.length() < 4) result.append('0');
        return result.toString();
    }

    private double textSimilarity(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) previous[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] swap = previous; previous = current; current = swap;
        }
        return 1.0 - ((double) previous[b.length()] / Math.max(a.length(), b.length()));
    }

    private void requestDisambiguation(List<ContactMatch> candidates) {
        destroyRecognizer();
        ArrayList<String> names = new ArrayList<>();
        ArrayList<String> numbers = new ArrayList<>();
        for (ContactMatch candidate : candidates) {
            names.add(candidate.name);
            numbers.add(candidate.number);
        }
        sendBroadcast(new Intent(EVENT_DISAMBIGUATE).setPackage(getPackageName())
                .putStringArrayListExtra(EXTRA_NAMES, names)
                .putStringArrayListExtra(EXTRA_NUMBERS, numbers));
        Intent open = new Intent(this, MainActivity.class)
                .putStringArrayListExtra(EXTRA_NAMES, names)
                .putStringArrayListExtra(EXTRA_NUMBERS, numbers);
        PendingIntent content = PendingIntent.getActivity(this, 14, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(this, CALL_CHANNEL)
                .setSmallIcon(R.drawable.ic_iris)
                .setContentTitle("Which contact did you mean?")
                .setContentText(String.join(" • ", names))
                .setContentIntent(content)
                .setAutoCancel(true)
                .build();
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(CALL_NOTIFICATION, notification);
        handler.postDelayed(() -> {
            if (isRunning && pendingName == null && PHASE_COMMAND.equals(phase)) {
                broadcastMessage("No selection made. Going back to sleep.");
                LogStore.append(this, "TIMEOUT", "Disambiguation expired");
                cancelCallNotification();
                rearmAfterAction();
            }
        }, 30_000);
    }

    private void requestCorrection(String heard) {
        sendBroadcast(new Intent(EVENT_TEACH).setPackage(getPackageName())
                .putExtra(EXTRA_TEXT, heard));
        Intent open = new Intent(this, MainActivity.class)
                .putExtra(EXTRA_TEACH, true).putExtra(EXTRA_TEXT, heard);
        Notification notification = new Notification.Builder(this, CALL_CHANNEL)
                .setSmallIcon(R.drawable.ic_iris)
                .setContentTitle("Teach IRIS what you meant?")
                .setContentText("“" + heard + "”")
                .setContentIntent(PendingIntent.getActivity(this, 34, open,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT))
                .setAutoCancel(true).build();
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(TEACH_NOTIFICATION, notification);
    }

    private void requestCallConfirmation(String name, String number) {
        requestCallConfirmation(name, number, null);
    }

    private void requestCallConfirmation(String name, String number, String customPrompt) {
        if (name == null || number == null) {
            rearmAfterAction();
            return;
        }
        // Smart call timing checks
        String warning = callTimingWarning(name, number);
        if (warning != null) {
            broadcastMessage(warning);
            speak(warning);
        }
        pendingName = name;
        pendingNumber = number;
        confirmationRetries = 0;
        destroyRecognizer();
        LogStore.append(this, "CONFIRM", "Waiting to call " + name);
        broadcastCallPrompt(name, number);
        showCallNotification(name, number);
        String confirmText = customPrompt != null ? customPrompt : personalityLine("confirm", name);
        if (settings.voiceReplies() && ttsReady && confirmText != null) {
            textToSpeech.speak(confirmText, TextToSpeech.QUEUE_FLUSH, null, "iris_confirm");
            textToSpeech.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) {
                    if ("iris_confirm".equals(utteranceId)) {
                        textToSpeech.setOnUtteranceProgressListener(null);
                        handler.post(() -> startConfirmationRecognition());
                    }
                }
                @Override public void onError(String utteranceId) {
                    textToSpeech.setOnUtteranceProgressListener(null);
                    handler.post(() -> startConfirmationRecognition());
                }
            });
        } else {
            startConfirmationRecognition();
        }
    }

    private void placeCall(String name, String number) {
        if (number == null || number.trim().isEmpty()) {
            broadcastMessage("That contact has no callable number.");
            rearmAfterAction();
            return;
        }
        KeyguardManager keyguard = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (settings.requireUnlock() && keyguard != null && keyguard.isDeviceLocked()) {
            cancelCallNotification();
            requestUnlockForCall(name, number);
            return;
        }
        pendingName = name;
        pendingNumber = number;
        speak(personalityLine("calling", name));
        broadcastMessage("Calling " + name + "…");
        handler.postDelayed(() -> performCall(name, number), settings.voiceReplies() ? 500 : 80);
    }

    private void performCall(String name, String number) {
        String digits = number.replaceAll("[^0-9+]", "");
        boolean sensitive = digits.replace("+", "").length() <= 3 || digits.startsWith("1900");
        boolean direct = hasPermission(Manifest.permission.CALL_PHONE) && !sensitive;
        Intent call = new Intent(direct ? Intent.ACTION_CALL : Intent.ACTION_DIAL,
                Uri.parse("tel:" + Uri.encode(digits))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            new ProfileStore(this).recordCall(name, number);
            BehaviorAnalyzer.onCallPlaced(this, name, number);
            try { ledger().record("call", ActionLedger.OK,
                    "Called " + (name == null ? number : name), "", "", false); } catch (Throwable ignored) { }
            LogStore.append(this, direct ? "CALLING" : "DIALER", name == null ? number : name);

            // Launch FIRST, while we are still a foreground service. Tearing down foreground
            // state before startActivity loses the background-activity-start exemption on
            // Android 10+, which silently swallowed the call.
            boolean launched = false;
            try { startActivity(call); launched = true; }
            catch (Throwable t) { LogStore.append(this, "CALL", "direct start blocked: " + t); }

            if (!launched) {
                // Reliable fallback: a full-screen intent can bring the dialer up from the
                // background and over the lock screen.
                try {
                    PendingIntent pi = PendingIntent.getActivity(this, 51, call,
                            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                    Notification n = new Notification.Builder(this, CALL_CHANNEL)
                            .setSmallIcon(R.drawable.ic_iris)
                            .setContentTitle("Calling " + (name == null ? number : name))
                            .setContentText("Tap if the call doesn't start")
                            .setCategory(Notification.CATEGORY_CALL)
                            .setFullScreenIntent(pi, true)
                            .setAutoCancel(true).build();
                    ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(0xCA11, n);
                    launched = true;
                } catch (Throwable t) {
                    LogStore.append(this, "CALL", "full-screen fallback failed: " + t);
                }
            }
            if (!launched) {
                broadcastMessage("This device blocked the call. Tap the notification to dial.");
                speakThenRun("I couldn't start the call.", this::rearmAfterAction);
                return;
            }
            // Now it is safe to stand down.
            isRunning = false;
            broadcastState(false, "off");
            destroyRecognizer();
            stopWakeEngine();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        } catch (Exception error) {
            LogStore.append(this, "ERROR", "Call failed: " + error.getMessage());
            broadcastMessage("This device could not place the call.");
            stopIris("Call launch failed");
        }
    }

    private void requestUnlockForCall(String name, String number) {
        Intent open = new Intent(this, MainActivity.class)
                .putExtra(EXTRA_NAME, name).putExtra(EXTRA_NUMBER, number)
                .putExtra(EXTRA_AUTH_REQUIRED, true);
        PendingIntent content = PendingIntent.getActivity(this, 24, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(this, CALL_CHANNEL)
                .setSmallIcon(R.drawable.ic_iris)
                .setContentTitle("Unlock to call " + name)
                .setContentText("IRIS protects calls while your phone is locked.")
                .setContentIntent(content).setAutoCancel(true).build();
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(CALL_NOTIFICATION, notification);
        LogStore.append(this, "LOCKED", "Authentication required for " + name);
    }

    /** True (and tells the user) if an action must wait for unlock while the phone is locked. */
    private boolean blockedWhileLocked(String actionLabel) {
        // Sending messages always respects the unlock preference, even with lock-screen camera enabled.
        KeyguardManager kg = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (settings.requireUnlock() && kg != null && kg.isDeviceLocked()) {
            String msg = "Please unlock your phone first to " + actionLabel + ".";
            broadcastMessage(msg);
            speakThenRun(msg, this::rearmAfterAction);
            LogStore.append(this, "LOCKED", "Blocked \"" + actionLabel + "\" while locked");
            return true;
        }
        return false;
    }

    /** Missing or invalid identity data always rejects a wake. */
    private boolean isOwnerVoice(float[] embedding) {
        try {
            return voskEngine != null && voskEngine.isSpeakerReady()
                    && WakePolicy.owner(embedding, new ProfileStore(this).getVoiceprint(), voiceThreshold());
        } catch (Throwable error) { return false; }
    }

    private double voiceThreshold() { return WakePolicy.threshold(settings.voiceSensitivity()); }

    private static double cosine(float[] a, float[] b) {
        double dot = 0, na = 0, nb = 0;
        for (int i = 0; i < a.length; i++) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]; }
        if (na == 0 || nb == 0) return 0;
        return dot / (Math.sqrt(na) * Math.sqrt(nb));
    }

    private final java.util.Random cueRandom = new java.util.Random();
    private String lastCue = "";

    /** A varied, tone-aware "voice not recognized" line. */
    private String notRecognizedLine() {
        String tone = settings.personality();
        String owner = PersonalProfile.preferredName(this);
        if (owner == null) owner = "the owner";
        String[] pool;
        if ("Professional".equals(tone)) {
            pool = new String[]{"Voice not recognised.", "Authentication failed.", "Unrecognised voice."};
        } else if ("Warm".equals(tone)) {
            pool = new String[]{"Hmm, that didn't sound like you.", "Sorry, I didn't quite recognise your voice."};
        } else { // Sarcastic / default
            pool = new String[]{"Nice try, but you're not " + owner + ".",
                    "That voice doesn't ring a bell.", "I only answer to " + owner + "."};
        }
        String pick = pool[0];
        int guard = 0;
        do { pick = pool[cueRandom.nextInt(pool.length)]; }
        while (pick.equals(lastCue) && ++guard < 5 && pool.length > 1);
        lastCue = pick;
        return pick;
    }

    /** Launch another app's screen. While locked with lock-screen control on, route
     *  through UnlockActivity so the user authenticates once, then it opens. */
    private void launchViaLock(Intent target) {
        try {
            KeyguardManager kg = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            boolean locked = kg != null && kg.isDeviceLocked();
            if (locked && settings.lockScreenControl()) {
                Intent u = new Intent(this, UnlockActivity.class);
                u.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                u.putExtra(UnlockActivity.EXTRA_TARGET, target);
                startActivity(u);
            } else {
                target.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(target);
            }
        } catch (Exception e) {
            try { startActivity(target); } catch (Exception ignored) { }
        }
    }

    private void rearmAfterAction() {
        if (commandTimeout != null) { handler.removeCallbacks(commandTimeout); commandTimeout = null; }
        if (confirmTimeout != null) { handler.removeCallbacks(confirmTimeout); confirmTimeout = null; }
        smsCompose = null;
        spellingCall = false;
        pendingPlan = null;          // an unanswered clarification expires with the session
        pendingName = null;
        pendingNumber = null;
        destroyRecognizer();
        cancelCallNotification();
        if (!isRunning) return;
        if (AppSettings.MODE_TAP.equals(settings.listeningMode())) stopIris("Tap session completed");
        else if (AppSettings.MODE_WAKE.equals(settings.listeningMode())) handler.postDelayed(this::startWakeDetection, 500);
        else handler.postDelayed(this::startCommandRecognition, 650);
    }

    private String configureAudioRoute() {
        AudioManager manager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (manager == null) return "Phone microphone";
        if (audioManager == null) previousAudioMode = manager.getMode();
        audioManager = manager;
        try {
            String preference = settings.preferredMicrophone();
            if (Build.VERSION.SDK_INT >= 31) {
                AudioDeviceInfo chosen = chooseDevice(audioManager.getAvailableCommunicationDevices(), preference);
                if (chosen != null && isBluetoothMic(chosen)) {
                    // Bluetooth headset mic requires communication mode + routing.
                    audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                    if (audioManager.setCommunicationDevice(chosen)) return readableDeviceName(chosen);
                }
                // Phone / wired mic: stay in NORMAL mode so media (music) keeps its tone.
                audioManager.setMode(AudioManager.MODE_NORMAL);
                if (chosen != null && !isBluetoothMic(chosen)) return readableDeviceName(chosen);
            } else {
                AudioDeviceInfo chosen = chooseDevice(arrayToList(audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)), preference);
                if (chosen != null && chosen.getType() == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) {
                    audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                    audioManager.startBluetoothSco();
                    audioManager.setBluetoothScoOn(true);
                    return readableDeviceName(chosen);
                }
                audioManager.setMode(AudioManager.MODE_NORMAL);
                if (chosen != null) return readableDeviceName(chosen);
            }
        } catch (Exception ignored) { return "Active system microphone"; }
        return "Phone microphone";
    }

    /** True if the mic is a Bluetooth headset (SCO/BLE) that needs communication mode. */
    private boolean isBluetoothMic(AudioDeviceInfo device) {
        if (device == null) return false;
        int t = device.getType();
        return t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
                || (Build.VERSION.SDK_INT >= 31 && t == AudioDeviceInfo.TYPE_BLE_HEADSET);
    }

    private AudioDeviceInfo chooseDevice(List<AudioDeviceInfo> devices, String preference) {
        // Automatic: allow the Bluetooth mic unless music is actually playing, because grabbing
        // the BT mic switches A2DP to call-quality SCO and changes the music tone.
        boolean musicPlaying = false;
        try { musicPlaying = audioManager != null && audioManager.isMusicActive(); } catch (Throwable ignored) { }
        return chooseDevice(devices, preference, !musicPlaying);
    }

    private AudioDeviceInfo chooseDevice(List<AudioDeviceInfo> devices, String preference,
                                         boolean allowBluetoothInAuto) {
        AudioDeviceInfo builtIn = null, btDev = null, wiredDev = null;
        for (AudioDeviceInfo device : devices) {
            int type = device.getType();
            if (type == AudioDeviceInfo.TYPE_BUILTIN_MIC || type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE) builtIn = device;
            boolean bluetooth = type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
                    || (Build.VERSION.SDK_INT >= 31 && type == AudioDeviceInfo.TYPE_BLE_HEADSET);
            boolean wired = type == AudioDeviceInfo.TYPE_WIRED_HEADSET || type == AudioDeviceInfo.TYPE_USB_HEADSET;
            if (bluetooth) btDev = device;
            if (wired) wiredDev = device;
        }
        if ("Phone".equals(preference)) return builtIn;
        if ("Bluetooth".equals(preference)) return btDev != null ? btDev : builtIn;
        if ("Wired / USB".equals(preference)) return wiredDev != null ? wiredDev : builtIn;
        // Automatic: wired first (never disturbs playback), then the Bluetooth headset you're
        // actually wearing — but only when music isn't playing, so the tone never changes.
        if (wiredDev != null) return wiredDev;
        if (btDev != null && allowBluetoothInAuto) return btDev;
        return builtIn;
    }

    private List<AudioDeviceInfo> arrayToList(AudioDeviceInfo[] devices) {
        List<AudioDeviceInfo> result = new ArrayList<>();
        Collections.addAll(result, devices);
        return result;
    }

    private String readableDeviceName(AudioDeviceInfo device) {
        int type = device.getType();
        if (type == AudioDeviceInfo.TYPE_BUILTIN_MIC || type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE)
            return "Phone microphone";
        String product = device.getProductName() == null ? "" : device.getProductName().toString().trim();
        switch (type) {
            case AudioDeviceInfo.TYPE_BLUETOOTH_SCO:
                return (product.isEmpty() ? "Bluetooth headset" : product) + " (Bluetooth)";
            case AudioDeviceInfo.TYPE_WIRED_HEADSET:
                return (product.isEmpty() ? "Wired headset" : product) + " (wired)";
            case AudioDeviceInfo.TYPE_USB_HEADSET:
                return (product.isEmpty() ? "USB headset" : product) + " (USB)";
            default:
                if (Build.VERSION.SDK_INT >= 31 && type == AudioDeviceInfo.TYPE_BLE_HEADSET)
                    return (product.isEmpty() ? "Bluetooth headset" : product) + " (Bluetooth)";
                return product.isEmpty() ? "Phone microphone" : product + " microphone";
        }
    }

    private void registerAudioChanges() {
        if (audioManager == null || audioDeviceCallback != null) return;
        audioDeviceCallback = new AudioDeviceCallback() {
            @Override public void onAudioDevicesAdded(AudioDeviceInfo[] addedDevices) { refreshAudioRoute(); }
            @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] removedDevices) { refreshAudioRoute(); }
        };
        audioManager.registerAudioDeviceCallback(audioDeviceCallback, handler);
    }

    private void refreshAudioRoute() {
        if (!isRunning) return;
        handler.postDelayed(() -> {
            microphoneLabel = configureAudioRoute();
            broadcastState(true, phase);
            updateListeningNotification("Active through " + microphoneLabel);
        }, 300);
    }

    private void releaseAudioRoute() {
        if (audioManager == null) return;
        try {
            if (audioDeviceCallback != null) audioManager.unregisterAudioDeviceCallback(audioDeviceCallback);
            if (Build.VERSION.SDK_INT >= 31) audioManager.clearCommunicationDevice();
            else { audioManager.setBluetoothScoOn(false); audioManager.stopBluetoothSco(); }
            audioManager.setMode(previousAudioMode);
        } catch (Exception ignored) { }
        audioDeviceCallback = null;
        audioManager = null;
    }

    private Notification listeningNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, IrisListeningService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent talk = new Intent(this, IrisListeningService.class).setAction(ACTION_TALK);
        PendingIntent talkPending = PendingIntent.getService(this, 8, talk,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent shush = new Intent(this, IrisListeningService.class).setAction(ACTION_STOP_SPEAKING);
        PendingIntent shushPending = PendingIntent.getService(this, 12, shush,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, LISTENING_CHANNEL)
                .setSmallIcon(R.drawable.ic_iris).setContentTitle("IRIS is active")
                .setContentText(microphoneLabel).setOngoing(true).setOnlyAlertOnce(true)
                .setContentIntent(content)
                .addAction(new Notification.Action.Builder(null, "\uD83C\uDF99 Talk", talkPending).build())
                .addAction(new Notification.Action.Builder(null, "\u23F9 Stop", shushPending).build())
                .addAction(new Notification.Action.Builder(null, "Turn off", stopPending).build())
                .build();
    }

    private void updateListeningNotification(String text) {
        Notification notification = new Notification.Builder(this, LISTENING_CHANNEL)
                .setSmallIcon(R.drawable.ic_iris).setContentTitle("IRIS is active")
                .setContentText(text + " • " + microphoneLabel).setOngoing(true).setOnlyAlertOnce(true)
                .setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)).build();
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(LISTENING_NOTIFICATION, notification);
    }

    private void showCallNotification(String name, String number) {
        Intent confirm = new Intent(this, IrisListeningService.class).setAction(ACTION_CONFIRM_CALL)
                .putExtra(EXTRA_NAME, name).putExtra(EXTRA_NUMBER, number);
        Intent cancel = new Intent(this, IrisListeningService.class).setAction(ACTION_CANCEL_CALL)
                .putExtra(EXTRA_NAME, name);
        PendingIntent yes = PendingIntent.getService(this, 2, confirm,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent no = PendingIntent.getService(this, 3, cancel,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(this, CALL_CHANNEL)
                .setSmallIcon(R.drawable.ic_iris).setContentTitle("Call " + name + "?")
                .setContentText(number + " • Say Call or Cancel")
                .setContentIntent(PendingIntent.getActivity(this, 4,
                        new Intent(this, MainActivity.class).putExtra(EXTRA_NAME, name).putExtra(EXTRA_NUMBER, number),
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT))
                .addAction(new Notification.Action.Builder(null, "Cancel", no).build())
                .addAction(new Notification.Action.Builder(null, "Call", yes).build())
                .setVisibility(Notification.VISIBILITY_PRIVATE).build();
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(CALL_NOTIFICATION, notification);
    }

    private void cancelCallNotification() {
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(CALL_NOTIFICATION);
    }

    private void showVoiceChallengeNotification() {
        Intent open = new Intent(this, MainActivity.class)
                .putExtra("voice_challenge", true);
        PendingIntent content = PendingIntent.getActivity(this, 44, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(this, CALL_CHANNEL)
                .setSmallIcon(R.drawable.ic_iris)
                .setContentTitle("\uD83D\uDD12 Voice verification required")
                .setContentText("Someone triggered your wake phrase. Tap to verify.")
                .setContentIntent(content)
                .setAutoCancel(true)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .build();
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(CALL_NOTIFICATION, notification);
    }

    private void createNotificationChannels() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.createNotificationChannel(new NotificationChannel(LISTENING_CHANNEL,
                "IRIS listening", NotificationManager.IMPORTANCE_LOW));
        manager.createNotificationChannel(new NotificationChannel(CALL_CHANNEL,
                "IRIS call decisions", NotificationManager.IMPORTANCE_HIGH));
    }

    private void stopIris(String reason) {
        clearCameraLaunch();
        isRunning = false;
        currentPhase = "off";
        handler.removeCallbacksAndMessages(null);
        androidWakeActive = false;
        restoreRecognizerBeep();
        destroyRecognizer();
        stopWakeEngine();
        cancelCallNotification();
        LogStore.append(this, "STOP", reason);
        broadcastState(false, "off");
        if (wakeLock != null && wakeLock.isHeld()) { wakeLock.release(); wakeLock = null; }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void stopWakeEngine() {
        if (wakeEngine != null) { wakeEngine.stop(); wakeEngine = null; }
        if (voskEngine != null) voskEngine.stop();
    }

    private void destroyRecognizer() {
        recognizerGeneration++;
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) { }
            recognizer.destroy();
            recognizer = null;
        }
    }

    private static int qualityScore(android.speech.tts.Voice v) {
        int q = v.getQuality();
        if (q >= android.speech.tts.Voice.QUALITY_VERY_HIGH) return 5;
        if (q >= android.speech.tts.Voice.QUALITY_HIGH) return 3;
        if (q >= android.speech.tts.Voice.QUALITY_NORMAL) return 1;
        return 0;
    }

    /** Heuristic: does this TTS voice sound female? Android doesn't expose gender, so we
     *  check the voice name/features for common markers used by TTS engines. */
    private static boolean isFemaleVoice(android.speech.tts.Voice v) {
        if (v == null) return false;
        String n = v.getName() == null ? "" : v.getName().toLowerCase(Locale.ROOT);
        if (n.contains("female") || n.contains("-f-") || n.endsWith("-f")
                || n.contains("#female") || n.contains("_f_")) return true;
        try {
            java.util.Set<String> feats = v.getFeatures();
            if (feats != null) for (String f : feats) {
                if (f != null && f.toLowerCase(Locale.ROOT).contains("female")) return true;
            }
        } catch (Exception ignored) { }
        return false;
    }

    /** Pick the most natural available voice (Indian English preferred) and tune pacing. */
    private void configureVoice() {
        if (textToSpeech == null) return;
        try {
            // Prefer Indian English, fall back to device locale
            Locale indian = new Locale("en", "IN");
            int langResult = textToSpeech.setLanguage(indian);
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech.setLanguage(Locale.getDefault());
            }
            // Choose the highest-quality voice for the chosen locale, preferring non-robotic
            try {
                String savedName = settings.ttsVoiceName();
                android.speech.tts.Voice best = null;
                int bestScore = Integer.MIN_VALUE;
                for (android.speech.tts.Voice v : textToSpeech.getVoices()) {
                    if (v == null || v.getLocale() == null) continue;
                    // Honor the user's explicit pick if it's still available.
                    if (!savedName.isEmpty() && savedName.equals(v.getName())) { best = v; bestScore = Integer.MAX_VALUE; break; }
                    String lang = v.getLocale().getLanguage();
                    if (!"en".equals(lang)) continue;
                    boolean indianV = "IN".equals(v.getLocale().getCountry());
                    // Strongly prefer a female voice (IRIS is female), then Indian, then quality, then offline.
                    int score = (isFemaleVoice(v) ? 100 : 0)
                            + (indianV ? 20 : 0)
                            + qualityScore(v)
                            + (v.isNetworkConnectionRequired() ? 0 : 3);
                    if (best == null || score > bestScore) { best = v; bestScore = score; }
                }
                if (best != null) {
                    textToSpeech.setVoice(best);
                    LogStore.append(this, "TTS", "Voice: " + best.getName() + " (" + best.getLocale()
                            + (bestScore == Integer.MAX_VALUE ? ", user-picked" : ", female=" + isFemaleVoice(best)) + ")");
                }
            } catch (Exception ignored) { }
            // Warmer, less-robotic delivery; slightly higher pitch reads as more feminine.
            textToSpeech.setSpeechRate(0.98f);
            textToSpeech.setPitch(1.12f);
        } catch (Exception e) {
            LogStore.append(this, "TTS", "configureVoice error: " + e.getMessage());
        }
    }

    private Object speechFocusRequest;
    private volatile boolean speechCancelled;
    private volatile boolean pausedMediaForSpeech;
    private String lastUserCommand = "";
    private String lastActionSummary = "";
    private volatile boolean nextOutputMinor;
    private PersonalVocabulary personalVocabulary;
    private RecognitionStats recognitionStats;
    private ActionLedger actionLedger;
    private long commandWindowOpenedAt;
    private String lastHeardTranscript = "";
    /** Phase 2: a understood-but-incomplete plan waiting for one missing detail. */
    private Plan pendingPlan;

    /**
     * Stop background music/video before IRIS speaks — a REAL pause, not audio-focus ducking.
     * Ducking (AUDIOFOCUS_GAIN_TRANSIENT) only asks other apps to lower volume; many apps mix
     * instead, which is the "weird sounding" tone reported. Sending an actual PAUSE key stops
     * the source outright, then PLAY resumes it afterwards.
     */
    private void requestSpeechFocus() {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (am == null) return;
            pausedMediaForSpeech = am.isMusicActive();
            if (pausedMediaForSpeech) {
                am.dispatchMediaKeyEvent(new android.view.KeyEvent(
                        android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_MEDIA_PAUSE));
                am.dispatchMediaKeyEvent(new android.view.KeyEvent(
                        android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_MEDIA_PAUSE));
            }
            // Still take brief focus so the system doesn't let anything else start while we talk.
            if (Build.VERSION.SDK_INT >= 26) {
                android.media.AudioFocusRequest req = new android.media.AudioFocusRequest.Builder(
                        AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                        .setAudioAttributes(new android.media.AudioAttributes.Builder()
                                .setUsage(android.media.AudioAttributes.USAGE_ASSISTANT)
                                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        .build();
                if (am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                    speechFocusRequest = req;
                }
            } else {
                am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
            }
        } catch (Exception ignored) { }
    }

    /** Release focus and resume whatever we actually paused. */
    private void abandonSpeechFocus() {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (am == null) return;
            if (Build.VERSION.SDK_INT >= 26 && speechFocusRequest instanceof android.media.AudioFocusRequest) {
                am.abandonAudioFocusRequest((android.media.AudioFocusRequest) speechFocusRequest);
                speechFocusRequest = null;
            } else {
                am.abandonAudioFocus(null);
            }
            if (pausedMediaForSpeech) {
                pausedMediaForSpeech = false;
                am.dispatchMediaKeyEvent(new android.view.KeyEvent(
                        android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_MEDIA_PLAY));
                am.dispatchMediaKeyEvent(new android.view.KeyEvent(
                        android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_MEDIA_PLAY));
            }
        } catch (Exception ignored) { }
    }

    /** Immediately stop whatever IRIS is saying (TTS or server audio) and return to listening. */
    private void stopSpeaking() {
        speechCancelled = true;
        try { if (textToSpeech != null) textToSpeech.stop(); } catch (Exception ignored) { }
        try { releaseServerTts(); } catch (Exception ignored) { }
        abandonSpeechFocus();
        LogStore.append(this, "STOP", "Speech interrupted by user");
        if (isRunning) rearmAfterAction();
    }

    private void speak(String text) {
        if (text == null || text.isEmpty()) return;
        if (!settings.voiceReplies()) return;
        if (useServerTts()) { speakServerThenRun(text, null); return; }
        speakThenRunLocal(text, () -> { });   // reuse the audio-focus-managed path
    }

    /** True when the server voice (Piper) should be used for this reply. */
    private boolean useServerTts() {
        return settings.serverTts() && serverMonitor.shouldUseServer(settings);
    }

    private void releaseServerTts() {
        if (serverTtsPlayer != null) {
            try { serverTtsPlayer.stop(); } catch (Exception ignored) { }
            try { serverTtsPlayer.release(); } catch (Exception ignored) { }
            serverTtsPlayer = null;
        }
    }

    /** Fetch the server's Piper audio and play it; fall back to Android TTS on any failure. */
    private void speakServerThenRun(String text, Runnable afterSpeaking) {
        new Thread(() -> {
            byte[] wav = new ServerClient(settings.serverUrl(), settings.serverToken()).tts(text, 2500, 12000);
            handler.post(() -> {
                if (wav == null || wav.length < 64) {
                    speakThenRunLocal(text, afterSpeaking);
                    return;
                }
                try {
                    java.io.File f = new java.io.File(getCacheDir(), "iris_tts.wav");
                    try (java.io.FileOutputStream o = new java.io.FileOutputStream(f)) { o.write(wav); }
                    releaseServerTts();
                    serverTtsPlayer = new android.media.MediaPlayer();
                    serverTtsPlayer.setAudioAttributes(new android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build());
                    serverTtsPlayer.setDataSource(f.getAbsolutePath());
                    serverTtsPlayer.setOnCompletionListener(mp -> {
                        releaseServerTts();
                        abandonSpeechFocus();
                        if (afterSpeaking != null) afterSpeaking.run();
                    });
                    serverTtsPlayer.setOnErrorListener((mp, what, extra) -> {
                        releaseServerTts();
                        abandonSpeechFocus();
                        if (afterSpeaking != null) afterSpeaking.run();
                        return true;
                    });
                    serverTtsPlayer.prepare();
                    requestSpeechFocus();
                    serverTtsPlayer.start();
                } catch (Throwable t) {
                    releaseServerTts();
                    speakThenRunLocal(text, afterSpeaking);
                }
            });
        }, "IRIS-ServerTTS").start();
    }

    private void speakAndroidTts(String text) {
        if (textToSpeech == null) {
            textToSpeech = new TextToSpeech(this, status -> {
                ttsReady = status == TextToSpeech.SUCCESS;
                if (ttsReady) {
                    textToSpeech.setLanguage(Locale.getDefault());
                    textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "iris_reply");
                } else {
                    LogStore.append(this, "TTS", "Android TTS init failed with status " + status);
                }
            });
            return;
        }
        if (!ttsReady) {
            // TTS exists but not ready — reinitialize
            try { textToSpeech.shutdown(); } catch (Exception ignored) { }
            textToSpeech = new TextToSpeech(this, status -> {
                ttsReady = status == TextToSpeech.SUCCESS;
                if (ttsReady) {
                    textToSpeech.setLanguage(Locale.getDefault());
                    textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "iris_reply");
                }
            });
            return;
        }
        try {
            int result = textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "iris_reply");
            if (result != TextToSpeech.SUCCESS) {
                LogStore.append(this, "TTS", "speak() returned error " + result);
            }
        } catch (Exception e) {
            LogStore.append(this, "TTS ERROR", e.getMessage());
        }
    }

    /**
     * Speak text and run the callback ONLY after speech finishes.
     * Prevents the mic from cutting off IRIS mid-sentence.
     * If voice replies are off or TTS fails, runs the callback after a short delay.
     */
    private void speakThenRun(String text, Runnable afterSpeaking) {
        boolean minor = nextOutputMinor; nextOutputMinor = false;
        mirrorToWatch(text, minor);
        if (useServerTts() && text != null && !text.isEmpty() && settings.voiceReplies()) {
            speakServerThenRun(text, afterSpeaking);
            return;
        }
        speakThenRunLocal(text, afterSpeaking);
    }

    /** Post IRIS's reply as a notification so it's visible on the phone and a paired watch. */
    private void mirrorToWatch(String text, boolean minor) {
        try {
            if (text == null || text.trim().isEmpty()) return;
            if (!settings.mirrorReplies()) return;
            if (settings.mirrorMajorOnly() && minor) return;      // skip greetings/cues
            if (!settings.mirrorAlways()) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && pm.isInteractive()) return;     // screen on → app is visible
            }
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel("iris_output") == null) {
                nm.createNotificationChannel(new NotificationChannel("iris_output", "IRIS replies",
                        NotificationManager.IMPORTANCE_DEFAULT));
            }
            Notification.Builder b = (Build.VERSION.SDK_INT >= 26)
                    ? new Notification.Builder(this, "iris_output") : new Notification.Builder(this);
            Notification n = b.setSmallIcon(R.drawable.ic_iris).setContentTitle("IRIS")
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setContentIntent(PendingIntent.getActivity(this, 41,
                            new Intent(this, MainActivity.class),
                            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT))
                    .setAutoCancel(true).build();
            nm.notify(0x1815, n);
        } catch (Throwable ignored) { }
    }

    private void speakThenRunLocal(String text, Runnable afterSpeaking) {
        if (text == null || text.isEmpty() || !settings.voiceReplies() || textToSpeech == null || !ttsReady) {
            // No speech — just run after a brief pause
            handler.postDelayed(afterSpeaking, 600);
            return;
        }
        final boolean[] ran = {false};
        speechCancelled = false;
        requestSpeechFocus();
        textToSpeech.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) { }
            @Override public void onDone(String utteranceId) {
                if ("iris_greet".equals(utteranceId) && !ran[0]) {
                    ran[0] = true;
                    // Small settle delay so the audio tail fully flushes before the
                    // mic opens — prevents the greeting being cut off / re-heard.
                    handler.postDelayed(() -> {
                        textToSpeech.setOnUtteranceProgressListener(null);
                        abandonSpeechFocus();
                        if (!speechCancelled) afterSpeaking.run();
                    }, 300);
                }
            }
            @Override public void onError(String utteranceId) {
                if (!ran[0]) {
                    ran[0] = true;
                    handler.post(() -> { textToSpeech.setOnUtteranceProgressListener(null); abandonSpeechFocus(); if (!speechCancelled) afterSpeaking.run(); });
                }
            }
        });
        try {
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "iris_greet");
        } catch (Exception e) {
            abandonSpeechFocus();
            handler.postDelayed(afterSpeaking, 600);
        }
        // Safety net: if onDone never fires (some TTS engines), run after 6s max
        handler.postDelayed(() -> {
            if (!ran[0]) { ran[0] = true; textToSpeech.setOnUtteranceProgressListener(null); abandonSpeechFocus(); if (!speechCancelled) afterSpeaking.run(); }
        }, 6000);
    }

    private String callTimingWarning(String name, String number) {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        // Late night warning (11 PM - 6 AM)
        if (hour >= 23 || hour < 6) {
            return "It\u2019s late. Are you sure about calling " + name + "?";
        }
        // DND check
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL) {
                return "Do Not Disturb is on. Still want to call " + name + "?";
            }
        } catch (Exception ignored) { }
        // Memory preference: no calls after X
        String noCallsAfter = MemoryStore.findPreference(this, "no calls after");
        if (noCallsAfter != null) {
            try {
                int cutoff = Integer.parseInt(noCallsAfter.replaceAll("[^0-9]", ""));
                if (cutoff > 0 && cutoff <= 24 && hour >= cutoff) {
                    return "Your rule says no calls after " + cutoff + ". Override for " + name + "?";
                }
            } catch (Exception ignored) { }
        }

        // Repeated calls check
        ProfileStore store = new ProfileStore(this);
        for (ProfileStore.Entry entry : store.getEntries()) {
            if (entry.phoneNumber != null && entry.phoneNumber.replaceAll("[^0-9+]", "").equals(
                    number.replaceAll("[^0-9+]", "")) && entry.callCount >= 3) {
                long hoursSinceLast = (System.currentTimeMillis() - entry.lastCalled) / 3_600_000;
                if (hoursSinceLast < 2) {
                    return "You\u2019ve called " + name + " " + entry.callCount + " times recently. Try again?";
                }
            }
        }
        return null;
    }

    /** A varied, natural wake greeting so IRIS doesn't sound robotic. */
    private String wakeGreeting() {
        String name = MemoryStore.ownerName(this);
        String n = butlerAddress();
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String tod = hour < 6 ? "" : hour < 12 ? "Morning" : hour < 17 ? "Afternoon" : hour < 21 ? "Evening" : "";
        String personality = settings.personality();
        if ("Professional".equals(personality)) {
            return pick("Yes" + n + "?", "How can I help" + n + "?", "At your service" + n + ".",
                    "Listening" + n + ".", "Go ahead" + n + ".");
        }
        if ("Sarcastic".equals(personality)) {
            return pick("You rang" + n + "?", "What now" + n + "?", "I'm all ears" + n + ".",
                    "Yeah" + n + ", what's up?", "Back again" + n + "? What do you need?");
        }
        // Warm / default
        String[] base = {
                "Hey" + n + ", what can I do?",
                "Yes" + n + "? I'm listening.",
                "Hi" + n + ", how can I help?",
                "I'm here" + n + ". What do you need?",
                "What's up" + n + "?",
                "Go ahead" + n + ", I'm listening."
        };
        String g = base[chatRandom.nextInt(base.length)];
        // Occasionally prepend the time of day for a natural touch
        if (!tod.isEmpty() && chatRandom.nextInt(3) == 0) {
            g = tod + n + ". " + pick("What can I do?", "How can I help?", "I'm listening.");
        }
        return g;
    }

    private String timeGreeting() {
        String name = MemoryStore.ownerName(this);
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String greeting;
        if (hour < 6) greeting = "Up late?";
        else if (hour < 12) greeting = "Good morning";
        else if (hour < 17) greeting = "Good afternoon";
        else if (hour < 21) greeting = "Good evening";
        else greeting = "Still going?";
        return name != null ? greeting + ", " + name + "." : greeting + ". I\u2019m here.";
    }

    private String personalityLine(String event, String name) {
        String personality = settings.personality();
        if ("Silent".equals(personality)) return null;
        if ("Professional".equals(personality)) {
            if ("confirm".equals(event)) return "Call " + name + "?";
            if ("calling".equals(event)) return "Calling " + name;
            return "Call cancelled";
        }
        if ("Warm".equals(personality)) {
            if ("confirm".equals(event)) return "Would you like me to call " + name + "?";
            if ("calling".equals(event)) return "Of course. Calling " + name;
            return "No problem. I cancelled it.";
        }
        if ("confirm".equals(event)) return "Call " + name + "? Your thumbs seem grateful.";
        if ("calling".equals(event)) return "Calling " + name + ". Because typing was apparently too much work.";
        return "Cancelled. Consider it a rehearsal.";
    }

    private void vibrate(long milliseconds) {
        if (!settings.haptics()) return;
        Vibrator vibrator;
        if (Build.VERSION.SDK_INT >= 31) {
            android.os.VibratorManager vm = (android.os.VibratorManager) getSystemService(VIBRATOR_MANAGER_SERVICE);
            vibrator = vm != null ? vm.getDefaultVibrator() : null;
        } else {
            vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        }
        if (vibrator != null && vibrator.hasVibrator())
            vibrator.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE));
    }

    private boolean hasPermission(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void broadcastState(boolean active, String statePhase) {
        currentMic = microphoneLabel;
        sendBroadcast(new Intent(EVENT_STATE).setPackage(getPackageName())
                .putExtra(EXTRA_ACTIVE, active).putExtra(EXTRA_PHASE, statePhase)
                .putExtra(EXTRA_MIC, microphoneLabel).putExtra(EXTRA_RECOGNITION, recognitionLabel));
    }

    private void broadcastTranscript(String text) {
        sendBroadcast(new Intent(EVENT_TRANSCRIPT).setPackage(getPackageName()).putExtra(EXTRA_TEXT, text));
    }

    private void broadcastCallPrompt(String name, String number) {
        sendBroadcast(new Intent(EVENT_CALL_PROMPT).setPackage(getPackageName())
                .putExtra(EXTRA_NAME, name).putExtra(EXTRA_NUMBER, number));
    }

    private void broadcastMessage(String text) {
        if (text != null) sendBroadcast(new Intent(EVENT_MESSAGE).setPackage(getPackageName()).putExtra(EXTRA_TEXT, text));
    }

    @Override public void onReadyForSpeech(Bundle params) {
        broadcastMessage(phase.equals(PHASE_CONFIRM) ? "Say Call or Cancel…" : "Listening — speak naturally now.");
        if (PHASE_COMMAND.equals(phase)) playListeningEarcon();
    }
    @Override public void onBeginningOfSpeech() { broadcastMessage("I hear you…"); }
    @Override public void onRmsChanged(float rmsdB) {
        long now = System.currentTimeMillis();
        if (now - lastLevelBroadcast < 90) return;
        lastLevelBroadcast = now;
        float normalized = Math.max(0f, Math.min(1f, (rmsdB + 2f) / 14f));
        sendBroadcast(new Intent(EVENT_LEVEL).setPackage(getPackageName()).putExtra(EXTRA_LEVEL, normalized));
    }
    @Override public void onBufferReceived(byte[] buffer) { }
    @Override public void onEndOfSpeech() { broadcastMessage("Thinking…"); }

    @Override
    public void onError(int error) {
        if (!isRunning) return;
        if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                && error != SpeechRecognizer.ERROR_CLIENT) LogStore.append(this, "LISTEN ERROR", speechError(error));
        // Google STT failed for a command — fall back to offline Vosk on network/availability errors.
        if (PHASE_COMMAND.equals(phase) && googleCommandActive) {
            googleCommandActive = false;
            if (commandTimeout != null) { handler.removeCallbacks(commandTimeout); commandTimeout = null; }
            if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    || error == SpeechRecognizer.ERROR_AUDIO || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY
                    || error == SpeechRecognizer.ERROR_CLIENT) {
                retryUnclearCommand("I didn't catch that clearly. Please repeat after I finish speaking.");
                return;
            }
            boolean networkish = error == SpeechRecognizer.ERROR_NETWORK
                    || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT
                    || error == SpeechRecognizer.ERROR_SERVER
                    || error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED
                    || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE
                    || error == SpeechRecognizer.ERROR_CLIENT
                    || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY;
            if (networkish && voskReady && voskEngine != null) {
                LogStore.append(this, "LISTEN", "Google STT " + speechError(error) + " \u2192 Vosk fallback");
                destroyRecognizer();
                String prompt = "The system speech service is unavailable. Please repeat for the offline Indian English recognizer.";
                broadcastMessage(prompt);
                speakThenRun(prompt, this::startVoskCommandRecognition);
                return;
            }
        }
        if (PHASE_CONFIRM.equals(phase)) {
            if (confirmationRetries++ < 1) handler.postDelayed(this::startConfirmationRecognition, 450);
            return;
        }
        rearmAfterAction();
    }

    @Override
    public void onResults(Bundle results) {
        if (!isRunning || (!PHASE_CONFIRM.equals(phase) && !googleCommandActive)) return;
        googleCommandActive = false;
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        String heard = matches == null || matches.isEmpty() ? "" : matches.get(0);
        if (heard == null) heard = "";
        if (PHASE_CONFIRM.equals(phase)) { handleConfirmation(heard); return; }
        float[] confidence = results.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES);
        if (heard.trim().isEmpty() || (confidence != null && confidence.length > 0
                && SpeechText.lowConfidence(confidence[0]))) {
            try { recognitionStats().recordUnclear(); } catch (Throwable ignored) { }
            if (!heard.trim().isEmpty()) lastHeardTranscript = heard;   // for the "I meant…" card
            retryUnclearCommand("I'm not confident I heard you correctly. Please say that once more.");
            return;
        }
        if (commandTimeout != null) { handler.removeCallbacks(commandTimeout); commandTimeout = null; }
        destroyRecognizer();
        try {
            recordTranscript(heard);
        } catch (Throwable ignored) { }
        // Never execute partial hypotheses or switch to a different contact from a lower-ranked guess.
        broadcastTranscript(heard);
        handleCommand(heard);
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) broadcastTranscript(matches.get(0));
    }

    @Override public void onEvent(int eventType, Bundle params) { }

    private String speechError(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "Microphone audio error";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "Microphone permission missing";
            case SpeechRecognizer.ERROR_NETWORK: return "Speech service network error";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "Speech service is busy";
            default: return "Speech recognition paused (" + error + ")";
        }
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        handler.removeCallbacksAndMessages(null);
        teardownTriggers();
        abandonSpeechFocus();
        restoreRecognizerBeep();
        destroyRecognizer();
        stopWakeEngine();
        releaseAudioRoute();
        if (wakeLock != null && wakeLock.isHeld()) { wakeLock.release(); wakeLock = null; }
        if (textToSpeech != null) textToSpeech.shutdown();
        releaseServerTts();

        if (voskEngine != null) { voskEngine.close(); voskEngine = null; }
        if (llmAgent != null) { llmAgent.close(); llmAgent = null; }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private static class ContactMatch {
        final String name;
        final String number;
        final double score;
        ContactMatch(String name, String number, double score) {
            this.name = name; this.number = number; this.score = score;
        }
    }
}
