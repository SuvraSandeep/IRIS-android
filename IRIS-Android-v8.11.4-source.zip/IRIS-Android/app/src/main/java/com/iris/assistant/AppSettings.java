package com.iris.assistant;

import android.content.Context;
import android.content.SharedPreferences;

public final class AppSettings {
    public static final String MODE_WAKE = "wake";
    public static final String MODE_TAP = "tap";
    public static final String MODE_CONTINUOUS = "continuous";
    public static final String LOG_COMMANDS = "commands";
    public static final String LOG_FULL = "full";
    public static final String LOG_OFF = "off";

    private static final String PREFS = "iris_settings_v2";
    private final SharedPreferences prefs;

    public AppSettings(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String listeningMode() { return prefs.getString("listening_mode", MODE_WAKE); }
    public void setListeningMode(String value) { prefs.edit().putString("listening_mode", value).apply(); }
    public String logMode() { return prefs.getString("log_mode", LOG_COMMANDS); }
    public void setLogMode(String value) { prefs.edit().putString("log_mode", value).apply(); }
    public int retentionDays() { return prefs.getInt("retention_days", 7); }
    public void setRetentionDays(int value) { prefs.edit().putInt("retention_days", value).apply(); }
    public String personality() { return prefs.getString("personality", "Sarcastic"); }
    public void setPersonality(String value) { prefs.edit().putString("personality", value).apply(); }
    public boolean requireUnlock() { return prefs.getBoolean("require_unlock", true); }
    public void setRequireUnlock(boolean value) { prefs.edit().putBoolean("require_unlock", value).apply(); }
    public boolean haptics() { return prefs.getBoolean("haptics", true); }
    public void setHaptics(boolean value) { prefs.edit().putBoolean("haptics", value).apply(); }
    public boolean voiceReplies() { return prefs.getBoolean("voice_replies", true); }
    public void setVoiceReplies(boolean value) { prefs.edit().putBoolean("voice_replies", value).apply(); }
    /** Exact TTS voice name the user picked (empty = auto-select a female en-IN voice). */
    public String ttsVoiceName() { return prefs.getString("tts_voice_name", ""); }
    public void setTtsVoiceName(String v) { prefs.edit().putString("tts_voice_name", v == null ? "" : v).apply(); }
    public boolean preferOnDevice() { return prefs.getBoolean("prefer_on_device", false); }
    public void setPreferOnDevice(boolean value) { prefs.edit().putBoolean("prefer_on_device", value).apply(); }
    public String preferredMicrophone() { return prefs.getString("preferred_microphone", "Automatic"); }
    public void setPreferredMicrophone(String value) { prefs.edit().putString("preferred_microphone", value).apply(); }
    public String languageTag() { return prefs.getString("language_tag", "en-IN"); }
    public void setLanguageTag(String value) { prefs.edit().putString("language_tag", value).apply(); }
    public String resolvedLanguageTag() {
        String value = languageTag();
        if ("hinglish".equals(value)) return "en-IN";
        return "system".equals(value) ? java.util.Locale.getDefault().toLanguageTag() : value;
    }
    public float textScale() { return prefs.getFloat("text_scale", 1.0f); }
    public void setTextScale(float value) { prefs.edit().putFloat("text_scale", value).apply(); }
    public String hfToken() { return prefs.getString("hf_token", ""); }
    public void setHfToken(String value) { prefs.edit().putString("hf_token", value == null ? "" : value.trim()).apply(); }
    /** Whether the on-device AI brain (LLM) is used. Off by default for stability;
     *  the rule-based engine handles all commands reliably without it. */
    public boolean aiEnabled() { return prefs.getBoolean("ai_enabled", false); }
    public void setAiEnabled(boolean value) { prefs.edit().putBoolean("ai_enabled", value).apply(); }
    /** Use the large, high-accuracy Vosk en-IN model (~1GB, downloaded on first use).
     *  Off by default; falls back to the small model automatically if it can't load. */
    public boolean highAccuracyVoice() { return prefs.getBoolean("high_accuracy_voice", false); }
    public void setHighAccuracyVoice(boolean value) { prefs.edit().putBoolean("high_accuracy_voice", value).apply(); }
    /** Server mode: use a private online server for smarter NLP/STT; auto-falls back offline. */
    public boolean serverModeEnabled() { return prefs.getBoolean("server_mode", false); }
    public void setServerModeEnabled(boolean v) { prefs.edit().putBoolean("server_mode", v).apply(); }
    public String serverUrl() { return prefs.getString("server_url", ""); }
    public void setServerUrl(String v) { prefs.edit().putString("server_url", v == null ? "" : v.trim()).apply(); }
    public String serverToken() { return prefs.getString("server_token", ""); }
    public void setServerToken(String v) { prefs.edit().putString("server_token", v == null ? "" : v.trim()).apply(); }
    /** Send audio to the server's Whisper endpoint for transcription (best accent accuracy). */
    public boolean serverStt() { return prefs.getBoolean("server_stt", true); }
    public void setServerStt(boolean v) { prefs.edit().putBoolean("server_stt", v).apply(); }
    /** Speak replies with the server's Piper voice (falls back to Android TTS if unavailable). */
    public boolean serverTts() { return prefs.getBoolean("server_tts", false); }
    public void setServerTts(boolean v) { prefs.edit().putBoolean("server_tts", v).apply(); }
    public boolean autoOfflineWhenSlow() { return prefs.getBoolean("server_auto_offline_slow", true); }
    public void setAutoOfflineWhenSlow(boolean v) { prefs.edit().putBoolean("server_auto_offline_slow", v).apply(); }
    public int serverSlowMs() { return prefs.getInt("server_slow_ms", 30000); }
    public void setServerSlowMs(int v) { prefs.edit().putInt("server_slow_ms", v).apply(); }
    /** Let IRIS act on commands while the phone is locked (UI actions prompt a quick unlock). */
    public boolean lockScreenControl() { return prefs.getBoolean("lock_screen_control", false); }
    public void setLockScreenControl(boolean value) { prefs.edit().putBoolean("lock_screen_control", value).apply(); }
    /** Voice-verification strictness 0=lenient .. 1=strict (default balanced; missing verification always rejects). */
    public float voiceSensitivity() { return prefs.getFloat("owner_voice_sensitivity_v2", 0.5f); }
    public void setVoiceSensitivity(float value) { prefs.edit().putFloat("owner_voice_sensitivity_v2", value).apply(); }
    /** Use Google Speech Recognition for commands (best accuracy; falls back to Vosk offline). */
    public boolean googleSttForCommands() { return prefs.getBoolean("google_stt_commands", true); }
    public void setGoogleSttForCommands(boolean v) { prefs.edit().putBoolean("google_stt_commands", v).apply(); }
    /** Speak a cue when a wake voice isn't recognized as the owner. */
    public boolean voiceCueEnabled() { return prefs.getBoolean("voice_cue_enabled", true); }
    public void setVoiceCueEnabled(boolean value) { prefs.edit().putBoolean("voice_cue_enabled", value).apply(); }

    // ---------------- Appearance / customization ----------------
    public static final String THEME_DARK = "dark";
    public static final String THEME_AMOLED = "amoled";
    public static final String DENSITY_COMFORTABLE = "comfortable";
    public static final String DENSITY_COMPACT = "compact";
    public static final String DEFAULT_ACCENT = "#22D3EE";

    public String accentColor() { return prefs.getString("accent_color", DEFAULT_ACCENT); }
    public void setAccentColor(String hex) { prefs.edit().putString("accent_color", hex).apply(); }
    public String theme() { return prefs.getString("ui_theme", THEME_DARK); }
    public void setTheme(String value) { prefs.edit().putString("ui_theme", value).apply(); }
    public boolean reduceMotion() { return prefs.getBoolean("reduce_motion", false); }
    public void setReduceMotion(boolean value) { prefs.edit().putBoolean("reduce_motion", value).apply(); }
    public String density() { return prefs.getString("ui_density", DENSITY_COMFORTABLE); }
    public void setDensity(String value) { prefs.edit().putString("ui_density", value).apply(); }
    /** CSV of quick-action chip ids shown on the home screen. */
    public String homeChips() { return prefs.getString("home_chips", "call,text,alarm,weather,torch,time"); }
    public void setHomeChips(String csv) { prefs.edit().putString("home_chips", csv).apply(); }
    public boolean speakerVerification() { return true; } // owner verification is mandatory for voice wake
    public void setSpeakerVerification(boolean value) { prefs.edit().putBoolean("speaker_verification", value).apply(); }
    public boolean shakeToWake() { return prefs.getBoolean("shake_to_wake", false); }
    public void setShakeToWake(boolean v) { prefs.edit().putBoolean("shake_to_wake", v).apply(); }
    public boolean headsetTrigger() { return prefs.getBoolean("headset_trigger", false); }
    public void setHeadsetTrigger(boolean v) { prefs.edit().putBoolean("headset_trigger", v).apply(); }
    public boolean mirrorReplies() { return prefs.getBoolean("mirror_replies", true); }
    public void setMirrorReplies(boolean v) { prefs.edit().putBoolean("mirror_replies", v).apply(); }
    public boolean mirrorMajorOnly() { return prefs.getBoolean("mirror_major_only", true); }
    public void setMirrorMajorOnly(boolean v) { prefs.edit().putBoolean("mirror_major_only", v).apply(); }
    /** Mirror replies even while the screen is on (not just when it's off). */
    public boolean mirrorAlways() { return prefs.getBoolean("mirror_always", true); }
    public void setMirrorAlways(boolean v) { prefs.edit().putBoolean("mirror_always", v).apply(); }
    public float speakerThreshold() { return prefs.getFloat("speaker_threshold", 0.70f); }
    public void setSpeakerThreshold(float value) { prefs.edit().putFloat("speaker_threshold", value).apply(); }
}
