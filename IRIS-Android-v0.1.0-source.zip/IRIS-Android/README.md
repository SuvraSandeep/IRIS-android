# IRIS

**Intelligent Responsive Interaction System**

IRIS is a native Android personal-assistant MVP focused on one job: listen for a call request, resolve the contact, and ask for confirmation before placing the call.

## What this version does

- Glowing one-tap assistant orb with clear listening state.
- Continuous listening through an Android foreground service.
- Prefers a connected Bluetooth, wired, or USB headset microphone; otherwise uses the phone microphone.
- Understands `Call <contact>`, `Dial <contact>`, and `Phone <contact>`.
- Requires visual or notification confirmation before calling.
- Voice-training flow: choose a contact and repeat your natural phrase three times.
- Local persistent profile containing contact mappings and learned command phrases.
- Export/import through a transferable `.irisprofile` JSON file.
- Persistent activity timeline with transcript, match, decision, error, and call events.
- Log export and clear controls.
- No raw audio is saved by IRIS.

## Important privacy detail

IRIS stores its training profile and activity log in the app's private on-device storage. The standard Android `SpeechRecognizer` is used for transcription with offline recognition preferred. Whether transcription is entirely offline ultimately depends on the speech-recognition service installed on the phone. Raw microphone audio is not written to IRIS storage.

An exported `.irisprofile` is readable JSON and contains contact names, phone numbers, and learned phrases. Keep it private.

## Build in GitHub Actions

1. Create a new empty GitHub repository.
2. Extract this ZIP and upload the **contents inside `IRIS-Android`** to the repository root. The root should contain `app`, `.github`, `build.gradle`, and `settings.gradle`.
3. Open the repository's **Actions** tab.
4. Select **Build IRIS Android APK** and choose **Run workflow**.
5. When the run finishes, open it and download the `IRIS-v0.1.0-debug-apk` artifact.
6. Extract the artifact ZIP and install `IRIS-v0.1.0-debug.apk` on an Android phone.

The workflow also runs automatically when source is pushed to `main` or `master`.

## First use

1. Tap the IRIS orb.
2. Grant microphone, contacts, phone, notification, and Bluetooth permissions when relevant.
3. Say `Call Rahul` (replace Rahul with a saved contact).
4. Confirm the contact and number before IRIS calls.
5. For nicknames or personal wording, open **Training**, choose a contact, and complete three samples.

## Compatibility

- Android 8.0+ (`minSdk 26`)
- Compiles against Android 15 (`compileSdk 35`)
- Java 17
- Gradle 8.9 in CI

## MVP limitations

- This is phrase/nickname adaptation, not biometric speaker recognition and not custom acoustic-model training.
- Android may suspend or stop microphone access under aggressive manufacturer battery restrictions.
- If direct-call permission is denied, IRIS opens the dialer with the number filled in.
- Contact matching deliberately asks for confirmation because duplicate or similar contact names are possible.
- A debug APK is produced for easy testing; a production Play Store release needs your own signing key, privacy policy, and store declarations for microphone, contacts, and call permissions.

## Project structure

```text
app/src/main/java/com/iris/assistant/
├── MainActivity.java            # UI, permissions, training, import/export
├── IrisListeningService.java    # foreground mic, recognition, contact lookup, calls
├── ProfileStore.java            # persistent learned phrases and profile transfer
├── LogStore.java                # private activity timeline
└── IrisOrbView.java             # animated interactive assistant orb
```
