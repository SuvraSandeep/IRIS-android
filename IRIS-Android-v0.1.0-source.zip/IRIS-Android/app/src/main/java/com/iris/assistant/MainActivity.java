package com.iris.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PERMISSION_START = 100;
    private static final int PERMISSION_TRAIN = 101;
    private static final int PICK_CONTACT = 200;
    private static final int EXPORT_PROFILE = 201;
    private static final int IMPORT_PROFILE = 202;
    private static final int EXPORT_LOGS = 203;

    private FrameLayout contentHost;
    private Button tabAssistant;
    private Button tabTraining;
    private Button tabLogs;
    private int selectedTab;

    private IrisOrbView irisOrb;
    private TextView statusText;
    private TextView subStatusText;
    private TextView liveTranscript;
    private TextView micRouteText;
    private String lastMicRoute = "Phone microphone";

    private TextView trainingStep;
    private TextView trainingContact;
    private TextView trainingPrompt;
    private TextView profileSummary;
    private Button startTrainingButton;
    private SpeechRecognizer trainingRecognizer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> trainingSamples = new ArrayList<>();
    private int trainingSampleIndex;
    private int trainingErrorCount;
    private String selectedContactName;
    private String selectedContactNumber;
    private boolean resumeAfterTraining;
    private boolean confirmationShowing;

    private final BroadcastReceiver irisEvents = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (IrisListeningService.EVENT_STATE.equals(action)) {
                boolean active = intent.getBooleanExtra(IrisListeningService.EXTRA_ACTIVE, false);
                String mic = intent.getStringExtra(IrisListeningService.EXTRA_MIC);
                if (mic != null && !mic.isEmpty()) lastMicRoute = mic;
                updateAssistantState(active);
            } else if (IrisListeningService.EVENT_TRANSCRIPT.equals(action)) {
                String text = intent.getStringExtra(IrisListeningService.EXTRA_TEXT);
                if (liveTranscript != null && text != null) liveTranscript.setText("“" + text + "”");
            } else if (IrisListeningService.EVENT_MESSAGE.equals(action)) {
                showAssistantMessage(intent.getStringExtra(IrisListeningService.EXTRA_TEXT));
            } else if (IrisListeningService.EVENT_CALL_PROMPT.equals(action)) {
                showCallConfirmation(intent.getStringExtra(IrisListeningService.EXTRA_NAME),
                        intent.getStringExtra(IrisListeningService.EXTRA_NUMBER));
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contentHost = findViewById(R.id.contentHost);
        tabAssistant = findViewById(R.id.tabAssistant);
        tabTraining = findViewById(R.id.tabTraining);
        tabLogs = findViewById(R.id.tabLogs);

        tabAssistant.setOnClickListener(v -> showAssistant());
        tabTraining.setOnClickListener(v -> showTraining());
        tabLogs.setOnClickListener(v -> showLogs());
        showAssistant();
        handleCallIntent(getIntent());
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter();
        filter.addAction(IrisListeningService.EVENT_STATE);
        filter.addAction(IrisListeningService.EVENT_TRANSCRIPT);
        filter.addAction(IrisListeningService.EVENT_CALL_PROMPT);
        filter.addAction(IrisListeningService.EVENT_MESSAGE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(irisEvents, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(irisEvents, filter);
    }

    @Override
    protected void onStop() {
        try { unregisterReceiver(irisEvents); } catch (Exception ignored) { }
        super.onStop();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleCallIntent(intent);
    }

    private void showAssistant() {
        selectedTab = 0;
        contentHost.removeAllViews();
        View view = LayoutInflater.from(this).inflate(R.layout.view_assistant, contentHost, false);
        contentHost.addView(view);
        irisOrb = view.findViewById(R.id.irisOrb);
        statusText = view.findViewById(R.id.statusText);
        subStatusText = view.findViewById(R.id.subStatusText);
        liveTranscript = view.findViewById(R.id.liveTranscript);
        micRouteText = view.findViewById(R.id.micRouteText);
        irisOrb.setOnClickListener(v -> toggleIris());
        updateTabs();
        updateAssistantState(IrisListeningService.isRunning);
    }

    private void showTraining() {
        selectedTab = 1;
        contentHost.removeAllViews();
        View view = LayoutInflater.from(this).inflate(R.layout.view_training, contentHost, false);
        contentHost.addView(view);
        trainingStep = view.findViewById(R.id.trainingStep);
        trainingContact = view.findViewById(R.id.trainingContact);
        trainingPrompt = view.findViewById(R.id.trainingPrompt);
        profileSummary = view.findViewById(R.id.profileSummary);
        startTrainingButton = view.findViewById(R.id.startTrainingButton);
        Button export = view.findViewById(R.id.exportProfileButton);
        Button importButton = view.findViewById(R.id.importProfileButton);
        startTrainingButton.setOnClickListener(v -> requestContactForTraining());
        export.setOnClickListener(v -> createProfileDocument());
        importButton.setOnClickListener(v -> openProfileDocument());
        updateProfileSummary();
        updateTabs();
    }

    private void showLogs() {
        selectedTab = 2;
        contentHost.removeAllViews();
        View view = LayoutInflater.from(this).inflate(R.layout.view_logs, contentHost, false);
        contentHost.addView(view);
        TextView logText = view.findViewById(R.id.logText);
        String logs = LogStore.readNewestFirst(this);
        logText.setText(logs.isEmpty() ? "No activity yet. IRIS is impressively innocent." : logs);
        view.findViewById(R.id.exportLogsButton).setOnClickListener(v -> createLogDocument());
        view.findViewById(R.id.clearLogsButton).setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Clear IRIS activity?")
                .setMessage("This removes the local timeline. Your trained profile stays untouched.")
                .setNegativeButton("Keep it", null)
                .setPositiveButton("Clear", (dialog, which) -> {
                    LogStore.clear(this);
                    logText.setText("No activity yet. IRIS is impressively innocent.");
                }).show());
        updateTabs();
    }

    private void updateTabs() {
        Button[] tabs = {tabAssistant, tabTraining, tabLogs};
        for (int i = 0; i < tabs.length; i++) {
            tabs[i].setBackgroundResource(i == selectedTab
                    ? R.drawable.bg_button_primary : R.drawable.bg_button_secondary);
            tabs[i].setTextColor(Color.WHITE);
        }
    }

    private void toggleIris() {
        if (IrisListeningService.isRunning) {
            stopListeningService();
        } else {
            ensureStartPermissions();
        }
    }

    private void ensureStartPermissions() {
        List<String> missing = new ArrayList<>();
        addIfMissing(missing, Manifest.permission.RECORD_AUDIO);
        addIfMissing(missing, Manifest.permission.READ_CONTACTS);
        addIfMissing(missing, Manifest.permission.CALL_PHONE);
        if (Build.VERSION.SDK_INT >= 31) addIfMissing(missing, Manifest.permission.BLUETOOTH_CONNECT);
        if (Build.VERSION.SDK_INT >= 33) addIfMissing(missing, Manifest.permission.POST_NOTIFICATIONS);
        if (missing.isEmpty()) startListeningService();
        else new AlertDialog.Builder(this)
                .setTitle("IRIS needs a few doors opened")
                .setMessage("Microphone lets IRIS hear; Contacts finds the right person; Phone places the confirmed call; Notifications keep listening visible. You can deny optional access and IRIS will gracefully do less.")
                .setNegativeButton("Not now", null)
                .setPositiveButton("Continue", (dialog, which) ->
                        requestPermissions(missing.toArray(new String[0]), PERMISSION_START))
                .show();
    }

    private void startListeningService() {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
            toast("Microphone permission is required to listen.");
            return;
        }
        Intent service = new Intent(this, IrisListeningService.class).setAction(IrisListeningService.ACTION_START);
        startForegroundService(service);
        updateAssistantState(true);
    }

    private void stopListeningService() {
        Intent service = new Intent(this, IrisListeningService.class).setAction(IrisListeningService.ACTION_STOP);
        startService(service);
        updateAssistantState(false);
    }

    private void updateAssistantState(boolean active) {
        if (irisOrb == null) return;
        irisOrb.setActive(active);
        statusText.setText(active ? "IRIS is awake" : "IRIS is resting");
        statusText.setTextColor(active ? getColor(R.color.cyan) : getColor(R.color.text_primary));
        subStatusText.setText(active ? "Listening for a call command." : "Tap the orb when you need me.");
        micRouteText.setText("Microphone: " + lastMicRoute);
        if (!active) liveTranscript.setText("Say “Call <contact name>”");
    }

    private void showAssistantMessage(String message) {
        if (message == null || message.trim().isEmpty()) return;
        if (subStatusText != null) subStatusText.setText(message);
    }

    private void requestContactForTraining() {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)
                || !hasPermission(Manifest.permission.READ_CONTACTS)) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_CONTACTS}, PERMISSION_TRAIN);
            return;
        }
        launchContactPicker();
    }

    private void launchContactPicker() {
        Intent pick = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        try {
            startActivityForResult(pick, PICK_CONTACT);
        } catch (Exception error) {
            toast("No contacts app is available on this phone.");
        }
    }

    private void beginVoiceTraining() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("No speech recognition service is available.");
            return;
        }
        resumeAfterTraining = IrisListeningService.isRunning;
        if (resumeAfterTraining) stopListeningService();
        destroyTrainingRecognizer();
        trainingSamples.clear();
        trainingSampleIndex = 0;
        trainingErrorCount = 0;
        trainingRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        trainingRecognizer.setRecognitionListener(new TrainingListener());
        trainingContact.setText(selectedContactName);
        startTrainingButton.setEnabled(false);
        handler.postDelayed(this::recordNextTrainingSample, resumeAfterTraining ? 800 : 250);
    }

    private void recordNextTrainingSample() {
        if (trainingRecognizer == null || trainingSampleIndex >= 3) return;
        trainingStep.setText("SAMPLE " + (trainingSampleIndex + 1) + " OF 3");
        String ordinal = trainingSampleIndex == 0 ? "first" : trainingSampleIndex == 1 ? "again" : "one last time";
        trainingPrompt.setText("Say how you would ask IRIS to call " + selectedContactName + " — " + ordinal + ".");
        Intent speech = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speech.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        speech.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        speech.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag());
        try {
            trainingRecognizer.startListening(speech);
        } catch (Exception error) {
            trainingPrompt.setText("The microphone blinked. Tap retry.");
            startTrainingButton.setText("Retry sample");
            startTrainingButton.setEnabled(true);
            startTrainingButton.setOnClickListener(v -> {
                startTrainingButton.setEnabled(false);
                recordNextTrainingSample();
            });
        }
    }

    private void finishTraining() {
        new ProfileStore(this).addTraining(selectedContactName, selectedContactNumber, trainingSamples);
        LogStore.append(this, "TRAINED", selectedContactName + " with " + trainingSamples.size() + " phrases");
        trainingStep.setText("TRAINING COMPLETE");
        trainingContact.setText(selectedContactName + " is ready");
        trainingPrompt.setText("Learned: “" + String.join("”  •  “", trainingSamples) + "”");
        startTrainingButton.setText("Train another contact");
        startTrainingButton.setEnabled(true);
        startTrainingButton.setOnClickListener(v -> requestContactForTraining());
        destroyTrainingRecognizer();
        updateProfileSummary();
        if (resumeAfterTraining) {
            resumeAfterTraining = false;
            handler.postDelayed(this::startListeningService, 550);
        }
    }

    private void updateProfileSummary() {
        if (profileSummary == null) return;
        ProfileStore store = new ProfileStore(this);
        int contacts = store.getEntries().size();
        int phrases = store.phraseCount();
        profileSummary.setText(contacts + (contacts == 1 ? " trained contact" : " trained contacts")
                + "  •  " + phrases + (phrases == 1 ? " phrase" : " phrases"));
    }

    private void showCallConfirmation(String name, String number) {
        if (confirmationShowing || name == null || number == null) return;
        confirmationShowing = true;
        new AlertDialog.Builder(this)
                .setTitle("Call " + name + "?")
                .setMessage(number + "\n\nIRIS heard a call command and is waiting for you.")
                .setCancelable(true)
                .setNegativeButton("Cancel", (dialog, which) -> sendCallDecision(false, name, number))
                .setPositiveButton("Call", (dialog, which) -> sendCallDecision(true, name, number))
                .setOnCancelListener(dialog -> sendCallDecision(false, name, number))
                .setOnDismissListener(dialog -> confirmationShowing = false)
                .show();
    }

    private void sendCallDecision(boolean confirmed, String name, String number) {
        Intent service = new Intent(this, IrisListeningService.class)
                .setAction(confirmed ? IrisListeningService.ACTION_CONFIRM_CALL
                        : IrisListeningService.ACTION_CANCEL_CALL)
                .putExtra(IrisListeningService.EXTRA_NAME, name)
                .putExtra(IrisListeningService.EXTRA_NUMBER, number);
        startService(service);
    }

    private void handleCallIntent(Intent intent) {
        if (intent == null) return;
        String name = intent.getStringExtra(IrisListeningService.EXTRA_NAME);
        String number = intent.getStringExtra(IrisListeningService.EXTRA_NUMBER);
        if (name != null && number != null) {
            intent.removeExtra(IrisListeningService.EXTRA_NAME);
            intent.removeExtra(IrisListeningService.EXTRA_NUMBER);
            handler.postDelayed(() -> showCallConfirmation(name, number), 250);
        }
    }

    private void createProfileDocument() {
        Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json")
                .putExtra(Intent.EXTRA_TITLE, "IRIS-profile-v1.irisprofile");
        startActivityForResult(create, EXPORT_PROFILE);
    }

    private void openProfileDocument() {
        Intent open = new Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*");
        startActivityForResult(open, IMPORT_PROFILE);
    }

    private void createLogDocument() {
        String day = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("text/plain")
                .putExtra(Intent.EXTRA_TITLE, "IRIS-activity-" + day + ".txt");
        startActivityForResult(create, EXPORT_LOGS);
    }

    private void writeText(Uri uri, String text) throws Exception {
        try (OutputStream output = getContentResolver().openOutputStream(uri, "wt")) {
            if (output == null) throw new IllegalStateException("Could not open destination");
            output.write(text.getBytes(StandardCharsets.UTF_8));
        }
    }

    private String readText(Uri uri) throws Exception {
        StringBuilder result = new StringBuilder();
        try (InputStream input = getContentResolver().openInputStream(uri);
             BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) result.append(line).append('\n');
        }
        return result.toString();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == PICK_CONTACT) {
                try (Cursor cursor = getContentResolver().query(uri,
                        new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                                ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null)) {
                    if (cursor != null && cursor.moveToFirst()) {
                        selectedContactName = cursor.getString(0);
                        selectedContactNumber = cursor.getString(1);
                        beginVoiceTraining();
                    }
                }
            } else if (requestCode == EXPORT_PROFILE) {
                writeText(uri, new ProfileStore(this).exportJson());
                toast("IRIS profile exported.");
            } else if (requestCode == IMPORT_PROFILE) {
                int count = new ProfileStore(this).importAndMerge(readText(uri));
                LogStore.append(this, "IMPORT", count + " profile entries merged");
                updateProfileSummary();
                toast("Merged " + count + " trained contacts.");
            } else if (requestCode == EXPORT_LOGS) {
                String logs = LogStore.readNewestFirst(this);
                writeText(uri, logs.isEmpty() ? "IRIS has no recorded activity.\n" : logs);
                toast("Activity log exported.");
            }
        } catch (Exception error) {
            toast("That didn't work: " + error.getMessage());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_START) {
            if (hasPermission(Manifest.permission.RECORD_AUDIO)) startListeningService();
            else toast("IRIS cannot listen without microphone access.");
        } else if (requestCode == PERMISSION_TRAIN) {
            if (hasPermission(Manifest.permission.RECORD_AUDIO)
                    && hasPermission(Manifest.permission.READ_CONTACTS)) launchContactPicker();
            else toast("Voice training needs microphone and contacts access.");
        }
    }

    private class TrainingListener implements RecognitionListener {
        @Override public void onReadyForSpeech(Bundle params) { trainingPrompt.setText("Listening… say it naturally."); }
        @Override public void onBeginningOfSpeech() { trainingPrompt.setText("Got you. Keep going…"); }
        @Override public void onRmsChanged(float rmsdB) { }
        @Override public void onBufferReceived(byte[] buffer) { }
        @Override public void onEndOfSpeech() { trainingPrompt.setText("Saving that sample…"); }

        @Override
        public void onError(int error) {
            if (trainingRecognizer == null) return;
            trainingErrorCount++;
            if (trainingErrorCount < 3) {
                trainingPrompt.setText("I missed that one. Stay natural—trying the same sample again.");
                handler.postDelayed(MainActivity.this::recordNextTrainingSample, 800);
            } else {
                trainingPrompt.setText("The speech service is having a moment. Check the microphone, then retry this sample.");
                startTrainingButton.setText("Retry sample " + (trainingSampleIndex + 1));
                startTrainingButton.setEnabled(true);
                startTrainingButton.setOnClickListener(v -> {
                    trainingErrorCount = 0;
                    startTrainingButton.setEnabled(false);
                    recordNextTrainingSample();
                });
            }
        }

        @Override
        public void onResults(Bundle results) {
            ArrayList<String> heard = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (heard == null || heard.isEmpty() || heard.get(0).trim().isEmpty()) {
                onError(SpeechRecognizer.ERROR_NO_MATCH);
                return;
            }
            String phrase = heard.get(0).trim();
            trainingErrorCount = 0;
            trainingSamples.add(phrase);
            trainingSampleIndex++;
            if (trainingSampleIndex >= 3) finishTraining();
            else {
                trainingPrompt.setText("Learned “" + phrase + "”. Nice. Next sample…");
                handler.postDelayed(MainActivity.this::recordNextTrainingSample, 850);
            }
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
            ArrayList<String> heard = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (heard != null && !heard.isEmpty()) trainingPrompt.setText("“" + heard.get(0) + "”");
        }

        @Override public void onEvent(int eventType, Bundle params) { }
    }

    private void destroyTrainingRecognizer() {
        handler.removeCallbacksAndMessages(null);
        if (trainingRecognizer != null) {
            trainingRecognizer.cancel();
            trainingRecognizer.destroy();
            trainingRecognizer = null;
        }
    }

    private void addIfMissing(List<String> list, String permission) {
        if (!hasPermission(permission)) list.add(permission);
    }

    private boolean hasPermission(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        destroyTrainingRecognizer();
        super.onDestroy();
    }
}
