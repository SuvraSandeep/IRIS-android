package com.iris.assistant;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class LogStore {
    private static final String FILE_NAME = "iris_activity.log";
    private static final long MAX_BYTES = 750_000L;
    private static final Object LOCK = new Object();

    private LogStore() { }

    public static void append(Context context, String type, String message) {
        synchronized (LOCK) {
            try {
                File file = new File(context.getFilesDir(), FILE_NAME);
                if (file.exists() && file.length() > MAX_BYTES) trim(file);
                String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
                String safe = message == null ? "" : message.replace('\n', ' ').replace('\r', ' ');
                String line = time + "  " + type + "  " + safe + "\n";
                try (FileOutputStream out = new FileOutputStream(file, true)) {
                    out.write(line.getBytes(StandardCharsets.UTF_8));
                }
            } catch (Exception ignored) { }
        }
    }

    public static String readNewestFirst(Context context) {
        synchronized (LOCK) {
            File file = new File(context.getFilesDir(), FILE_NAME);
            if (!file.exists()) return "";
            List<String> lines = new ArrayList<>();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                    new FileInputStream(file), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) lines.add(line);
            } catch (Exception ignored) { }
            Collections.reverse(lines);
            if (lines.size() > 500) lines = lines.subList(0, 500);
            return String.join("\n\n", lines);
        }
    }

    public static void clear(Context context) {
        synchronized (LOCK) {
            File file = new File(context.getFilesDir(), FILE_NAME);
            if (file.exists()) file.delete();
        }
    }

    private static void trim(File file) throws Exception {
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) lines.add(line);
        }
        int start = Math.max(0, lines.size() / 2);
        try (FileOutputStream out = new FileOutputStream(file, false)) {
            for (int i = start; i < lines.size(); i++) {
                out.write((lines.get(i) + "\n").getBytes(StandardCharsets.UTF_8));
            }
        }
    }
}
