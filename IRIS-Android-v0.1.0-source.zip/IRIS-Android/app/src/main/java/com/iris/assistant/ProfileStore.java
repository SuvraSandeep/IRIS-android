package com.iris.assistant;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ProfileStore {
    private static final String PREFS = "iris_profile_store";
    private static final String KEY = "profile_json";

    public static class Entry {
        public String contactName;
        public String phoneNumber;
        public final List<String> phrases = new ArrayList<>();
    }

    public static class Match {
        public final String contactName;
        public final String phoneNumber;
        public final String phrase;
        public final double confidence;

        Match(String contactName, String phoneNumber, String phrase, double confidence) {
            this.contactName = contactName;
            this.phoneNumber = phoneNumber;
            this.phrase = phrase;
            this.confidence = confidence;
        }
    }

    private final SharedPreferences prefs;

    public ProfileStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized List<Entry> getEntries() {
        List<Entry> result = new ArrayList<>();
        try {
            JSONObject root = new JSONObject(prefs.getString(KEY, "{\"profiles\":[]}"));
            JSONArray profiles = root.optJSONArray("profiles");
            if (profiles == null) return result;
            for (int i = 0; i < profiles.length(); i++) {
                JSONObject item = profiles.getJSONObject(i);
                Entry entry = new Entry();
                entry.contactName = item.optString("contactName", "");
                entry.phoneNumber = item.optString("phoneNumber", "");
                JSONArray phrases = item.optJSONArray("phrases");
                if (phrases != null) {
                    for (int p = 0; p < phrases.length(); p++) {
                        String phrase = phrases.optString(p, "").trim();
                        if (!phrase.isEmpty()) entry.phrases.add(phrase);
                    }
                }
                if (!entry.contactName.isEmpty() && !entry.phoneNumber.isEmpty()) result.add(entry);
            }
        } catch (Exception ignored) { }
        return result;
    }

    public synchronized void addTraining(String name, String number, List<String> phrases) {
        List<Entry> entries = getEntries();
        Entry target = null;
        String normalizedNumber = normalizeNumber(number);
        for (Entry entry : entries) {
            if (normalizeNumber(entry.phoneNumber).equals(normalizedNumber)) {
                target = entry;
                break;
            }
        }
        if (target == null) {
            target = new Entry();
            target.contactName = name;
            target.phoneNumber = number;
            entries.add(target);
        }
        target.contactName = name;
        for (String phrase : phrases) {
            boolean exists = false;
            for (String old : target.phrases) {
                if (normalize(old).equals(normalize(phrase))) exists = true;
            }
            if (!exists && !phrase.trim().isEmpty()) target.phrases.add(phrase.trim());
        }
        save(entries);
    }

    public synchronized Match findMatch(String spokenText) {
        String heard = normalize(spokenText);
        Match best = null;
        for (Entry entry : getEntries()) {
            for (String phrase : entry.phrases) {
                String learned = normalize(phrase);
                double score;
                if (heard.equals(learned)) score = 1.0;
                else if (heard.contains(learned) || learned.contains(heard)) score = .91;
                else score = similarity(heard, learned);
                if (score >= .76 && (best == null || score > best.confidence)) {
                    best = new Match(entry.contactName, entry.phoneNumber, phrase, score);
                }
            }
        }
        return best;
    }

    public synchronized String exportJson() {
        try {
            JSONObject root = buildRoot(getEntries());
            root.put("exportedAt", System.currentTimeMillis());
            root.put("description", "IRIS transferable command-phrase profile");
            return root.toString(2);
        } catch (Exception e) {
            return "{\"schema\":\"iris-profile\",\"version\":1,\"profiles\":[]}";
        }
    }

    public synchronized int importAndMerge(String json) throws Exception {
        JSONObject root = new JSONObject(json);
        if (!"iris-profile".equals(root.optString("schema")) || root.optInt("version", -1) != 1) {
            throw new IllegalArgumentException("This is not a supported IRIS profile.");
        }
        JSONArray profiles = root.getJSONArray("profiles");
        List<Entry> current = getEntries();
        Map<String, Entry> merged = new LinkedHashMap<>();
        for (Entry entry : current) merged.put(normalizeNumber(entry.phoneNumber), entry);
        int imported = 0;
        for (int i = 0; i < profiles.length(); i++) {
            JSONObject item = profiles.getJSONObject(i);
            String name = item.optString("contactName", "").trim();
            String number = item.optString("phoneNumber", "").trim();
            if (name.isEmpty() || number.isEmpty()) continue;
            Entry target = merged.get(normalizeNumber(number));
            if (target == null) {
                target = new Entry();
                target.contactName = name;
                target.phoneNumber = number;
                merged.put(normalizeNumber(number), target);
            }
            JSONArray phrases = item.optJSONArray("phrases");
            if (phrases != null) {
                for (int p = 0; p < phrases.length(); p++) {
                    String phrase = phrases.optString(p, "").trim();
                    if (phrase.isEmpty()) continue;
                    boolean duplicate = false;
                    for (String old : target.phrases) {
                        if (normalize(old).equals(normalize(phrase))) duplicate = true;
                    }
                    if (!duplicate) target.phrases.add(phrase);
                }
            }
            imported++;
        }
        save(new ArrayList<>(merged.values()));
        return imported;
    }

    public synchronized int phraseCount() {
        int count = 0;
        for (Entry entry : getEntries()) count += entry.phrases.size();
        return count;
    }

    private void save(List<Entry> entries) {
        prefs.edit().putString(KEY, buildRoot(entries).toString()).apply();
    }

    private JSONObject buildRoot(List<Entry> entries) {
        JSONObject root = new JSONObject();
        JSONArray profiles = new JSONArray();
        try {
            root.put("schema", "iris-profile");
            root.put("version", 1);
            for (Entry entry : entries) {
                JSONObject item = new JSONObject();
                item.put("contactName", entry.contactName);
                item.put("phoneNumber", entry.phoneNumber);
                JSONArray phrases = new JSONArray();
                for (String phrase : entry.phrases) phrases.put(phrase);
                item.put("phrases", phrases);
                profiles.put(item);
            }
            root.put("profiles", profiles);
        } catch (Exception ignored) { }
        return root;
    }

    public static String normalize(String value) {
        if (value == null) return "";
        String text = Normalizer.normalize(value.toLowerCase(Locale.ROOT), Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .replaceAll("[^\\p{L}\\p{N} ]", " ")
                .replaceAll("\\s+", " ")
                .trim();
        if (text.startsWith("hey iris ")) text = text.substring(9).trim();
        if (text.startsWith("iris ")) text = text.substring(5).trim();
        return text;
    }

    private static String normalizeNumber(String value) {
        return value == null ? "" : value.replaceAll("[^0-9+]", "");
    }

    private static double similarity(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        int[][] dp = new int[a.length() + 1][b.length() + 1];
        for (int i = 0; i <= a.length(); i++) dp[i][0] = i;
        for (int j = 0; j <= b.length(); j++) dp[0][j] = j;
        for (int i = 1; i <= a.length(); i++) {
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                dp[i][j] = Math.min(Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1),
                        dp[i - 1][j - 1] + cost);
            }
        }
        return 1.0 - ((double) dp[a.length()][b.length()] / Math.max(a.length(), b.length()));
    }
}
