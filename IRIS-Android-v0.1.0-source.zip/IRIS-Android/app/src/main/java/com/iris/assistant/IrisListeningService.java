package com.iris.assistant;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.ContactsContract;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IrisListeningService extends Service implements RecognitionListener {
    public static final String ACTION_START = "com.iris.assistant.START";
    public static final String ACTION_STOP = "com.iris.assistant.STOP";
    public static final String ACTION_CONFIRM_CALL = "com.iris.assistant.CONFIRM_CALL";
    public static final String ACTION_CANCEL_CALL = "com.iris.assistant.CANCEL_CALL";
    public static final String EVENT_STATE = "com.iris.assistant.EVENT_STATE";
    public static final String EVENT_TRANSCRIPT = "com.iris.assistant.EVENT_TRANSCRIPT";
    public static final String EVENT_CALL_PROMPT = "com.iris.assistant.EVENT_CALL_PROMPT";
    public static final String EVENT_MESSAGE = "com.iris.assistant.EVENT_MESSAGE";
    public static final String EXTRA_ACTIVE = "active";
    public static final String EXTRA_TEXT = "text";
    public static final String EXTRA_NAME = "name";
    public static final String EXTRA_NUMBER = "number";
    public static final String EXTRA_MIC = "mic";

    private static final String LISTENING_CHANNEL = "iris_listening";
    private static final String CALL_CHANNEL = "iris_call_confirmation";
    private static final int LISTENING_NOTIFICATION = 4101;
    private static final int CALL_NOTIFICATION = 4102;
    private static final Pattern CALL_PATTERN = Pattern.compile(
            "^(?:(?:please)\\s+)?(?:call|dial|phone)\\s+(.+?)(?:\\s+please)?$",
            Pattern.CASE_INSENSITIVE);

    public static volatile boolean isRunning = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private Intent recognizerIntent;
    private boolean awaitingConfirmation;
    private String microphoneLabel = "Phone microphone";
    private AudioManager routedAudioManager;
    private int previousAudioMode = AudioManager.MODE_NORMAL;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannels();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopIris("Listening switched off");
            return START_NOT_STICKY;
        }
        if (ACTION_CONFIRM_CALL.equals(action)) {
            awaitingConfirmation = false;
            cancelCallNotification();
            placeCall(intent.getStringExtra(EXTRA_NAME), intent.getStringExtra(EXTRA_NUMBER));
            return START_NOT_STICKY;
        }
        if (ACTION_CANCEL_CALL.equals(action)) {
            String name = intent.getStringExtra(EXTRA_NAME);
            awaitingConfirmation = false;
            cancelCallNotification();
            LogStore.append(this, "CANCELLED", "Call to " + (name == null ? "contact" : name));
            broadcastMessage("Call cancelled. Consider it unsaid.");
            if (isRunning) handler.postDelayed(this::startListening, 450);
            return START_STICKY;
        }

        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
            broadcastMessage("Microphone permission is required.");
            stopSelf();
            return START_NOT_STICKY;
        }

        isRunning = true;
        awaitingConfirmation = false;
        microphoneLabel = configureAudioRoute();
        startForeground(LISTENING_NOTIFICATION, listeningNotification());
        LogStore.append(this, "START", "Listening through " + microphoneLabel);
        broadcastState(true);
        createRecognizer();
        handler.postDelayed(this::startListening, 300);
        return START_STICKY;
    }

    private void createRecognizer() {
        destroyRecognizer();
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            broadcastMessage("No speech recognition service is available on this phone.");
            LogStore.append(this, "ERROR", "Speech recognition unavailable");
            return;
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(this);
        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag());
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
    }

    private void startListening() {
        if (!isRunning || awaitingConfirmation || recognizer == null) return;
        try {
            recognizer.cancel();
            recognizer.startListening(recognizerIntent);
        } catch (Exception error) {
            LogStore.append(this, "ERROR", "Could not start microphone: " + error.getMessage());
            scheduleRestart(1100);
        }
    }

    private String configureAudioRoute() {
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audioManager == null) return "Phone microphone";
        routedAudioManager = audioManager;
        previousAudioMode = audioManager.getMode();
        try {
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                for (AudioDeviceInfo device : audioManager.getAvailableCommunicationDevices()) {
                    int type = device.getType();
                    if (type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
                            || type == AudioDeviceInfo.TYPE_BLE_HEADSET
                            || type == AudioDeviceInfo.TYPE_WIRED_HEADSET
                            || type == AudioDeviceInfo.TYPE_USB_HEADSET) {
                        if (audioManager.setCommunicationDevice(device)) {
                            return readableDeviceName(device);
                        }
                    }
                }
            } else {
                for (AudioDeviceInfo device : audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)) {
                    if (device.getType() == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) {
                        audioManager.startBluetoothSco();
                        audioManager.setBluetoothScoOn(true);
                        return readableDeviceName(device);
                    }
                    if (device.getType() == AudioDeviceInfo.TYPE_WIRED_HEADSET
                            || device.getType() == AudioDeviceInfo.TYPE_USB_HEADSET) {
                        return readableDeviceName(device);
                    }
                }
            }
            for (AudioDeviceInfo device : audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)) {
                if (device.getType() != AudioDeviceInfo.TYPE_BUILTIN_MIC) return readableDeviceName(device);
            }
        } catch (SecurityException ignored) {
            return "Active system microphone";
        }
        return "Phone microphone";
    }

    private String readableDeviceName(AudioDeviceInfo device) {
        String product = device.getProductName() == null ? "" : device.getProductName().toString();
        if (!product.trim().isEmpty()) return product + " microphone";
        switch (device.getType()) {
            case AudioDeviceInfo.TYPE_BLUETOOTH_SCO: return "Bluetooth headset microphone";
            case AudioDeviceInfo.TYPE_BLE_HEADSET: return "Bluetooth LE headset microphone";
            case AudioDeviceInfo.TYPE_WIRED_HEADSET: return "Wired headset microphone";
            case AudioDeviceInfo.TYPE_USB_HEADSET: return "USB headset microphone";
            default: return "Active system microphone";
        }
    }

    private void handleFinalTranscript(String heard) {
        if (heard == null || heard.trim().isEmpty()) {
            scheduleRestart(400);
            return;
        }
        String clean = heard.trim();
        LogStore.append(this, "HEARD", clean);
        broadcastTranscript(clean);

        ProfileStore.Match learned = new ProfileStore(this).findMatch(clean);
        if (learned != null) {
            LogStore.append(this, "MATCH", "Learned phrase → " + learned.contactName
                    + " (" + Math.round(learned.confidence * 100) + "%)");
            requestCallConfirmation(learned.contactName, learned.phoneNumber);
            return;
        }

        Matcher matcher = CALL_PATTERN.matcher(ProfileStore.normalize(clean));
        if (!matcher.matches()) {
            LogStore.append(this, "IGNORED", "No call command detected");
            scheduleRestart(450);
            return;
        }

        String requested = matcher.group(1).trim();
        ContactMatch contact = resolveContact(requested);
        if (contact == null) {
            String message = hasPermission(Manifest.permission.READ_CONTACTS)
                    ? "I couldn't confidently match “" + requested + "” to a contact. Train the phrase once."
                    : "Contacts permission is needed to find “" + requested + "”.";
            LogStore.append(this, "NO MATCH", requested);
            broadcastMessage(message);
            scheduleRestart(900);
            return;
        }
        requestCallConfirmation(contact.name, contact.number);
    }

    private ContactMatch resolveContact(String requested) {
        String target = ProfileStore.normalize(requested);
        if (target.matches("[+0-9 ]{3,}")) return new ContactMatch(requested, requested.replace(" ", ""), 1.0);
        if (!hasPermission(Manifest.permission.READ_CONTACTS)) return null;
        ContentResolver resolver = getContentResolver();
        String[] projection = {
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
        };
        ContactMatch best = null;
        try (Cursor cursor = resolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection, null, null, null)) {
            if (cursor == null) return null;
            while (cursor.moveToNext()) {
                String name = cursor.getString(0);
                String number = cursor.getString(1);
                String candidate = ProfileStore.normalize(name);
                double score = nameScore(target, candidate);
                if (best == null || score > best.score) best = new ContactMatch(name, number, score);
            }
        } catch (Exception error) {
            LogStore.append(this, "ERROR", "Contact lookup failed: " + error.getMessage());
        }
        return best != null && best.score >= .70 ? best : null;
    }

    private double nameScore(String target, String candidate) {
        if (target.equals(candidate)) return 1.0;
        if (candidate.startsWith(target) || target.startsWith(candidate)) return .90;
        if (candidate.contains(target) || target.contains(candidate)) return .82;
        String[] targetWords = target.split(" ");
        String[] candidateWords = candidate.split(" ");
        for (String a : targetWords) {
            for (String b : candidateWords) {
                if (a.length() > 2 && a.equals(b)) return .76;
            }
        }
        return textSimilarity(target, candidate);
    }

    private double textSimilarity(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) previous[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1),
                        previous[j - 1] + cost);
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }
        return 1.0 - ((double) previous[b.length()] / Math.max(a.length(), b.length()));
    }

    private void requestCallConfirmation(String name, String number) {
        awaitingConfirmation = true;
        if (recognizer != null) recognizer.cancel();
        LogStore.append(this, "CONFIRM", "Waiting to call " + name);
        broadcastCallPrompt(name, number);
        showCallNotification(name, number);
    }

    private void placeCall(String name, String number) {
        if (number == null || number.trim().isEmpty()) {
            broadcastMessage("That contact has no callable number.");
            if (isRunning) scheduleRestart(500);
            return;
        }
        boolean direct = hasPermission(Manifest.permission.CALL_PHONE);
        Intent call = new Intent(direct ? Intent.ACTION_CALL : Intent.ACTION_DIAL,
                Uri.parse("tel:" + Uri.encode(number)));
        call.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            LogStore.append(this, direct ? "CALLING" : "DIALER", (name == null ? number : name));
            isRunning = false;
            broadcastState(false);
            destroyRecognizer();
            stopForeground(STOP_FOREGROUND_REMOVE);
            startActivity(call);
            stopSelf();
        } catch (Exception error) {
            LogStore.append(this, "ERROR", "Call failed: " + error.getMessage());
            broadcastMessage("This device could not place the call.");
            stopSelf();
        }
    }

    private Notification listeningNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, IrisListeningService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, LISTENING_CHANNEL)
                .setSmallIcon(com.iris.assistant.R.drawable.ic_iris)
                .setContentTitle("IRIS is listening")
                .setContentText(microphoneLabel + " • Say “Call <name>”")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(content)
                .addAction(new Notification.Action.Builder(null, "Turn off", stopPending).build())
                .build();
    }

    private void showCallNotification(String name, String number) {
        Intent confirm = new Intent(this, IrisListeningService.class)
                .setAction(ACTION_CONFIRM_CALL)
                .putExtra(EXTRA_NAME, name)
                .putExtra(EXTRA_NUMBER, number);
        Intent cancel = new Intent(this, IrisListeningService.class)
                .setAction(ACTION_CANCEL_CALL)
                .putExtra(EXTRA_NAME, name);
        PendingIntent yes = PendingIntent.getService(this, 2, confirm,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent no = PendingIntent.getService(this, 3, cancel,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent open = new Intent(this, MainActivity.class)
                .putExtra(EXTRA_NAME, name)
                .putExtra(EXTRA_NUMBER, number);
        PendingIntent content = PendingIntent.getActivity(this, 4, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(this, CALL_CHANNEL)
                .setSmallIcon(com.iris.assistant.R.drawable.ic_iris)
                .setContentTitle("Call " + name + "?")
                .setContentText(number)
                .setAutoCancel(false)
                .setContentIntent(content)
                .addAction(new Notification.Action.Builder(null, "Cancel", no).build())
                .addAction(new Notification.Action.Builder(null, "Call", yes).build())
                .build();
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(CALL_NOTIFICATION, notification);
    }

    private void cancelCallNotification() {
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(CALL_NOTIFICATION);
    }

    private void createNotificationChannels() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel listening = new NotificationChannel(LISTENING_CHANNEL,
                "IRIS listening", NotificationManager.IMPORTANCE_LOW);
        listening.setDescription("Required while IRIS is actively listening through the microphone.");
        NotificationChannel calls = new NotificationChannel(CALL_CHANNEL,
                "Call confirmation", NotificationManager.IMPORTANCE_HIGH);
        calls.setDescription("Asks before IRIS places a call.");
        manager.createNotificationChannel(listening);
        manager.createNotificationChannel(calls);
    }

    private void scheduleRestart(long delay) {
        handler.removeCallbacksAndMessages(null);
        if (isRunning && !awaitingConfirmation) handler.postDelayed(this::startListening, delay);
    }

    private void stopIris(String reason) {
        isRunning = false;
        awaitingConfirmation = false;
        handler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        cancelCallNotification();
        LogStore.append(this, "STOP", reason);
        broadcastState(false);
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            recognizer.cancel();
            recognizer.destroy();
            recognizer = null;
        }
    }

    private void releaseAudioRoute() {
        if (routedAudioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                routedAudioManager.clearCommunicationDevice();
            } else {
                routedAudioManager.setBluetoothScoOn(false);
                routedAudioManager.stopBluetoothSco();
            }
            routedAudioManager.setMode(previousAudioMode);
        } catch (Exception ignored) { }
        routedAudioManager = null;
    }

    private boolean hasPermission(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void broadcastState(boolean active) {
        Intent event = new Intent(EVENT_STATE).setPackage(getPackageName())
                .putExtra(EXTRA_ACTIVE, active)
                .putExtra(EXTRA_MIC, microphoneLabel);
        sendBroadcast(event);
    }

    private void broadcastTranscript(String text) {
        sendBroadcast(new Intent(EVENT_TRANSCRIPT).setPackage(getPackageName())
                .putExtra(EXTRA_TEXT, text));
    }

    private void broadcastCallPrompt(String name, String number) {
        sendBroadcast(new Intent(EVENT_CALL_PROMPT).setPackage(getPackageName())
                .putExtra(EXTRA_NAME, name)
                .putExtra(EXTRA_NUMBER, number));
    }

    private void broadcastMessage(String text) {
        sendBroadcast(new Intent(EVENT_MESSAGE).setPackage(getPackageName())
                .putExtra(EXTRA_TEXT, text));
    }

    @Override public void onReadyForSpeech(Bundle params) { broadcastMessage("Listening…"); }
    @Override public void onBeginningOfSpeech() { broadcastMessage("I hear you…"); }
    @Override public void onRmsChanged(float rmsdB) { }
    @Override public void onBufferReceived(byte[] buffer) { }
    @Override public void onEndOfSpeech() { broadcastMessage("Thinking…"); }

    @Override
    public void onError(int error) {
        if (!isRunning || awaitingConfirmation) return;
        if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                && error != SpeechRecognizer.ERROR_CLIENT) {
            LogStore.append(this, "LISTEN ERROR", speechError(error));
            broadcastMessage(speechError(error));
        }
        scheduleRestart(error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1300 : 500);
    }

    @Override
    public void onResults(Bundle results) {
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        handleFinalTranscript(matches == null || matches.isEmpty() ? "" : matches.get(0));
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) broadcastTranscript(matches.get(0));
    }

    @Override public void onEvent(int eventType, Bundle params) { }

    private String speechError(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "Microphone audio error";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "Microphone permission missing";
            case SpeechRecognizer.ERROR_NETWORK: return "Speech service network error";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "Speech service timed out";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "Speech service is busy";
            case SpeechRecognizer.ERROR_SERVER: return "Speech service error";
            default: return "Speech recognition paused (" + error + ")";
        }
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        handler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        releaseAudioRoute();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private static class ContactMatch {
        final String name;
        final String number;
        final double score;
        ContactMatch(String name, String number, double score) {
            this.name = name;
            this.number = number;
            this.score = score;
        }
    }
}
