package com.iris.assistant;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

public class IrisOrbView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float pulse = 0f;
    private boolean active = false;

    public IrisOrbView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setClickable(true);
        setFocusable(true);
        ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(1800);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        animator.setInterpolator(new AccelerateDecelerateInterpolator());
        animator.addUpdateListener(valueAnimator -> {
            pulse = (float) valueAnimator.getAnimatedValue();
            if (active) invalidate();
        });
        animator.start();
    }

    public void setActive(boolean active) {
        this.active = active;
        setContentDescription(active ? "Turn IRIS off" : "Turn IRIS on");
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float base = Math.min(getWidth(), getHeight()) * 0.31f;

        if (active) {
            float halo = base * (1.45f + pulse * 0.18f);
            paint.setShader(new RadialGradient(cx, cy, halo,
                    new int[]{0x668B5CF6, 0x3322D3EE, Color.TRANSPARENT},
                    new float[]{0f, .58f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, halo, paint);
            paint.setShader(null);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(5f);
            paint.setColor(0xAA22D3EE);
            canvas.drawCircle(cx, cy, base * (1.12f + pulse * .08f), paint);
        }

        paint.setStyle(Paint.Style.FILL);
        int inner = active ? 0xFF8B5CF6 : 0xFF2A2D4B;
        int outer = active ? 0xFF22D3EE : 0xFF414665;
        paint.setShader(new RadialGradient(cx - base * .25f, cy - base * .3f, base * 1.45f,
                new int[]{0xFFF8FAFC, inner, outer},
                new float[]{0f, .27f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, base, paint);
        paint.setShader(null);

        paint.setColor(0xFF090A18);
        canvas.drawCircle(cx, cy, base * .50f, paint);
        paint.setColor(active ? 0xFFFFFFFF : 0xFF8B91B4);
        canvas.drawCircle(cx, cy, base * .22f, paint);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(base * .19f);
        paint.setFakeBoldText(true);
        paint.setColor(active ? 0xFFFFFFFF : 0xFFB8BDD7);
        canvas.drawText(active ? "LISTENING" : "TAP TO WAKE", cx, cy + base * 1.42f, paint);
        paint.setFakeBoldText(false);
    }
}
