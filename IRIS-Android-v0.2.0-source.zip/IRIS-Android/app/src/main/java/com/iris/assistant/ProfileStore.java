package com.iris.assistant;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ProfileStore {
    private static final String FILE_NAME = "iris_profile_v2.enc";
    private static final String LEGACY_PREFS = "iris_profile_store";
    private static final String LEGACY_KEY = "profile_json";

    public static class Entry {
        public String contactName;
        public String phoneNumber;
        public final List<String> phrases = new ArrayList<>();
        public int callCount;
        public long lastCalled;
    }

    public static class WakeProfile {
        public String phrase = "";
        public double threshold = 1.05;
        public long trainedAt;
        public final List<float[][]> templates = new ArrayList<>();
        public boolean isReady() { return !phrase.trim().isEmpty() && templates.size() >= 3; }
    }

    public static class Match {
        public final String contactName;
        public final String phoneNumber;
        public final String phrase;
        public final double confidence;
        Match(String contactName, String phoneNumber, String phrase, double confidence) {
            this.contactName = contactName;
            this.phoneNumber = phoneNumber;
            this.phrase = phrase;
            this.confidence = confidence;
        }
    }

    private final Context context;

    public ProfileStore(Context context) {
        this.context = context.getApplicationContext();
        migrateLegacyIfNeeded();
    }

    public synchronized List<Entry> getEntries() {
        List<Entry> result = new ArrayList<>();
        try {
            JSONArray profiles = root().optJSONArray("profiles");
            if (profiles == null) return result;
            for (int i = 0; i < profiles.length(); i++) {
                JSONObject item = profiles.getJSONObject(i);
                Entry entry = new Entry();
                entry.contactName = item.optString("contactName", "");
                entry.phoneNumber = item.optString("phoneNumber", "");
                entry.callCount = item.optInt("callCount", 0);
                entry.lastCalled = item.optLong("lastCalled", 0);
                JSONArray phrases = item.optJSONArray("phrases");
                if (phrases != null) {
                    for (int p = 0; p < phrases.length(); p++) {
                        String phrase = phrases.optString(p, "").trim();
                        if (!phrase.isEmpty()) entry.phrases.add(phrase);
                    }
                }
                if (!entry.contactName.isEmpty() && !entry.phoneNumber.isEmpty()) result.add(entry);
            }
        } catch (Exception ignored) { }
        return result;
    }

    public synchronized WakeProfile getWakeProfile() {
        WakeProfile profile = new WakeProfile();
        try {
            JSONObject wake = root().optJSONObject("wakeWord");
            if (wake == null) return profile;
            profile.phrase = wake.optString("phrase", "");
            profile.threshold = Math.max(.40, Math.min(2.50, wake.optDouble("threshold", 1.05)));
            profile.trainedAt = wake.optLong("trainedAt", 0);
            JSONArray templates = wake.optJSONArray("templates");
            if (templates != null) {
                for (int t = 0; t < Math.min(5, templates.length()); t++) {
                    JSONArray frames = templates.getJSONArray(t);
                    int frameCount = Math.min(120, frames.length());
                    float[][] matrix = new float[frameCount][];
                    for (int f = 0; f < frameCount; f++) {
                        JSONArray features = frames.getJSONArray(f);
                        int featureCount = Math.min(20, features.length());
                        matrix[f] = new float[featureCount];
                        for (int c = 0; c < featureCount; c++) matrix[f][c] = (float) features.getDouble(c);
                    }
                    if (matrix.length > 0) profile.templates.add(matrix);
                }
            }
        } catch (Exception ignored) { }
        return profile;
    }

    public synchronized boolean setWakeProfile(String phrase, List<float[][]> templates) {
        try {
            JSONObject current = root();
            JSONObject wake = new JSONObject();
            wake.put("phrase", phrase.trim());
            wake.put("trainedAt", System.currentTimeMillis());
            wake.put("threshold", WakeWordEngine.calibratedThreshold(templates));
            JSONArray allTemplates = new JSONArray();
            for (float[][] template : templates) {
                JSONArray frames = new JSONArray();
                for (float[] frame : template) {
                    JSONArray values = new JSONArray();
                    for (float value : frame) values.put(Math.round(value * 10000f) / 10000.0);
                    frames.put(values);
                }
                allTemplates.put(frames);
            }
            wake.put("templates", allTemplates);
            current.put("wakeWord", wake);
            persist(current);
            return true;
        } catch (Exception ignored) { return false; }
    }

    public synchronized void addTraining(String name, String number, List<String> phrases) {
        List<Entry> entries = getEntries();
        Entry target = null;
        String normalizedNumber = normalizeNumber(number);
        for (Entry entry : entries) {
            if (normalizeNumber(entry.phoneNumber).equals(normalizedNumber)) {
                target = entry;
                break;
            }
        }
        if (target == null) {
            target = new Entry();
            target.contactName = name;
            target.phoneNumber = number;
            entries.add(target);
        }
        target.contactName = name;
        for (String phrase : phrases) {
            boolean exists = false;
            for (String old : target.phrases) if (normalize(old).equals(normalize(phrase))) exists = true;
            if (!exists && !phrase.trim().isEmpty()) target.phrases.add(phrase.trim());
        }
        saveEntries(entries);
    }

    public synchronized void deleteContact(String number) {
        String target = normalizeNumber(number);
        List<Entry> entries = getEntries();
        entries.removeIf(entry -> normalizeNumber(entry.phoneNumber).equals(target));
        saveEntries(entries);
    }

    public synchronized void recordCall(String name, String number) {
        List<Entry> entries = getEntries();
        Entry target = null;
        for (Entry entry : entries) {
            if (normalizeNumber(entry.phoneNumber).equals(normalizeNumber(number))) target = entry;
        }
        if (target == null) {
            target = new Entry();
            target.contactName = name == null ? number : name;
            target.phoneNumber = number;
            entries.add(target);
        }
        target.callCount++;
        target.lastCalled = System.currentTimeMillis();
        saveEntries(entries);
    }

    public synchronized List<Entry> frequentContacts(int limit) {
        List<Entry> entries = getEntries();
        entries.sort((a, b) -> {
            int calls = Integer.compare(b.callCount, a.callCount);
            return calls != 0 ? calls : Long.compare(b.lastCalled, a.lastCalled);
        });
        return new ArrayList<>(entries.subList(0, Math.min(limit, entries.size())));
    }

    public synchronized Match findMatch(String spokenText) {
        String heard = normalize(spokenText);
        Match best = null;
        for (Entry entry : getEntries()) {
            for (String phrase : entry.phrases) {
                String learned = normalize(phrase);
                double score;
                if (heard.equals(learned)) score = 1.0;
                else if (heard.contains(learned) || learned.contains(heard)) score = .91;
                else score = similarity(heard, learned);
                if (score >= .76 && (best == null || score > best.confidence)) {
                    best = new Match(entry.contactName, entry.phoneNumber, phrase, score);
                }
            }
        }
        return best;
    }

    public synchronized String exportJson() {
        try {
            JSONObject result = root();
            result.put("exportedAt", System.currentTimeMillis());
            result.put("description", "IRIS portable wake-word and calling profile");
            return result.toString(2);
        } catch (Exception error) {
            return emptyRoot().toString();
        }
    }

    public synchronized int importAndMerge(String json) throws Exception {
        JSONObject incoming = new JSONObject(json);
        if (!"iris-profile".equals(incoming.optString("schema"))) {
            throw new IllegalArgumentException("This is not an IRIS profile.");
        }
        int version = incoming.optInt("version", 1);
        if (version < 1 || version > 2) throw new IllegalArgumentException("Unsupported IRIS profile version.");
        JSONArray profiles = incoming.optJSONArray("profiles");
        List<Entry> current = getEntries();
        Map<String, Entry> merged = new LinkedHashMap<>();
        for (Entry entry : current) merged.put(normalizeNumber(entry.phoneNumber), entry);
        int imported = 0;
        if (profiles != null) {
            for (int i = 0; i < Math.min(500, profiles.length()); i++) {
                JSONObject item = profiles.getJSONObject(i);
                String name = item.optString("contactName", "").trim();
                String number = item.optString("phoneNumber", "").trim();
                if (name.isEmpty() || number.isEmpty()) continue;
                Entry target = merged.get(normalizeNumber(number));
                if (target == null) {
                    target = new Entry();
                    target.contactName = name;
                    target.phoneNumber = number;
                    merged.put(normalizeNumber(number), target);
                }
                JSONArray phrases = item.optJSONArray("phrases");
                if (phrases != null) {
                    for (int p = 0; p < Math.min(50, phrases.length()); p++) {
                        String phrase = phrases.optString(p, "").trim();
                        if (phrase.length() > 300) phrase = phrase.substring(0, 300);
                        boolean duplicate = false;
                        for (String old : target.phrases) if (normalize(old).equals(normalize(phrase))) duplicate = true;
                        if (!phrase.isEmpty() && !duplicate) target.phrases.add(phrase);
                    }
                }
                imported++;
            }
        }
        JSONObject result = root();
        result.put("profiles", entriesArray(new ArrayList<>(merged.values())));
        JSONObject wake = incoming.optJSONObject("wakeWord");
        if (wake != null && wake.optJSONArray("templates") != null) result.put("wakeWord", wake);
        result.put("version", 2);
        persist(result);
        return imported;
    }

    public synchronized int phraseCount() {
        int count = 0;
        for (Entry entry : getEntries()) count += entry.phrases.size();
        return count;
    }

    private void saveEntries(List<Entry> entries) {
        try {
            JSONObject current = root();
            current.put("profiles", entriesArray(entries));
            persist(current);
        } catch (Exception ignored) { }
    }

    private JSONArray entriesArray(List<Entry> entries) throws Exception {
        JSONArray profiles = new JSONArray();
        for (Entry entry : entries) {
            JSONObject item = new JSONObject();
            item.put("contactName", entry.contactName);
            item.put("phoneNumber", entry.phoneNumber);
            item.put("callCount", entry.callCount);
            item.put("lastCalled", entry.lastCalled);
            JSONArray phrases = new JSONArray();
            for (String phrase : entry.phrases) phrases.put(phrase);
            item.put("phrases", phrases);
            profiles.put(item);
        }
        return profiles;
    }

    private JSONObject root() {
        try {
            return new JSONObject(SecureStore.read(context, FILE_NAME, emptyRoot().toString()));
        } catch (Exception ignored) {
            return emptyRoot();
        }
    }

    private void persist(JSONObject root) throws Exception {
        root.put("schema", "iris-profile");
        root.put("version", 2);
        SecureStore.write(context, FILE_NAME, root.toString());
    }

    private JSONObject emptyRoot() {
        JSONObject root = new JSONObject();
        try {
            root.put("schema", "iris-profile");
            root.put("version", 2);
            root.put("profiles", new JSONArray());
        } catch (Exception ignored) { }
        return root;
    }

    private void migrateLegacyIfNeeded() {
        if (!SecureStore.read(context, FILE_NAME, "").isEmpty()) return;
        SharedPreferences legacy = context.getSharedPreferences(LEGACY_PREFS, Context.MODE_PRIVATE);
        String json = legacy.getString(LEGACY_KEY, "");
        if (json == null || json.isEmpty()) return;
        try {
            JSONObject old = new JSONObject(json);
            old.put("schema", "iris-profile");
            old.put("version", 2);
            SecureStore.write(context, FILE_NAME, old.toString());
            legacy.edit().remove(LEGACY_KEY).apply();
        } catch (Exception ignored) { }
    }

    public static String normalize(String value) {
        if (value == null) return "";
        String text = Normalizer.normalize(value.toLowerCase(Locale.ROOT), Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .replaceAll("[^\\p{L}\\p{N} ]", " ")
                .replaceAll("\\s+", " ").trim();
        if (text.startsWith("hey iris ")) text = text.substring(9).trim();
        if (text.startsWith("iris ")) text = text.substring(5).trim();
        return text;
    }

    private static String normalizeNumber(String value) {
        return value == null ? "" : value.replaceAll("[^0-9+]", "");
    }

    private static double similarity(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        int[][] dp = new int[a.length() + 1][b.length() + 1];
        for (int i = 0; i <= a.length(); i++) dp[i][0] = i;
        for (int j = 0; j <= b.length(); j++) dp[0][j] = j;
        for (int i = 1; i <= a.length(); i++) {
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                dp[i][j] = Math.min(Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1), dp[i - 1][j - 1] + cost);
            }
        }
        return 1.0 - ((double) dp[a.length()][b.length()] / Math.max(a.length(), b.length()));
    }
}
