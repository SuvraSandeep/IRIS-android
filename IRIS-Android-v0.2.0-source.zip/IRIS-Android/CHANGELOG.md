# Changelog

## 0.2.0

- Replaced continuous full recognizer use in the default mode with a trainable acoustic wake detector.
- Added fully customizable three-sample wake-phrase training and transfer.
- Added Wake, Tap, and Continuous Experimental modes.
- Added on-device speech preference, offline-model request, multilingual options, and fallback status.
- Added voice confirmation, contact disambiguation, phonetic matching, corrections, and safe no-call tests.
- Added encrypted profiles/logs, biometric export protection, retention choices, and locked-call protection.
- Added automatic and manual microphone routing, BLE headset handling, and a Quick Settings tile.
- Added personality, voice, haptic, text-size, activity, and training-management controls.
- Added animated assistant phases, live transcript/level feedback, contact imagery, and frequent-call insights.

## 0.1.0

- Initial calling-only Android MVP.
